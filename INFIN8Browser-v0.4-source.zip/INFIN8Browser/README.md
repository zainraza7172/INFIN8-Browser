# INFIN8 Browser v0.4

Android browser prototype with an embedded WireGuard USA mode and a fail-closed USA verification gate.

## v0.4 browser layer
- Vivaldi-style horizontal tab strip for quick switching
- + new-tab control directly on the strip
- Long-press a top tab to close it
- Redesigned new-tab / Speed Dial page
- Built-in Google/address search field on the new-tab page
- Default creator shortcuts: Instagram, TikTok, YouTube, YouTube Studio, Reddit and X
- User-created Speed Dial shortcuts with add/edit/delete, stored locally in WebView localStorage
- Existing full tab manager dialog retained

## Network security retained
- Embedded WireGuard tunnel backend
- Imported .conf encrypted locally with Android Keystore
- Tunnel scoped to the INFIN8 app package
- Automatic US-exit verification with independent checks
- Fail-closed WebView proxy gate when USA exit is not verified
- WebRTC shield and geolocation disabled

The Proton WireGuard private key is intentionally NOT bundled in source. Import the profile on-device.
