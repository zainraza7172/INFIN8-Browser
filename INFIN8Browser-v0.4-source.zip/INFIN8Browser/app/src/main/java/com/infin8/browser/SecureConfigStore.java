package com.infin8.browser;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores the imported WireGuard configuration encrypted with an app-private Android Keystore key.
 * The raw Proton private key is never committed to source code or GitHub.
 */
final class SecureConfigStore {
    private static final String PREFS = "infin8_secure_vpn";
    private static final String KEY_CONFIG = "wg_config_ciphertext";
    private static final String KEY_ALIAS = "infin8_wireguard_config_key_v1";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";

    private SecureConfigStore() {}

    static void save(Context context, String plaintext) throws Exception {
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encrypted = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        String iv = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP);
        String body = Base64.encodeToString(encrypted, Base64.NO_WRAP);
        prefs(context).edit().putString(KEY_CONFIG, iv + "." + body).apply();
    }

    static String load(Context context) throws Exception {
        String packed = prefs(context).getString(KEY_CONFIG, "");
        if (packed == null || packed.isEmpty()) return "";
        int dot = packed.indexOf('.');
        if (dot <= 0 || dot >= packed.length() - 1) return "";

        byte[] iv = Base64.decode(packed.substring(0, dot), Base64.NO_WRAP);
        byte[] body = Base64.decode(packed.substring(dot + 1), Base64.NO_WRAP);
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(body), StandardCharsets.UTF_8);
    }

    static boolean hasConfig(Context context) {
        String packed = prefs(context).getString(KEY_CONFIG, "");
        return packed != null && !packed.isEmpty();
    }

    static void clear(Context context) {
        prefs(context).edit().remove(KEY_CONFIG).apply();
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);
        java.security.Key existing = keyStore.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
        )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
