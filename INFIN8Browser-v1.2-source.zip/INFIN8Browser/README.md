# INFIN8 Browser v0.5

Android browser prototype with embedded WireGuard USA routing and a fail-closed verification gate.

## v0.5 UI cleanup
- Minimal top toolbar: INFIN8 logo, search/address bar, overflow menu only
- Overflow menu contains Back, Forward, Reload, Home, New Tab, Tabs, USA network and IP check
- Each top tab has a visible × close button
- Android system Back now prioritizes WebView history; if no history exists on a website it returns to the INFIN8 home page instead of immediately exiting
- Android 13+ modern back callback registered for gesture/back-button reliability
- Removed the USA MODE badge from the new-tab page
- Increased INFIN8 Browser branding size
- Speed Dial is now 100% user-custom; no preloaded social shortcuts
- Removed the USA Security Gate promotional card from the homepage

## Network security retained
- Embedded WireGuard tunnel backend
- Imported .conf encrypted locally with Android Keystore
- Tunnel scoped to the INFIN8 app package
- Automatic US-exit verification with independent checks
- Fail-closed WebView proxy gate when USA exit is not verified
- WebRTC shield and geolocation disabled

The Proton WireGuard private key is intentionally NOT bundled in source. Import the profile on-device.
