package com.infin8.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.URLUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * INFIN8 in-process downloader. It intentionally avoids Android DownloadManager so
 * download traffic remains inside this app package and follows INFIN8's app-routed VPN.
 *
 * Current engine: HTTP/HTTPS direct files, dynamic range segmentation (up to 32 parts),
 * pause/resume, retry recovery, queueing, speed limiting and automatic categories.
 */
public final class DownloadService extends Service {
    public static final String ACTION_ADD = "com.infin8.browser.download.ADD";
    public static final String ACTION_PAUSE = "com.infin8.browser.download.PAUSE";
    public static final String ACTION_RESUME = "com.infin8.browser.download.RESUME";
    public static final String ACTION_CANCEL = "com.infin8.browser.download.CANCEL";
    public static final String ACTION_RETRY = "com.infin8.browser.download.RETRY";
    public static final String ACTION_DELETE = "com.infin8.browser.download.DELETE";
    public static final String ACTION_MOVE_UP = "com.infin8.browser.download.MOVE_UP";
    public static final String ACTION_MOVE_DOWN = "com.infin8.browser.download.MOVE_DOWN";
    public static final String ACTION_SCHEDULE = "com.infin8.browser.download.SCHEDULE";
    public static final String ACTION_START_NOW = "com.infin8.browser.download.START_NOW";
    public static final String ACTION_WAKE = "com.infin8.browser.download.WAKE";

    public static final String EXTRA_ID = "id";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_USER_AGENT = "ua";
    public static final String EXTRA_CONTENT_DISPOSITION = "content_disposition";
    public static final String EXTRA_MIME = "mime";
    public static final String EXTRA_LENGTH = "length";
    public static final String EXTRA_FILENAME = "filename";
    public static final String EXTRA_SEGMENTS = "segments";
    public static final String EXTRA_CATEGORY = "category";
    public static final String EXTRA_SCHEDULE_AT = "schedule_at";

    private static final String CHANNEL_ID = "infin8_downloads";
    private static final int NOTIFICATION_ID = 8010;
    private static final String PREFS = "infin8_downloads";
    private static final String KEY_TASKS = "tasks";
    public static final String KEY_SPEED_LIMIT_KBPS = "speed_limit_kbps";
    public static final String KEY_WIFI_ONLY = "wifi_only";
    public static final String KEY_MAX_CONCURRENT = "max_concurrent";

    private final ExecutorService taskPool = Executors.newFixedThreadPool(3);
    private final Map<String, AtomicBoolean> pauseFlags = new ConcurrentHashMap<>();
    private final Map<String, Future<?>> running = new ConcurrentHashMap<>();
    private final Object persistLock = new Object();
    private final Object rateLock = new Object();
    private final Object usaVerifyLock = new Object();
    private long downloadUsaVerifiedAt;
    private boolean downloadUsaVerified;
    private String downloadUsaDetail = "USA exit not verified";
    private UsaNetworkVerifier downloadUsaVerifier;
    private long rateWindowStarted = System.currentTimeMillis();
    private long rateWindowBytes;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final Handler scheduleHandler = new Handler(Looper.getMainLooper());
    private final Runnable scheduleTick = () -> { pumpQueue(); refreshNotification(); };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        downloadUsaVerifier = new UsaNetworkVerifier();
        startForeground(NOTIFICATION_ID, buildNotification("Downloads ready", "INFIN8 download manager", -1, false));
        registerNetworkWatcher();
        recoverInterruptedTasks();
        resumeWaitingWifiTasks();
        pumpQueue();
        scheduleNextWake();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_ADD.equals(action)) {
            addTask(intent);
        } else if (ACTION_PAUSE.equals(action)) {
            pauseTask(intent.getStringExtra(EXTRA_ID));
        } else if (ACTION_RESUME.equals(action) || ACTION_RETRY.equals(action) || ACTION_START_NOW.equals(action)) {
            resumeTask(intent.getStringExtra(EXTRA_ID));
        } else if (ACTION_CANCEL.equals(action)) {
            cancelTask(intent.getStringExtra(EXTRA_ID));
        } else if (ACTION_DELETE.equals(action)) {
            deleteTask(intent.getStringExtra(EXTRA_ID));
        } else if (ACTION_MOVE_UP.equals(action)) {
            moveTask(intent.getStringExtra(EXTRA_ID), -1);
        } else if (ACTION_MOVE_DOWN.equals(action)) {
            moveTask(intent.getStringExtra(EXTRA_ID), 1);
        } else if (ACTION_SCHEDULE.equals(action)) {
            scheduleTask(intent.getStringExtra(EXTRA_ID), intent.getLongExtra(EXTRA_SCHEDULE_AT, 0L));
        } else if (ACTION_WAKE.equals(action)) {
            resumeWaitingUsaTasks();
        }
        if (!isWifiOnly(this) || isWifiConnected()) resumeWaitingWifiTasks();
        pumpQueue();
        scheduleNextWake();
        refreshNotification();
        return START_STICKY;
    }

    public static void enqueue(Context context, String url, String userAgent, String contentDisposition, String mime, long length) {
        enqueueAdvanced(context, url, userAgent, contentDisposition, mime, length, "", 0, "", 0L);
    }

    public static void enqueueAdvanced(Context context, String url, String userAgent, String contentDisposition, String mime, long length,
                                       String filename, int requestedSegments, String category) {
        enqueueAdvanced(context, url, userAgent, contentDisposition, mime, length, filename, requestedSegments, category, 0L);
    }

    public static void enqueueAdvanced(Context context, String url, String userAgent, String contentDisposition, String mime, long length,
                                       String filename, int requestedSegments, String category, long scheduledAt) {
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(ACTION_ADD);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_USER_AGENT, userAgent == null ? "" : userAgent);
        i.putExtra(EXTRA_CONTENT_DISPOSITION, contentDisposition == null ? "" : contentDisposition);
        i.putExtra(EXTRA_MIME, mime == null ? "" : mime);
        i.putExtra(EXTRA_LENGTH, length);
        i.putExtra(EXTRA_FILENAME, filename == null ? "" : filename);
        i.putExtra(EXTRA_SEGMENTS, requestedSegments);
        i.putExtra(EXTRA_CATEGORY, category == null ? "" : category);
        i.putExtra(EXTRA_SCHEDULE_AT, Math.max(0L, scheduledAt));
        startServiceCompat(context, i);
    }

    public static void schedule(Context context, String id, long whenMillis) {
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(ACTION_SCHEDULE);
        i.putExtra(EXTRA_ID, id);
        i.putExtra(EXTRA_SCHEDULE_AT, whenMillis);
        startServiceCompat(context, i);
    }

    public static void command(Context context, String action, String id) {
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(action);
        i.putExtra(EXTRA_ID, id);
        startServiceCompat(context, i);
    }

    public static void wake(Context context) {
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(ACTION_WAKE);
        startServiceCompat(context, i);
    }

    private static void startServiceCompat(Context context, Intent i) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
        else context.startService(i);
    }

    private void addTask(Intent intent) {
        String url = intent.getStringExtra(EXTRA_URL);
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return;
        String ua = intent.getStringExtra(EXTRA_USER_AGENT);
        String disposition = intent.getStringExtra(EXTRA_CONTENT_DISPOSITION);
        String mime = intent.getStringExtra(EXTRA_MIME);
        long length = intent.getLongExtra(EXTRA_LENGTH, -1L);
        String requestedName = intent.getStringExtra(EXTRA_FILENAME);
        String guessedName = URLUtil.guessFileName(url, disposition, mime);
        String name = safeFilename(requestedName == null || requestedName.trim().isEmpty() ? guessedName : requestedName);
        int requestedSegments = normalizeRequestedSegments(intent.getIntExtra(EXTRA_SEGMENTS, 0));
        String category = normalizeCategory(intent.getStringExtra(EXTRA_CATEGORY));
        long scheduledAt = Math.max(0L, intent.getLongExtra(EXTRA_SCHEDULE_AT, 0L));
        String mediaKind = detectMediaKind(url, mime);
        if (!"DIRECT".equals(mediaKind)) {
            requestedSegments = 1;
            category = "Videos";
            name = streamFilename(name);
        }
        String initialState = scheduledAt > System.currentTimeMillis() + 1000L ? "SCHEDULED" : "QUEUED";
        TaskInfo task = new TaskInfo(UUID.randomUUID().toString(), url, ua, name, mime, length, 0L, initialState, "", 1,
                System.currentTimeMillis(), "", System.currentTimeMillis(), requestedSegments, category, scheduledAt, mediaKind, "");
        List<TaskInfo> tasks = loadTasks(this);
        tasks.add(0, task);
        saveTasks(this, tasks);
        pumpQueue();
        scheduleNextWake();
    }

    private void pauseTask(String id) {
        if (id == null) return;
        pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean()).set(true);
        Future<?> f = running.remove(id);
        if (f != null) f.cancel(true);
        updateTask(id, t -> t.withState("PAUSED", t.error));
        pumpQueue();
    }

    private void resumeTask(String id) {
        if (id == null) return;
        AtomicBoolean flag = pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean());
        flag.set(false);
        updateTask(id, t -> t.withSchedule(0L, "QUEUED", ""));
        pumpQueue();
    }

    private void cancelTask(String id) {
        if (id == null) return;
        pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean()).set(true);
        Future<?> f = running.remove(id);
        if (f != null) f.cancel(true);
        TaskInfo task = findTask(id);
        if (task != null) cleanupTaskFiles(task);
        updateTask(id, t -> t.withState("CANCELLED", ""));
        pumpQueue();
        scheduleNextWake();
    }

    private void deleteTask(String id) {
        if (id == null) return;
        pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean()).set(true);
        Future<?> f = running.remove(id);
        if (f != null) f.cancel(true);
        synchronized (persistLock) {
            List<TaskInfo> tasks = loadTasks(this);
            for (int i = tasks.size() - 1; i >= 0; i--) {
                TaskInfo t = tasks.get(i);
                if (id.equals(t.id)) {
                    cleanupTaskFiles(t);
                    if (t.outputPath != null && !t.outputPath.isEmpty()) new File(t.outputPath).delete();
                    tasks.remove(i);
                }
            }
            saveTasks(this, tasks);
        }
        pumpQueue();
        scheduleNextWake();
    }

    private void submit(String id) {
        if (id == null || running.containsKey(id)) return;
        Future<?> f = taskPool.submit(() -> {
            try {
                runTask(id);
            } finally {
                running.remove(id);
                pumpQueue();
                scheduleNextWake();
                refreshNotification();
            }
        });
        running.put(id, f);
    }

    private synchronized void pumpQueue() {
        long now = System.currentTimeMillis();
        List<TaskInfo> tasks = loadTasks(this);
        boolean changed = false;
        for (int i = 0; i < tasks.size(); i++) {
            TaskInfo t = tasks.get(i);
            if ("SCHEDULED".equals(t.state) && t.scheduledAt > 0 && t.scheduledAt <= now) {
                tasks.set(i, t.withSchedule(0L, "QUEUED", ""));
                changed = true;
            }
        }
        if (changed) saveTasks(this, tasks);
        int max = getMaxConcurrent(this);
        int slots = Math.max(0, max - running.size());
        if (slots <= 0) return;
        for (TaskInfo t : tasks) {
            if (slots <= 0) break;
            if (!"QUEUED".equals(t.state) || running.containsKey(t.id)) continue;
            if (isWifiOnly(this) && !isWifiConnected()) {
                updateTask(t.id, x -> x.withState("WAITING_WIFI", "Waiting for Wi-Fi"));
                continue;
            }
            submit(t.id);
            slots--;
        }
    }

    private void moveTask(String id, int direction) {
        if (id == null || direction == 0) return;
        synchronized (persistLock) {
            List<TaskInfo> tasks = loadTasks(this);
            int from = -1;
            for (int i = 0; i < tasks.size(); i++) if (id.equals(tasks.get(i).id)) { from = i; break; }
            if (from < 0) return;
            TaskInfo current = tasks.get(from);
            if (!("QUEUED".equals(current.state) || "SCHEDULED".equals(current.state) || "PAUSED".equals(current.state))) return;
            int to = from + direction;
            while (to >= 0 && to < tasks.size()) {
                TaskInfo other = tasks.get(to);
                if ("QUEUED".equals(other.state) || "SCHEDULED".equals(other.state) || "PAUSED".equals(other.state)) break;
                to += direction;
            }
            if (to < 0 || to >= tasks.size()) return;
            Collections.swap(tasks, from, to);
            saveTasks(this, tasks);
        }
        pumpQueue();
    }

    private void scheduleTask(String id, long whenMillis) {
        if (id == null) return;
        pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean()).set(true);
        Future<?> f = running.remove(id);
        if (f != null) f.cancel(true);
        long when = Math.max(System.currentTimeMillis() + 5000L, whenMillis);
        updateTask(id, t -> t.withSchedule(when, "SCHEDULED", "Starts at " + formatScheduleTime(when)));
        scheduleNextWake();
        pumpQueue();
    }

    private void runTask(String id) {
        TaskInfo task = findTask(id);
        if (task == null) return;
        AtomicBoolean pause = pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean(false));
        pause.set(false);

        try {
            if (task.scheduledAt > System.currentTimeMillis() + 1000L) return;
            if (!ensureUsaExitForDownload()) {
                updateTask(id, t -> t.withState("WAITING_USA", downloadUsaDetail));
                return;
            }
            if (isWifiOnly(this) && !isWifiConnected()) {
                updateTask(id, t -> t.withState("WAITING_WIFI", "Waiting for Wi-Fi"));
                return;
            }
            String mediaKind = task.mediaKind == null || task.mediaKind.isEmpty() ? detectMediaKind(task.url, task.mime) : task.mediaKind;
            if (!"DIRECT".equals(mediaKind)) {
                runStreamTask(task, pause, mediaKind);
                return;
            }

            Probe probe = probe(task.url, task.userAgent, task.totalBytes);
            long total = probe.totalBytes > 0 ? probe.totalBytes : task.totalBytes;
            int segments = task.requestedSegments > 0
                    ? (probe.acceptRanges && total > 0 ? Math.min(32, task.requestedSegments) : 1)
                    : chooseSegmentCount(total, probe.acceptRanges);
            String folder = task.category == null || task.category.isEmpty() ? categoryFor(task.filename, task.mime) : task.category;
            File categoryDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), folder);
            if (!categoryDir.exists() && !categoryDir.mkdirs()) throw new IllegalStateException("Could not create downloads folder");
            File finalFile = uniqueFinalFile(categoryDir, task.filename, task.outputPath);
            String outputPath = finalFile.getAbsolutePath();

            task = new TaskInfo(task.id, task.url, task.userAgent, finalFile.getName(), task.mime, total, task.downloadedBytes,
                    "DOWNLOADING", outputPath, segments, task.createdAt, "", System.currentTimeMillis(), task.requestedSegments, folder,
                    0L, "DIRECT", task.detail);
            replaceTask(task);

            if (segments > 1 && total > 0) downloadSegmented(task, pause);
            else downloadSingle(task, pause);

            if (pause.get()) { markPausedIfActive(id); return; }
            updateTask(id, t -> new TaskInfo(t.id, t.url, t.userAgent, t.filename, t.mime, t.totalBytes,
                    t.totalBytes > 0 ? t.totalBytes : t.downloadedBytes, "COMPLETED", t.outputPath, t.segments, t.createdAt, "",
                    System.currentTimeMillis(), t.requestedSegments, t.category, 0L, t.mediaKind, t.detail));
        } catch (PausedException | StreamDownloader.PauseException e) {
            markPausedIfActive(id);
        } catch (Throwable e) {
            updateTask(id, t -> ("CANCELLED".equals(t.state) || "SCHEDULED".equals(t.state)) ? t : t.withState("FAILED", safeError(e)));
        }
    }

    private void markPausedIfActive(String id) {
        updateTask(id, t -> ("CANCELLED".equals(t.state) || "SCHEDULED".equals(t.state)) ? t : t.withState("PAUSED", ""));
    }

    private void runStreamTask(TaskInfo original, AtomicBoolean pause, String mediaKind) throws Exception {
        String folder = "Videos";
        File categoryDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), folder);
        if (!categoryDir.exists() && !categoryDir.mkdirs()) throw new IllegalStateException("Could not create Videos folder");
        String name = streamFilename(original.filename);
        File finalFile = uniqueFinalFile(categoryDir, name, original.outputPath);
        TaskInfo task = new TaskInfo(original.id, original.url, original.userAgent, finalFile.getName(),
                "video/mp4", -1L, original.downloadedBytes, "DOWNLOADING", finalFile.getAbsolutePath(), 1, original.createdAt, "",
                System.currentTimeMillis(), 1, folder, 0L, mediaKind, mediaKind + " public clear stream");
        replaceTask(task);

        StreamDownloader.Control control = new StreamDownloader.Control() {
            @Override public boolean isPaused() { return pause.get() || Thread.currentThread().isInterrupted(); }
            @Override public void onBytes(long totalDownloaded) { publishProgress(task.id, totalDownloaded, -1L); }
            @Override public void throttle(int bytes) throws InterruptedException { DownloadService.this.throttle(bytes); }
        };
        StreamDownloader.Result result = "HLS".equals(mediaKind)
                ? StreamDownloader.downloadHls(task.url, task.userAgent, finalFile, control)
                : StreamDownloader.downloadDash(task.url, task.userAgent, finalFile, control);
        if (pause.get()) throw new PausedException();
        updateTask(task.id, t -> new TaskInfo(t.id, t.url, t.userAgent, result.file.getName(), result.mime, result.bytes, result.bytes,
                "COMPLETED", result.file.getAbsolutePath(), 1, t.createdAt, "", System.currentTimeMillis(), 1, folder,
                0L, mediaKind, result.detail));
    }

    private void downloadSegmented(TaskInfo task, AtomicBoolean pause) throws Exception {
        int segments = Math.max(2, task.segments);
        File finalFile = new File(task.outputPath);
        File tempDir = new File(finalFile.getParentFile(), ".infin8_" + task.id);
        if (!tempDir.exists() && !tempDir.mkdirs()) throw new IllegalStateException("Could not create temporary download folder");

        long piece = task.totalBytes / segments;
        AtomicLong downloaded = new AtomicLong(0L);
        for (int i = 0; i < segments; i++) {
            File part = new File(tempDir, "part_" + i);
            downloaded.addAndGet(part.exists() ? part.length() : 0L);
        }
        publishProgress(task.id, downloaded.get(), task.totalBytes);

        ExecutorService segmentPool = Executors.newFixedThreadPool(Math.min(8, segments));
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < segments; i++) {
            final int index = i;
            final long start = i * piece;
            final long end = (i == segments - 1) ? task.totalBytes - 1 : (start + piece - 1);
            futures.add(segmentPool.submit(() -> {
                try {
                    downloadRange(task, tempDir, index, start, end, pause, downloaded);
                } catch (PausedException e) {
                    throw new RuntimeException(e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }));
        }

        Throwable failure = null;
        for (Future<?> future : futures) {
            try { future.get(); }
            catch (Throwable e) { failure = e.getCause() == null ? e : e.getCause(); break; }
        }
        if (failure != null) {
            pause.set(pause.get());
            segmentPool.shutdownNow();
            if (containsPaused(failure) || pause.get()) throw new PausedException();
            if (failure instanceof Exception) throw (Exception) failure;
            throw new RuntimeException(failure);
        }
        segmentPool.shutdown();
        if (pause.get()) throw new PausedException();

        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(finalFile, false))) {
            byte[] buffer = new byte[64 * 1024];
            for (int i = 0; i < segments; i++) {
                File part = new File(tempDir, "part_" + i);
                try (InputStream in = new BufferedInputStream(new FileInputStream(part))) {
                    int n;
                    while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
                }
            }
        }
        deleteRecursively(tempDir);
    }

    private void downloadRange(TaskInfo task, File tempDir, int index, long start, long end,
                               AtomicBoolean pause, AtomicLong downloaded) throws Exception {
        File part = new File(tempDir, "part_" + index);
        long expected = end - start + 1;
        long have = part.exists() ? part.length() : 0L;
        if (have >= expected) return;

        int attempt = 0;
        while (attempt < 4) {
            attempt++;
            if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
            HttpURLConnection c = null;
            try {
                long rangeStart = start + have;
                c = open(task.url, task.userAgent);
                c.setRequestProperty("Range", "bytes=" + rangeStart + "-" + end);
                c.connect();
                int code = c.getResponseCode();
                if (code != HttpURLConnection.HTTP_PARTIAL) throw new IllegalStateException("Server stopped supporting range requests");
                try (InputStream in = new BufferedInputStream(c.getInputStream());
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(part, true))) {
                    byte[] buffer = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buffer)) >= 0) {
                        if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
                        throttle(n);
                        out.write(buffer, 0, n);
                        have += n;
                        long now = downloaded.addAndGet(n);
                        publishProgress(task.id, now, task.totalBytes);
                    }
                }
                if (have >= expected) return;
            } catch (PausedException e) {
                throw e;
            } catch (Exception e) {
                if (attempt >= 4) throw e;
                try { Thread.sleep(700L * attempt); } catch (InterruptedException ie) { throw new PausedException(); }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void downloadSingle(TaskInfo task, AtomicBoolean pause) throws Exception {
        File finalFile = new File(task.outputPath);
        File part = new File(finalFile.getAbsolutePath() + ".part");
        long have = part.exists() ? part.length() : 0L;
        int attempt = 0;
        while (attempt < 4) {
            attempt++;
            if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
            HttpURLConnection c = null;
            try {
                c = open(task.url, task.userAgent);
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                c.connect();
                int code = c.getResponseCode();
                boolean append = have > 0 && code == HttpURLConnection.HTTP_PARTIAL;
                if (have > 0 && !append) have = 0;
                try (InputStream in = new BufferedInputStream(c.getInputStream());
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(part, append))) {
                    byte[] buffer = new byte[64 * 1024];
                    int n;
                    long progress = have;
                    while ((n = in.read(buffer)) >= 0) {
                        if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
                        throttle(n);
                        out.write(buffer, 0, n);
                        progress += n;
                        publishProgress(task.id, progress, task.totalBytes);
                    }
                }
                if (!part.renameTo(finalFile)) {
                    copy(part, finalFile);
                    part.delete();
                }
                return;
            } catch (PausedException e) {
                throw e;
            } catch (Exception e) {
                if (attempt >= 4) throw e;
                try { Thread.sleep(700L * attempt); } catch (InterruptedException ie) { throw new PausedException(); }
                have = part.exists() ? part.length() : 0L;
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private Probe probe(String url, String ua, long knownLength) throws Exception {
        HttpURLConnection c = open(url, ua);
        c.setRequestMethod("HEAD");
        try {
            c.connect();
            int code = c.getResponseCode();
            if (code >= 200 && code < 400) {
                long total = c.getContentLengthLong();
                String ranges = c.getHeaderField("Accept-Ranges");
                boolean accept = ranges != null && ranges.toLowerCase(Locale.ENGLISH).contains("bytes");
                return new Probe(total > 0 ? total : knownLength, accept);
            }
        } finally {
            c.disconnect();
        }

        HttpURLConnection range = open(url, ua);
        range.setRequestProperty("Range", "bytes=0-0");
        try {
            range.connect();
            int code = range.getResponseCode();
            boolean accept = code == HttpURLConnection.HTTP_PARTIAL;
            long total = knownLength;
            String contentRange = range.getHeaderField("Content-Range");
            if (contentRange != null && contentRange.contains("/")) {
                try { total = Long.parseLong(contentRange.substring(contentRange.lastIndexOf('/') + 1).trim()); } catch (Exception ignored) {}
            }
            if (total <= 0) total = range.getContentLengthLong();
            return new Probe(total, accept);
        } finally {
            range.disconnect();
        }
    }

    private HttpURLConnection open(String rawUrl, String ua) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(rawUrl).openConnection();
        c.setConnectTimeout(15_000);
        c.setReadTimeout(30_000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", ua == null || ua.isEmpty() ? "INFIN8 Browser" : ua);
        c.setRequestProperty("Accept-Encoding", "identity");
        try {
            String cookie = CookieManager.getInstance().getCookie(rawUrl);
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        } catch (Throwable ignored) {}
        return c;
    }

    private int chooseSegmentCount(long total, boolean acceptRanges) {
        if (!acceptRanges || total <= 2L * 1024L * 1024L) return 1;
        if (total < 25L * 1024L * 1024L) return 4;
        if (total < 250L * 1024L * 1024L) return 8;
        if (total < 1024L * 1024L * 1024L) return 16;
        return 32;
    }

    private void throttle(int bytes) throws InterruptedException {
        long kbps = getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_SPEED_LIMIT_KBPS, 0L);
        if (kbps <= 0) return;
        long maxBytes = kbps * 1024L;
        synchronized (rateLock) {
            long now = System.currentTimeMillis();
            if (now - rateWindowStarted >= 1000L) {
                rateWindowStarted = now;
                rateWindowBytes = 0L;
            }
            rateWindowBytes += bytes;
            if (rateWindowBytes > maxBytes) {
                long wait = 1000L - (now - rateWindowStarted);
                if (wait > 0) Thread.sleep(wait);
                rateWindowStarted = System.currentTimeMillis();
                rateWindowBytes = 0L;
            }
        }
    }

    private void publishProgress(String id, long downloaded, long total) {
        long now = System.currentTimeMillis();
        TaskInfo current = findTask(id);
        if (current == null) return;
        if (downloaded - current.downloadedBytes < 256 * 1024L && now - current.lastPersistAt < 900L) return;
        replaceTask(new TaskInfo(current.id, current.url, current.userAgent, current.filename, current.mime,
                total > 0 ? total : current.totalBytes, downloaded, current.state, current.outputPath,
                current.segments, current.createdAt, current.error, now, current.requestedSegments, current.category,
                current.scheduledAt, current.mediaKind, current.detail));
        refreshNotification();
    }

    private void recoverInterruptedTasks() {
        List<TaskInfo> tasks = loadTasks(this);
        boolean changed = false;
        for (int i = 0; i < tasks.size(); i++) {
            TaskInfo t = tasks.get(i);
            if ("DOWNLOADING".equals(t.state)) {
                tasks.set(i, t.withState("PAUSED", "App restarted — tap Resume"));
                changed = true;
            }
        }
        if (changed) saveTasks(this, tasks);
    }

    private void cleanupTaskFiles(TaskInfo task) {
        if (task.outputPath == null || task.outputPath.isEmpty()) return;
        File finalFile = new File(task.outputPath);
        new File(finalFile.getAbsolutePath() + ".part").delete();
        deleteRecursively(new File(finalFile.getParentFile(), ".infin8_" + task.id));
        deleteRecursively(new File(finalFile.getParentFile(), ".stream_" + Math.abs((task.url + finalFile.getName()).hashCode())));
        deleteRecursively(new File(finalFile.getParentFile(), ".dash_" + Math.abs((task.url + finalFile.getName()).hashCode())));
    }

    private static void copy(File from, File to) throws Exception {
        try (InputStream in = new BufferedInputStream(new FileInputStream(from));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(to, false))) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
        }
    }

    private static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursively(c);
        }
        f.delete();
    }

    private File uniqueFinalFile(File dir, String name, String existingPath) {
        if (existingPath != null && !existingPath.isEmpty()) return new File(existingPath);
        File file = new File(dir, name);
        if (!file.exists()) return file;
        String base = name, ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        for (int i = 2; i < 1000; i++) {
            File candidate = new File(dir, base + " (" + i + ")" + ext);
            if (!candidate.exists()) return candidate;
        }
        return new File(dir, System.currentTimeMillis() + "_" + name);
    }

    private static String categoryFor(String name, String mime) {
        String lower = (name == null ? "" : name.toLowerCase(Locale.ENGLISH));
        String m = mime == null ? "" : mime.toLowerCase(Locale.ENGLISH);
        if (m.startsWith("video/") || lower.matches(".*\\.(mp4|mkv|webm|mov|avi|ts)$")) return "Videos";
        if (m.startsWith("audio/") || lower.matches(".*\\.(mp3|m4a|aac|flac|wav|ogg)$")) return "Music";
        if (m.startsWith("image/") || lower.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|svg)$")) return "Images";
        if (lower.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|epub)$")) return "Documents";
        if (lower.endsWith(".apk")) return "Apps";
        return "Other";
    }

    private static String safeFilename(String value) {
        String name = value == null || value.trim().isEmpty() ? "download.bin" : value.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return name.length() > 160 ? name.substring(name.length() - 160) : name;
    }

    private static String safeError(Throwable e) {
        if (e == null) return "Unknown download error";
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) m = e.getClass().getSimpleName();
        return m.length() > 180 ? m.substring(0, 180) : m;
    }

    private static boolean containsPaused(Throwable t) {
        Throwable c = t;
        for (int i = 0; i < 5 && c != null; i++, c = c.getCause()) if (c instanceof PausedException) return true;
        return false;
    }

    interface TaskMutator { TaskInfo mutate(TaskInfo task); }

    private void updateTask(String id, TaskMutator mutator) {
        synchronized (persistLock) {
            List<TaskInfo> tasks = loadTasks(this);
            for (int i = 0; i < tasks.size(); i++) {
                if (tasks.get(i).id.equals(id)) {
                    tasks.set(i, mutator.mutate(tasks.get(i)));
                    break;
                }
            }
            saveTasks(this, tasks);
        }
    }

    private void replaceTask(TaskInfo replacement) {
        synchronized (persistLock) {
            List<TaskInfo> tasks = loadTasks(this);
            for (int i = 0; i < tasks.size(); i++) {
                if (tasks.get(i).id.equals(replacement.id)) {
                    tasks.set(i, replacement);
                    saveTasks(this, tasks);
                    return;
                }
            }
            tasks.add(0, replacement);
            saveTasks(this, tasks);
        }
    }

    private TaskInfo findTask(String id) {
        for (TaskInfo t : loadTasks(this)) if (t.id.equals(id)) return t;
        return null;
    }

    public static List<TaskInfo> loadTasks(Context context) {
        List<TaskInfo> result = new ArrayList<>();
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString(KEY_TASKS, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                result.add(TaskInfo.fromJson(o));
            }
        } catch (Exception ignored) {}
        return result;
    }

    private static void saveTasks(Context context, List<TaskInfo> tasks) {
        JSONArray a = new JSONArray();
        try { for (TaskInfo t : tasks) a.put(t.toJson()); } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TASKS, a.toString()).commit();
    }

    public static long getSpeedLimitKbps(Context context) {
        return context.getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_SPEED_LIMIT_KBPS, 0L);
    }

    public static void setSpeedLimitKbps(Context context, long kbps) {
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong(KEY_SPEED_LIMIT_KBPS, Math.max(0L, kbps)).apply();
    }

    public static boolean isWifiOnly(Context context) {
        return context.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_WIFI_ONLY, false);
    }

    public static void setWifiOnly(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_WIFI_ONLY, enabled).apply();
        Intent i = new Intent(context, DownloadService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i); else context.startService(i);
    }

    private boolean ensureUsaExitForDownload() {
        synchronized (usaVerifyLock) {
            long now = System.currentTimeMillis();
            if (downloadUsaVerified && now - downloadUsaVerifiedAt < 10L * 60L * 1000L) return true;
            try {
                if (downloadUsaVerifier == null) downloadUsaVerifier = new UsaNetworkVerifier();
                UsaNetworkVerifier.Result result = downloadUsaVerifier.verifyBlocking();
                downloadUsaVerified = result.verifiedUsa;
                downloadUsaVerifiedAt = result.verifiedUsa ? now : 0L;
                downloadUsaDetail = result.detail == null || result.detail.isEmpty() ? "USA exit not verified" : result.detail;
                return downloadUsaVerified;
            } catch (Throwable e) {
                downloadUsaVerified = false;
                downloadUsaVerifiedAt = 0L;
                downloadUsaDetail = "USA verification unavailable — download remains blocked";
                return false;
            }
        }
    }

    private void resumeWaitingUsaTasks() {
        downloadUsaVerified = false;
        downloadUsaVerifiedAt = 0L;
        for (TaskInfo t : loadTasks(this)) {
            if ("WAITING_USA".equals(t.state)) updateTask(t.id, x -> x.withState("QUEUED", ""));
        }
    }

    private boolean isWifiConnected() {
        try {
            if (connectivityManager == null) connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = connectivityManager.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = connectivityManager.getNetworkCapabilities(n);
            return c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) { return false; }
    }

    private void registerNetworkWatcher() {
        try {
            connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { resumeWaitingWifiTasks(); }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) { resumeWaitingWifiTasks(); }
            };
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception ignored) {}
    }

    private void resumeWaitingWifiTasks() {
        if (isWifiOnly(this) && !isWifiConnected()) return;
        for (TaskInfo t : loadTasks(this)) {
            if ("WAITING_WIFI".equals(t.state)) {
                updateTask(t.id, x -> x.withState("QUEUED", ""));
            }
        }
        pumpQueue();
        refreshNotification();
    }

    public static int getMaxConcurrent(Context context) {
        int value = context.getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_MAX_CONCURRENT, 2);
        return Math.max(1, Math.min(3, value));
    }

    public static void setMaxConcurrent(Context context, int value) {
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_MAX_CONCURRENT, Math.max(1, Math.min(3, value))).apply();
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(ACTION_WAKE);
        startServiceCompat(context, i);
    }

    public static String detectMediaKind(String url, String mime) {
        String u = url == null ? "" : url.toLowerCase(Locale.ENGLISH);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ENGLISH);
        if (u.contains(".m3u8") || m.contains("mpegurl")) return "HLS";
        if (u.contains(".mpd") || m.contains("dash+xml")) return "DASH";
        return "DIRECT";
    }

    private static String streamFilename(String name) {
        String n = safeFilename(name);
        String lower = n.toLowerCase(Locale.ENGLISH);
        if (lower.endsWith(".m3u8")) n = n.substring(0, n.length() - 5);
        else if (lower.endsWith(".mpd")) n = n.substring(0, n.length() - 4);
        int q = n.indexOf('?'); if (q >= 0) n = n.substring(0, q);
        if (!n.toLowerCase(Locale.ENGLISH).endsWith(".mp4")) n += ".mp4";
        return safeFilename(n);
    }

    private static String formatScheduleTime(long when) {
        return new java.text.SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(new java.util.Date(when));
    }

    private void scheduleNextWake() {
        scheduleHandler.removeCallbacks(scheduleTick);
        long next = Long.MAX_VALUE;
        for (TaskInfo t : loadTasks(this)) if ("SCHEDULED".equals(t.state) && t.scheduledAt > 0) next = Math.min(next, t.scheduledAt);
        if (next == Long.MAX_VALUE) return;
        long delay = Math.max(1000L, Math.min(next - System.currentTimeMillis(), 60_000L));
        scheduleHandler.postDelayed(scheduleTick, delay);
        try {
            AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
            Intent wake = new Intent(this, DownloadAlarmReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, 8117, wake, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        } catch (Throwable ignored) {}
    }

    private static int normalizeRequestedSegments(int value) {
        return value == 1 || value == 4 || value == 8 || value == 16 || value == 32 ? value : 0;
    }

    private static String normalizeCategory(String value) {
        if (value == null) return "";
        String v = value.trim();
        String[] allowed = {"Videos", "Music", "Images", "Documents", "Apps", "Other"};
        for (String a : allowed) if (a.equalsIgnoreCase(v)) return a;
        return "";
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "INFIN8 Downloads", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Download progress and queue status");
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotification(String title, String text, int progress, boolean indeterminate) {
        Intent open = new Intent(this, DownloadsActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 20, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(com.infin8.browser.R.drawable.ic_download)
                .setContentTitle(title).setContentText(text).setContentIntent(pi)
                .setOnlyAlertOnce(true).setOngoing(hasActiveTasks()).setCategory(Notification.CATEGORY_PROGRESS);
        if (progress >= 0) b.setProgress(100, Math.max(0, Math.min(100, progress)), indeterminate);
        return b.build();
    }

    private boolean hasActiveTasks() {
        for (TaskInfo t : loadTasks(this)) {
            if ("DOWNLOADING".equals(t.state) || "QUEUED".equals(t.state) || "WAITING_WIFI".equals(t.state) || "WAITING_USA".equals(t.state) || "SCHEDULED".equals(t.state)) return true;
        }
        return false;
    }

    private void refreshNotification() {
        List<TaskInfo> tasks = loadTasks(this);
        int active = 0, waiting = 0, waitingUsa = 0, scheduled = 0, progress = -1;
        boolean indeterminate = false;
        for (TaskInfo t : tasks) {
            if ("WAITING_WIFI".equals(t.state)) waiting++;
            if ("WAITING_USA".equals(t.state)) waitingUsa++;
            if ("SCHEDULED".equals(t.state)) scheduled++;
            if ("DOWNLOADING".equals(t.state) || "QUEUED".equals(t.state) || "WAITING_WIFI".equals(t.state) || "WAITING_USA".equals(t.state)) active++;
            if (progress < 0 && "DOWNLOADING".equals(t.state)) {
                if (t.totalBytes > 0) progress = (int)Math.min(100L, (t.downloadedBytes * 100L) / t.totalBytes);
                else { progress = 0; indeterminate = true; }
            }
        }
        String text;
        if (waitingUsa > 0 && active == waitingUsa) text = waitingUsa + (waitingUsa == 1 ? " download waiting for USA verification" : " downloads waiting for USA verification");
        else if (waiting > 0 && active == waiting) text = waiting + (waiting == 1 ? " download waiting for Wi-Fi" : " downloads waiting for Wi-Fi");
        else if (active == 0 && scheduled > 0) text = scheduled + (scheduled == 1 ? " scheduled download" : " scheduled downloads");
        else text = active == 0 ? "No active downloads" : active + (active == 1 ? " active download" : " active downloads");
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification("INFIN8 Downloads", text, progress, indeterminate));
        if (active == 0 && scheduled == 0 && running.isEmpty()) {
            stopForeground(true);
            stopSelf();
        } else if (scheduled > 0) {
            scheduleNextWake();
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        scheduleHandler.removeCallbacksAndMessages(null);
        if (downloadUsaVerifier != null) downloadUsaVerifier.shutdown();
        taskPool.shutdownNow();
        try { if (connectivityManager != null && networkCallback != null) connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) {}
        super.onDestroy();
    }

    static final class Probe {
        final long totalBytes; final boolean acceptRanges;
        Probe(long totalBytes, boolean acceptRanges) { this.totalBytes = totalBytes; this.acceptRanges = acceptRanges; }
    }

    static final class PausedException extends Exception {}

    public static final class TaskInfo {
        public final String id, url, userAgent, filename, mime, state, outputPath, error, category, mediaKind, detail;
        public final long totalBytes, downloadedBytes, createdAt, lastPersistAt, scheduledAt;
        public final int segments, requestedSegments;

        TaskInfo(String id, String url, String userAgent, String filename, String mime, long totalBytes,
                 long downloadedBytes, String state, String outputPath, int segments, long createdAt, String error) {
            this(id, url, userAgent, filename, mime, totalBytes, downloadedBytes, state, outputPath, segments, createdAt, error,
                    System.currentTimeMillis(), 0, "", 0L, detectMediaKind(url, mime), "");
        }

        TaskInfo(String id, String url, String userAgent, String filename, String mime, long totalBytes,
                 long downloadedBytes, String state, String outputPath, int segments, long createdAt, String error, long lastPersistAt) {
            this(id, url, userAgent, filename, mime, totalBytes, downloadedBytes, state, outputPath, segments, createdAt, error,
                    lastPersistAt, 0, "", 0L, detectMediaKind(url, mime), "");
        }

        TaskInfo(String id, String url, String userAgent, String filename, String mime, long totalBytes,
                 long downloadedBytes, String state, String outputPath, int segments, long createdAt, String error, long lastPersistAt,
                 int requestedSegments, String category) {
            this(id, url, userAgent, filename, mime, totalBytes, downloadedBytes, state, outputPath, segments, createdAt, error,
                    lastPersistAt, requestedSegments, category, 0L, detectMediaKind(url, mime), "");
        }

        TaskInfo(String id, String url, String userAgent, String filename, String mime, long totalBytes,
                 long downloadedBytes, String state, String outputPath, int segments, long createdAt, String error, long lastPersistAt,
                 int requestedSegments, String category, long scheduledAt, String mediaKind, String detail) {
            this.id=id; this.url=url; this.userAgent=userAgent; this.filename=filename; this.mime=mime;
            this.totalBytes=totalBytes; this.downloadedBytes=downloadedBytes; this.state=state; this.outputPath=outputPath;
            this.segments=segments; this.createdAt=createdAt; this.error=error; this.lastPersistAt=lastPersistAt;
            this.requestedSegments=normalizeRequestedSegments(requestedSegments); this.category=normalizeCategory(category);
            this.scheduledAt=Math.max(0L, scheduledAt);
            this.mediaKind=(mediaKind == null || mediaKind.isEmpty()) ? detectMediaKind(url, mime) : mediaKind;
            this.detail=detail == null ? "" : detail;
        }

        TaskInfo withState(String state, String error) {
            return new TaskInfo(id,url,userAgent,filename,mime,totalBytes,downloadedBytes,state,outputPath,segments,createdAt,error,
                    lastPersistAt,requestedSegments,category,scheduledAt,mediaKind,detail);
        }

        TaskInfo withSchedule(long when, String state, String error) {
            return new TaskInfo(id,url,userAgent,filename,mime,totalBytes,downloadedBytes,state,outputPath,segments,createdAt,error,
                    lastPersistAt,requestedSegments,category,when,mediaKind,detail);
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id",id); o.put("url",url); o.put("ua",userAgent); o.put("name",filename); o.put("mime",mime);
            o.put("total",totalBytes); o.put("done",downloadedBytes); o.put("state",state); o.put("path",outputPath);
            o.put("segments",segments); o.put("created",createdAt); o.put("error",error); o.put("persist",lastPersistAt);
            o.put("requestedSegments", requestedSegments); o.put("category", category);
            o.put("scheduledAt", scheduledAt); o.put("mediaKind", mediaKind); o.put("detail", detail);
            return o;
        }

        static TaskInfo fromJson(JSONObject o) {
            String url = o.optString("url");
            String mime = o.optString("mime");
            return new TaskInfo(o.optString("id"), url, o.optString("ua"), o.optString("name","download.bin"),
                    mime, o.optLong("total",-1), o.optLong("done",0), o.optString("state","PAUSED"),
                    o.optString("path"), Math.max(1,o.optInt("segments",1)), o.optLong("created",0), o.optString("error"),
                    o.optLong("persist",0), o.optInt("requestedSegments",0), o.optString("category",""),
                    o.optLong("scheduledAt",0L), o.optString("mediaKind", detectMediaKind(url,mime)), o.optString("detail",""));
        }
    }
}