plugins {
    id("com.android.application")
}

val infin8KeystorePath = System.getenv("INFIN8_KEYSTORE_PATH")
val infin8KeystorePassword = System.getenv("INFIN8_KEYSTORE_PASSWORD")
val infin8KeyAlias = System.getenv("INFIN8_KEY_ALIAS")
val infin8KeyPassword = System.getenv("INFIN8_KEY_PASSWORD")
val hasInfin8ReleaseSigning = !infin8KeystorePath.isNullOrBlank()
        && !infin8KeystorePassword.isNullOrBlank()
        && !infin8KeyAlias.isNullOrBlank()
        && !infin8KeyPassword.isNullOrBlank()

android {
    namespace = "com.infin8.browser"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.infin8.browser"
        minSdk = 24
        targetSdk = 36
        versionCode = 27
        versionName = "2.5.0"
    }

    signingConfigs {
        if (hasInfin8ReleaseSigning) {
            create("infin8Release") {
                storeFile = file(infin8KeystorePath!!)
                storePassword = infin8KeystorePassword
                keyAlias = infin8KeyAlias
                keyPassword = infin8KeyPassword
            }
        }
    }

    val infin8ReleaseSigningConfig = signingConfigs.findByName("infin8Release")

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            // Keep shrinking off for the first release-candidate pass so the tested WebView/WireGuard
            // behavior stays identical. It can be enabled after signed-device regression testing.
            isMinifyEnabled = false
            isDebuggable = false
            infin8ReleaseSigningConfig?.let { signingConfig = it }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.17.1")
    implementation("androidx.core:core:1.17.0")
    implementation("com.wireguard.android:tunnel:1.0.20260102")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.3")
}
