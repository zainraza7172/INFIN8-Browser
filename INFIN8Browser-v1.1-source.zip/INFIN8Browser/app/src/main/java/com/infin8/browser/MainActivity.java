package com.infin8.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Typeface;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import com.wireguard.android.backend.Tunnel;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;

public class MainActivity extends Activity implements WireGuardManager.Listener {
    private static final String HOME_URL = "file:///android_asset/start.html";
    private static final int FILE_CHOOSER_REQUEST = 501;
    private static final int WG_CONFIG_REQUEST = 502;
    private static final int VPN_PERMISSION_REQUEST = 503;
    private static final long REVERIFY_INTERVAL_MS = 10L * 60L * 1000L;

    private final List<BrowserTab> tabs = new ArrayList<>();
    private int currentTab = -1;

    private FrameLayout webContainer;
    private LinearLayout navBar;
    private EditText addressBar;
    private ImageButton menuButton;
    private ProgressBar progressBar;
    private HorizontalScrollView tabStripScroll;
    private LinearLayout tabStrip;
    private Button bottomTabsButton;
    private Button bottomBackButton;
    private Button bottomSearchButton;
    private Button bottomForwardButton;
    private Button bottomCountButton;
    private Button bottomHomeButton;
    private Button bottomMenuButton;
    private ValueCallback<Uri[]> filePathCallback;
    private WireGuardManager wireGuard;
    private UsaNetworkVerifier usaVerifier;
    private boolean destroyed;
    private boolean usaVerified;
    private boolean webGateOpen;
    private String verificationSummary = "USA exit not verified";
    private String verifiedIp = "";
    private String verifiedLocation = "";
    private long lastVerifiedAt;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private OnBackInvokedCallback backInvokedCallback;
    private final Executor proxyExecutor = Runnable::run;
    private final Runnable periodicReverify = () -> {
        if (!destroyed && wireGuard != null && wireGuard.isConnected()) {
            verifyUsaExit(false);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Locale.setDefault(Locale.US);
        wireGuard = new WireGuardManager(this, this);
        usaVerifier = new UsaNetworkVerifier();
        setContentView(buildUi());
        registerModernBackHandler();
        closeWebGate("USA exit not verified", false);
        createTab(HOME_URL, true);
        updateUsaButton();

        if (wireGuard.hasConfig()) {
            webContainer.postDelayed(this::ensureVpnPermissionThenConnect, 350);
        }

        Intent incoming = getIntent();
        if (incoming != null && Intent.ACTION_VIEW.equals(incoming.getAction()) && incoming.getData() != null) {
            String requested = incoming.getData().toString();
            webContainer.postDelayed(() -> navigate(requested), 500);
        }
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF05080D);

        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER_VERTICAL);
        navBar.setBackgroundColor(0xFF0B0F16);
        navBar.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        navLp.setMargins(0, 0, 0, 0);
        navBar.setLayoutParams(navLp);

        LinearLayout addressShell = new LinearLayout(this);
        addressShell.setOrientation(LinearLayout.HORIZONTAL);
        addressShell.setGravity(Gravity.CENTER_VERTICAL);
        addressShell.setBackground(pillBackground(0xFF171D27, 15));
        addressShell.setPadding(dp(10), 0, dp(10), 0);
        addressShell.setLayoutParams(new LinearLayout.LayoutParams(0, dp(40), 1f));

        TextView searchGlyph = new TextView(this);
        searchGlyph.setText("⌕");
        searchGlyph.setTextColor(0xFF6F7DFF);
        searchGlyph.setTextSize(18);

        addressBar = new EditText(this);
        addressBar.setSingleLine(true);
        addressBar.setHint("Search Startpage or type URL");
        addressBar.setTextSize(14);
        addressBar.setTextColor(0xFFFFFFFF);
        addressBar.setHintTextColor(0xFF8E99AA);
        addressBar.setPadding(dp(10), 0, 0, 0);
        addressBar.setBackgroundColor(0x00000000);
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        addressShell.addView(searchGlyph);
        addressShell.addView(addressBar);

        menuButton = logoMenuButton();
        LinearLayout.LayoutParams menuParams = new LinearLayout.LayoutParams(dp(36), dp(36));
        menuParams.setMargins(dp(8), 0, 0, 0);
        menuButton.setLayoutParams(menuParams);
        menuButton.setContentDescription("Browser menu");

        navBar.addView(addressShell);
        navBar.addView(menuButton);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        webContainer = new FrameLayout(this);
        webContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabStrip.setGravity(Gravity.CENTER_VERTICAL);
        tabStrip.setPadding(dp(8), dp(2), dp(8), dp(5));

        tabStripScroll = new HorizontalScrollView(this);
        tabStripScroll.setHorizontalScrollBarEnabled(false);
        tabStripScroll.setFillViewport(false);
        tabStripScroll.addView(tabStrip, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)));

        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackground(darkRoundedBackground(0xFF080D15, 0, 0xFF1A2636, 1));
        bottomBar.setPadding(dp(8), dp(5), dp(8), dp(8));

        bottomHomeButton = bottomNavButton("⌂\nHome");
        bottomTabsButton = bottomNavButton("▤\nTabs");
        bottomSearchButton = bottomNavButton("⌕\nSearch");
        bottomMenuButton = bottomNavButton("☰\nMenu");

        bottomHomeButton.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomTabsButton.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomSearchButton.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomMenuButton.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        bottomBar.addView(bottomHomeButton);
        bottomBar.addView(bottomTabsButton);
        bottomBar.addView(bottomSearchButton);
        bottomBar.addView(bottomMenuButton);

        root.addView(navBar);
        root.addView(progressBar);
        root.addView(webContainer);
        root.addView(bottomBar);

        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate(addressBar.getText().toString());
                return true;
            }
            return false;
        });

        menuButton.setOnClickListener(this::showMainMenu);
        bottomHomeButton.setOnClickListener(v -> navigate(HOME_URL));
        bottomTabsButton.setOnClickListener(v -> showTabsDialog());
        bottomSearchButton.setOnClickListener(v -> {
            if (isOnHomePage()) {
                WebView w = currentWebView();
                if (w != null) w.evaluateJavascript("document.getElementById('q') && document.getElementById('q').focus();", null);
            } else {
                addressBar.requestFocus();
                addressBar.selectAll();
            }
        });
        bottomMenuButton.setOnClickListener(this::showMainMenu);

        return root;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(7), 0, dp(7), 0);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    private Button bottomNavButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        b.setTextColor(0xFFAAB4C3);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setGravity(Gravity.CENTER);
        b.setLines(2);
        b.setLineSpacing(dp(1), 1.0f);
        b.setPadding(0, dp(5), 0, dp(4));
        b.setBackgroundColor(0x00000000);
        return b;
    }

    private ImageButton logoMenuButton() {
        ImageButton b = new ImageButton(this);
        b.setScaleType(ImageView.ScaleType.CENTER_CROP);
        b.setAdjustViewBounds(true);
        b.setPadding(dp(3), dp(3), dp(3), dp(3));
        b.setBackground(pillBackground(0xFF111722, 12));
        try (InputStream is = getAssets().open("browser_logo.png")) {
            Bitmap bmp = BitmapFactory.decodeStream(is);
            b.setImageBitmap(bmp);
        } catch (Exception e) {
            b.setImageResource(android.R.drawable.ic_menu_more);
        }
        return b;
    }

    private void createTab(String initialUrl, boolean switchToIt) {
        WebView webView = new WebView(this);
        configureWebView(webView);
        BrowserTab tab = new BrowserTab(webView, "New Tab", initialUrl);
        tabs.add(tab);
        if (switchToIt) switchToTab(tabs.size() - 1);
        webView.loadUrl(initialUrl);
        updateTabCount();
        refreshTabStrip();
    }

    private void configureWebView(WebView webView) {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        installWebRtcShield(webView);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                if (!HOME_URL.equals(url)) addressBar.setText(url);
                updateNavState();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                BrowserTab tab = tabFor(view);
                if (tab != null) {
                    tab.url = url;
                    tab.title = view.getTitle() == null || view.getTitle().trim().isEmpty() ? url : view.getTitle();
                }
                if (view == currentWebView()) {
                    addressBar.setText(HOME_URL.equals(url) ? "" : url);
                }
                updateNavState();
                refreshTabStrip();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (!isInternetAllowed()) {
                        toast("USA exit must be verified before opening the internet.");
                        showUsaModeDialog();
                        return true;
                    }
                    return false;
                }
                if ("file".equalsIgnoreCase(scheme)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                BrowserTab tab = tabFor(view);
                if (tab != null && title != null) tab.title = title;
                refreshTabStrip();
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, false, false);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    toast("No file picker available.");
                    return false;
                }
            }
        });

        // Android's DownloadManager runs in a different package and could bypass an app-only VPN.
        // Keep downloads blocked in v0.2 instead of silently leaking traffic outside USA Mode.
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                toast("Downloads are temporarily disabled in USA Mode v0.5 to prevent VPN bypass."));
    }

    private void installWebRtcShield(WebView webView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        String script = "(() => { try {" +
                "Object.defineProperty(window,'RTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'webkitRTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'mozRTCPeerConnection',{value:undefined,configurable:false});" +
                "} catch(e) {} })();";
        try {
            WebViewCompat.addDocumentStartJavaScript(webView, script, Collections.singleton("*"));
        } catch (Exception ignored) {}
    }

    private void navigate(String input) {
        WebView webView = currentWebView();
        if (webView == null) return;
        String text = input == null ? "" : input.trim();
        if (text.isEmpty()) return;

        String url;
        if (HOME_URL.equals(text) || text.startsWith("file://")) {
            url = text;
        } else if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (text.matches("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}([/:?#].*)?$")) {
            url = "https://" + text;
        } else {
            url = "https://www.google.com/search?q=" + urlEncode(text);
        }

        if ((url.startsWith("http://") || url.startsWith("https://")) && !isInternetAllowed()) {
            toast("USA exit is not verified. Direct internet fallback is blocked.");
            showUsaModeDialog();
            return;
        }
        webView.loadUrl(url);
    }

    private void switchToTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        webContainer.removeAllViews();
        currentTab = index;
        WebView webView = tabs.get(index).webView;
        ViewGroup parent = (ViewGroup) webView.getParent();
        if (parent != null) parent.removeView(webView);
        webContainer.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        String url = webView.getUrl();
        addressBar.setText(url == null || HOME_URL.equals(url) ? "" : url);
        updateNavState();
        updateTabCount();
        refreshTabStrip();
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        BrowserTab tab = tabs.remove(index);
        if (tab.webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
        }
        tab.webView.stopLoading();
        tab.webView.destroy();

        if (tabs.isEmpty()) {
            currentTab = -1;
            createTab(HOME_URL, true);
            return;
        }
        int next = Math.min(index, tabs.size() - 1);
        switchToTab(next);
    }

    private void refreshTabStrip() {
        if (tabStrip == null) return;
        tabStrip.removeAllViews();

        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            BrowserTab tab = tabs.get(i);

            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), 0, dp(4), 0);
            chip.setBackground(pillBackground(index == currentTab ? 0xFFE7ECFF : 0xFFFFFFFF, 14));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(150), dp(34));
            cp.setMargins(0, 0, dp(7), 0);
            chip.setLayoutParams(cp);

            TextView title = new TextView(this);
            title.setText(shortTitleCompact(tab.title));
            title.setTextSize(12);
            title.setSingleLine(true);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setTextColor(0xFF111827);
            title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

            Button close = new Button(this);
            close.setText("×");
            close.setTextSize(17);
            close.setAllCaps(false);
            close.setMinWidth(0);
            close.setMinimumWidth(0);
            close.setPadding(0, 0, 0, 0);
            close.setBackgroundColor(0x00000000);
            close.setContentDescription("Close tab");
            close.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));

            View.OnClickListener openTab = v -> switchToTab(index);
            chip.setOnClickListener(openTab);
            title.setOnClickListener(openTab);
            close.setOnClickListener(v -> closeTab(index));

            chip.addView(title);
            chip.addView(close);
            tabStrip.addView(chip);
        }

        Button plus = new Button(this);
        plus.setText("+");
        plus.setTextSize(18);
        plus.setAllCaps(false);
        plus.setMinWidth(0);
        plus.setMinimumWidth(0);
        plus.setPadding(0, 0, 0, 0);
        plus.setBackground(pillBackground(0xFFF1F3F7, 17));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(38), dp(34));
        plus.setLayoutParams(pp);
        plus.setOnClickListener(v -> createTab(HOME_URL, true));
        tabStrip.addView(plus);

        if (tabStripScroll != null && currentTab >= 0) {
            tabStripScroll.post(() -> {
                int x = Math.max(0, currentTab * dp(157) - dp(24));
                tabStripScroll.smoothScrollTo(x, 0);
            });
        }
    }

    private GradientDrawable pillBackground(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), 0xFFE1E5EC);
        return d;
    }

    private GradientDrawable darkRoundedBackground(int color, int radiusDp, int strokeColor, int strokeWidthDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeWidthDp > 0) d.setStroke(dp(strokeWidthDp), strokeColor);
        return d;
    }

    private TextView dialogText(String text, float sizeSp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sizeSp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private TextView menuRow(String icon, String label, boolean enabled) {
        TextView row = dialogText(icon + "   " + label + "                                      ›", 16, enabled ? 0xFFF4F7FB : 0xFF566174, Typeface.NORMAL);
        row.setSingleLine(true);
        row.setPadding(dp(18), 0, dp(12), 0);
        row.setBackground(darkRoundedBackground(0xFF0E1724, 18, enabled ? 0xFF1E3552 : 0xFF172231, 1));
        row.setAlpha(enabled ? 1f : 0.55f);
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        return row;
    }

    private String shortTitleCompact(String title) {
        if (title == null || title.trim().isEmpty() || HOME_URL.equals(title)) return "New Tab";
        String clean = title.replace("INFIN8 — ", "").trim();
        return clean.length() > 18 ? clean.substring(0, 18) + "…" : clean;
    }

    private void showMainMenu(View anchor) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackground(darkRoundedBackground(0xFF08111D, 24, 0xFF2587FF, 1));

        WebView w = currentWebView();
        boolean canBack = w != null && w.canGoBack();
        boolean canForward = w != null && w.canGoForward();

        TextView back = menuRow("←", "Back", canBack);
        TextView forward = menuRow("→", "Forward", canForward);
        TextView reload = menuRow("↻", "Reload", w != null);
        TextView home = menuRow("⌂", "Home", true);
        TextView newTab = menuRow("＋", "New tab", true);
        TextView tabsRow = menuRow("▣", "Tabs", true);
        TextView usa = menuRow("🇺🇸", "USA network", true);
        TextView ip = menuRow("◎", "Check US IP", true);

        TextView[] rows = {back, forward, reload, home, newTab, tabsRow, usa, ip};
        for (int i = 0; i < rows.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
            if (i > 0) lp.setMargins(0, dp(6), 0, 0);
            rows[i].setLayoutParams(lp);
            panel.addView(rows[i]);
        }

        back.setOnClickListener(v -> { if (canBack) { dialog.dismiss(); handleBackNavigation(false); } });
        forward.setOnClickListener(v -> { if (canForward && w != null) { dialog.dismiss(); w.goForward(); } });
        reload.setOnClickListener(v -> { if (w != null) { dialog.dismiss(); w.reload(); } });
        home.setOnClickListener(v -> { dialog.dismiss(); navigate(HOME_URL); });
        newTab.setOnClickListener(v -> { dialog.dismiss(); createTab(HOME_URL, true); });
        tabsRow.setOnClickListener(v -> { dialog.dismiss(); showTabsDialog(); });
        usa.setOnClickListener(v -> { dialog.dismiss(); showUsaModeDialog(); });
        ip.setOnClickListener(v -> { dialog.dismiss(); openIpCheck(); });

        dialog.setContentView(panel);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0x00000000));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = dp(330);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.END | Gravity.BOTTOM;
            lp.dimAmount = 0.34f;
            lp.x = dp(12);
            lp.y = dp(72);
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void showTabsDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(darkRoundedBackground(0xFF07111E, 24, 0xFF2587FF, 1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = dialogText("Tabs", 27, 0xFFFFFFFF, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 1f));
        TextView closeDialog = dialogText("×", 32, 0xFFEAF2FF, Typeface.NORMAL);
        closeDialog.setGravity(Gravity.CENTER);
        closeDialog.setBackground(darkRoundedBackground(0xFF10233A, 24, 0xFF1E6EC8, 1));
        closeDialog.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
        closeDialog.setOnClickListener(v -> dialog.dismiss());
        header.addView(title);
        header.addView(closeDialog);
        card.addView(header);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        listLp.setMargins(0, dp(16), 0, 0);
        list.setLayoutParams(listLp);

        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            BrowserTab tab = tabs.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(8), dp(10), dp(8));
            row.setBackground(darkRoundedBackground(index == currentTab ? 0xFF0F233A : 0xFF0C1827, 18, index == currentTab ? 0xFF2587FF : 0xFF1C3552, 1));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72));
            if (i > 0) rowLp.setMargins(0, dp(8), 0, 0);
            row.setLayoutParams(rowLp);

            ImageView icon = new ImageView(this);
            icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
            icon.setBackground(darkRoundedBackground(0xFF000000, 12, 0xFF152B45, 1));
            try (InputStream is = getAssets().open("browser_logo.png")) {
                icon.setImageBitmap(BitmapFactory.decodeStream(is));
            } catch (Exception ignored) {}
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(44), dp(44));
            iconLp.setMargins(0, 0, dp(12), 0);
            icon.setLayoutParams(iconLp);

            TextView tabTitle = dialogText(shortTitle(tab.title), 16, 0xFFF4F7FB, Typeface.NORMAL);
            tabTitle.setSingleLine(true);
            tabTitle.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

            TextView closeTabButton = dialogText("×", 28, 0xFFDDEBFF, Typeface.NORMAL);
            closeTabButton.setGravity(Gravity.CENTER);
            closeTabButton.setBackground(darkRoundedBackground(0xFF10243B, 22, 0xFF1A4F83, 1));
            closeTabButton.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));

            row.setOnClickListener(v -> { switchToTab(index); dialog.dismiss(); });
            tabTitle.setOnClickListener(v -> { switchToTab(index); dialog.dismiss(); });
            closeTabButton.setOnClickListener(v -> { dialog.dismiss(); closeTab(index); });

            row.addView(icon);
            row.addView(tabTitle);
            row.addView(closeTabButton);
            list.addView(row);
        }
        card.addView(list);

        View divider = new View(this);
        divider.setBackgroundColor(0xFF1A2B42);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        divLp.setMargins(0, dp(18), 0, dp(16));
        divider.setLayoutParams(divLp);
        card.addView(divider);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView close = dialogText("Close", 16, 0xFF67A9FF, Typeface.BOLD);
        close.setGravity(Gravity.CENTER);
        close.setBackground(darkRoundedBackground(0xFF0E1D2F, 24, 0xFF1A3555, 1));
        close.setLayoutParams(new LinearLayout.LayoutParams(0, dp(54), 1f));
        close.setOnClickListener(v -> dialog.dismiss());

        TextView newTab = dialogText("＋  New Tab", 16, 0xFFFFFFFF, Typeface.BOLD);
        newTab.setGravity(Gravity.CENTER);
        newTab.setBackground(darkRoundedBackground(0xFF0967E8, 24, 0xFF36A3FF, 1));
        LinearLayout.LayoutParams newLp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        newLp.setMargins(dp(12), 0, 0, 0);
        newTab.setLayoutParams(newLp);
        newTab.setOnClickListener(v -> { dialog.dismiss(); createTab(HOME_URL, true); });

        actions.addView(close);
        actions.addView(newTab);
        card.addView(actions);

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0x00000000));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(36), dp(430));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = 0.48f;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void showUsaModeDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22), dp(8), dp(22), 0);

        TextView status = new TextView(this);
        String stateText;
        if (wireGuard.isConnected() && usaVerified && webGateOpen) stateText = "🟢 USA verified";
        else if (wireGuard.isConnected()) stateText = "🟡 Connected • browsing blocked";
        else stateText = "⚪ Disconnected";
        status.setText(stateText + "\n" + wireGuard.getServerLabel());
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(10));

        TextView description = new TextView(this);
        description.setText("v0.5 automatically verifies the VPN exit country. Internet pages stay blocked until the exit is confirmed as United States. The imported .conf remains encrypted locally with Android Keystore.");
        description.setTextSize(13);
        description.setPadding(0, dp(4), 0, dp(10));

        Button remove = new Button(this);
        remove.setAllCaps(false);
        remove.setText("Remove imported VPN profile");
        remove.setEnabled(wireGuard.hasConfig());

        TextView verification = new TextView(this);
        verification.setText("Security gate: " + verificationSummary
                + (verifiedIp.isEmpty() ? "" : "\nIP: " + verifiedIp)
                + (verifiedLocation.isEmpty() ? "" : "\nLocation: " + verifiedLocation));
        verification.setTextSize(13);
        verification.setPadding(0, dp(6), 0, dp(8));

        Button verifyNow = new Button(this);
        verifyNow.setAllCaps(false);
        verifyNow.setText("Verify USA exit now");
        verifyNow.setEnabled(wireGuard.isConnected());

        TextView note = new TextView(this);
        note.setText("Long-press 🇺🇸 to open a public IP page after verification. Top tab strip supports quick switching and each tab has its own × close button. If verification fails, WebView traffic is also blocked with a local process-level proxy gate to prevent direct fallback.");
        note.setTextSize(12);
        note.setPadding(0, dp(10), 0, 0);

        layout.addView(status);
        layout.addView(description);
        layout.addView(verification);
        layout.addView(verifyNow);
        layout.addView(remove);
        layout.addView(note);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("🇺🇸 USA WireGuard")
                .setView(layout)
                .setPositiveButton(wireGuard.isConnected() ? "Disconnect" : "Connect", null)
                .setNeutralButton("Import .conf", null)
                .setNegativeButton("Close", null)
                .create();

        verifyNow.setOnClickListener(v -> {
            dialog.dismiss();
            verifyUsaExit(true);
        });

        remove.setOnClickListener(v -> {
            closeWebGate("VPN profile removed", true);
            wireGuard.clearConfig();
            updateUsaButton();
            toast("Imported VPN profile removed");
            dialog.dismiss();
        });

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (wireGuard.isConnected()) {
                    closeWebGate("USA Mode disconnected", true);
                    wireGuard.disconnect();
                    dialog.dismiss();
                    return;
                }
                if (!wireGuard.hasConfig()) {
                    toast("Import your Proton US WireGuard .conf first.");
                    return;
                }
                dialog.dismiss();
                ensureVpnPermissionThenConnect();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                dialog.dismiss();
                chooseWireGuardConfig();
            });
        });
        dialog.show();
    }

    private void chooseWireGuardConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "application/octet-stream"});
        startActivityForResult(intent, WG_CONFIG_REQUEST);
    }

    private void importWireGuardConfig(Uri uri) {
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("Could not read selected file");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int read;
            while ((read = input.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                if (out.size() > 128 * 1024) throw new IllegalArgumentException("Configuration file is too large");
            }
            String raw = out.toString(StandardCharsets.UTF_8.name());
            wireGuard.importConfig(raw);
            updateUsaButton();
            toast("WireGuard profile imported securely");
            ensureVpnPermissionThenConnect();
        } catch (Exception e) {
            toast("Import failed: " + safeMessage(e));
        }
    }

    private void ensureVpnPermissionThenConnect() {
        if (!wireGuard.hasConfig()) {
            showUsaModeDialog();
            return;
        }
        Intent permission = wireGuard.getVpnPermissionIntent();
        if (permission == null) {
            closeWebGate("Connecting USA Mode…", false);
            toast("Connecting USA Mode…");
            wireGuard.connect();
        } else {
            startActivityForResult(permission, VPN_PERMISSION_REQUEST);
        }
    }

    private void openIpCheck() {
        if (!isInternetAllowed()) {
            toast("USA exit must be verified first.");
            showUsaModeDialog();
            return;
        }
        navigate("https://ipinfo.io/");
    }

    private void updateUsaButton() {
        // USA/WireGuard controls live in the overflow menu in v0.5.
    }

    private void updateNavState() {
        if (navBar != null) navBar.setVisibility(isOnHomePage() ? View.GONE : View.VISIBLE);
        if (bottomHomeButton != null) bottomHomeButton.setTextColor(isOnHomePage() ? 0xFF58A6FF : 0xFFAAB4C3);
        if (bottomTabsButton != null) bottomTabsButton.setTextColor(0xFFAAB4C3);
        if (bottomSearchButton != null) bottomSearchButton.setTextColor(0xFFAAB4C3);
        if (bottomMenuButton != null) bottomMenuButton.setTextColor(0xFFAAB4C3);
    }

    private void updateTabCount() {
        // Tab count is available in the Tabs dialog; keep the bottom bar minimal.
    }

    private boolean isOnHomePage() {
        WebView w = currentWebView();
        String url = w == null ? null : w.getUrl();
        return url == null || HOME_URL.equals(url) || url.startsWith(HOME_URL);
    }

    private BrowserTab tabFor(WebView webView) {
        for (BrowserTab tab : tabs) if (tab.webView == webView) return tab;
        return null;
    }

    private WebView currentWebView() {
        if (currentTab < 0 || currentTab >= tabs.size()) return null;
        return tabs.get(currentTab).webView;
    }

    private String shortTitle(String title) {
        if (title == null || title.trim().isEmpty()) return "New Tab";
        return title.length() > 36 ? title.substring(0, 36) + "…" : title;
    }

    private String urlEncode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception ignored) {
            return value.replace(" ", "+");
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        if (!destroyed) Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String safeMessage(Throwable error) {
        if (error == null) return "Unknown error";
        String message = error.getMessage();
        if (message == null || message.trim().isEmpty()) return error.getClass().getSimpleName();
        // Never echo configuration text/private keys into the UI.
        return message.length() > 160 ? message.substring(0, 160) : message;
    }

    @Override
    public void onStateChanged(Tunnel.State state) {
        runOnUiThread(() -> {
            if (destroyed) return;
            if (state == Tunnel.State.UP) {
                usaVerified = false;
                verifiedIp = "";
                verifiedLocation = "";
                verificationSummary = "WireGuard connected; verifying USA exit…";
                closeWebGate(verificationSummary, false);
                updateUsaButton();
                toast("WireGuard connected • verifying USA exit…");
                verifyUsaExit(true);
            } else if (state == Tunnel.State.DOWN) {
                mainHandler.removeCallbacks(periodicReverify);
                usaVerified = false;
                verifiedIp = "";
                verifiedLocation = "";
                verificationSummary = "VPN tunnel is disconnected";
                closeWebGate(verificationSummary, true);
                updateUsaButton();
            }
        });
    }

    @Override
    public void onError(String message, Throwable error) {
        runOnUiThread(() -> {
            if (destroyed) return;
            usaVerified = false;
            verificationSummary = message;
            closeWebGate(message, true);
            updateUsaButton();
            toast(message + ": " + safeMessage(error));
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) {
                closeWebGate("Connecting USA Mode…", false);
                toast("Connecting USA Mode…");
                wireGuard.connect();
            } else {
                toast("VPN permission is required for USA Mode.");
            }
            return;
        }

        if (requestCode == WG_CONFIG_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importWireGuardConfig(data.getData());
            }
            return;
        }

        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wireGuard != null && wireGuard.isConnected() && usaVerified
                && System.currentTimeMillis() - lastVerifiedAt > REVERIFY_INTERVAL_MS) {
            verifyUsaExit(false);
        }
    }

    private boolean isInternetAllowed() {
        return wireGuard != null && wireGuard.isConnected() && usaVerified && webGateOpen;
    }

    private void verifyUsaExit(boolean announce) {
        if (destroyed || wireGuard == null || !wireGuard.isConnected()) {
            usaVerified = false;
            verificationSummary = "VPN tunnel is not connected";
            closeWebGate(verificationSummary, true);
            updateUsaButton();
            return;
        }

        boolean alreadyVerified = usaVerified && webGateOpen;
        if (!alreadyVerified) {
            usaVerified = false;
            verificationSummary = "Checking current VPN exit country…";
            closeWebGate(verificationSummary, false);
            updateUsaButton();
        }

        usaVerifier.verify(result -> runOnUiThread(() -> {
            if (destroyed || wireGuard == null || !wireGuard.isConnected()) return;

            verifiedIp = result.ip;
            verifiedLocation = result.location;
            verificationSummary = result.detail;

            if (result.verifiedUsa) {
                usaVerified = true;
                lastVerifiedAt = System.currentTimeMillis();
                openWebGate(() -> {
                    updateUsaButton();
                    if (announce) toast("🇺🇸 USA exit verified" + (verifiedIp.isEmpty() ? "" : " • " + verifiedIp));
                });
                mainHandler.removeCallbacks(periodicReverify);
                mainHandler.postDelayed(periodicReverify, REVERIFY_INTERVAL_MS);
            } else {
                usaVerified = false;
                closeWebGate(verificationSummary, true);
                updateUsaButton();
                toast("USA verification failed. Browsing remains blocked.");
            }
        }));
    }

    private void openWebGate(Runnable afterOpen) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            webGateOpen = true;
            if (afterOpen != null) afterOpen.run();
            return;
        }
        try {
            ProxyController.getInstance().clearProxyOverride(proxyExecutor, () -> runOnUiThread(() -> {
                if (destroyed) return;
                webGateOpen = true;
                if (afterOpen != null) afterOpen.run();
            }));
        } catch (Exception e) {
            webGateOpen = false;
            usaVerified = false;
            verificationSummary = "Could not open the secure WebView gate";
            updateUsaButton();
            toast("Secure browsing gate error: " + safeMessage(e));
        }
    }

    private void closeWebGate(String reason, boolean returnInternetTabsHome) {
        webGateOpen = false;
        if (reason != null && !reason.trim().isEmpty()) verificationSummary = reason;

        if (returnInternetTabsHome) {
            for (BrowserTab tab : tabs) {
                String current = tab.webView.getUrl();
                if (current != null && (current.startsWith("http://") || current.startsWith("https://"))) {
                    tab.webView.stopLoading();
                    tab.webView.loadUrl(HOME_URL);
                }
            }
        }

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return;
        try {
            ProxyConfig blocked = new ProxyConfig.Builder()
                    .addProxyRule("http://127.0.0.1:9")
                    .build();
            ProxyController.getInstance().setProxyOverride(blocked, proxyExecutor, () -> { });
        } catch (Exception ignored) {
            // Software navigation checks remain active even if this WebView feature is unavailable at runtime.
        }
    }

    private void registerModernBackHandler() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            backInvokedCallback = () -> handleBackNavigation(true);
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backInvokedCallback);
        }
    }

    private boolean handleBackNavigation(boolean allowBackground) {
        WebView w = currentWebView();
        if (w != null && w.canGoBack()) {
            w.goBack();
            return true;
        }

        if (w != null) {
            String url = w.getUrl();
            if (url != null && !HOME_URL.equals(url)) {
                w.loadUrl(HOME_URL);
                return true;
            }
        }

        if (tabs.size() > 1) {
            closeTab(currentTab);
            return true;
        }

        if (allowBackground) {
            moveTaskToBack(true);
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        handleBackNavigation(true);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backInvokedCallback != null) {
            try {
                getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backInvokedCallback);
            } catch (Exception ignored) {}
            backInvokedCallback = null;
        }
        mainHandler.removeCallbacks(periodicReverify);
        if (usaVerifier != null) usaVerifier.shutdown();
        if (wireGuard != null) {
            wireGuard.disconnect();
            wireGuard.shutdown();
        }
        for (BrowserTab tab : tabs) {
            if (tab.webView.getParent() instanceof ViewGroup) {
                ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
            }
            tab.webView.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }

    private static final class BrowserTab {
        final WebView webView;
        String title;
        String url;

        BrowserTab(WebView webView, String title, String url) {
            this.webView = webView;
            this.title = title;
            this.url = url;
        }
    }
}
