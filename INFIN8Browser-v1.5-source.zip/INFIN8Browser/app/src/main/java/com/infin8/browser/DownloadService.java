package com.infin8.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.webkit.URLUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * INFIN8 in-process downloader. It intentionally avoids Android DownloadManager so
 * download traffic remains inside this app package and follows INFIN8's app-routed VPN.
 *
 * Current engine: HTTP/HTTPS direct files, dynamic range segmentation (up to 16 parts),
 * pause/resume, retry recovery, queueing, speed limiting and automatic categories.
 */
public final class DownloadService extends Service {
    public static final String ACTION_ADD = "com.infin8.browser.download.ADD";
    public static final String ACTION_PAUSE = "com.infin8.browser.download.PAUSE";
    public static final String ACTION_RESUME = "com.infin8.browser.download.RESUME";
    public static final String ACTION_CANCEL = "com.infin8.browser.download.CANCEL";
    public static final String ACTION_RETRY = "com.infin8.browser.download.RETRY";

    public static final String EXTRA_ID = "id";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_USER_AGENT = "ua";
    public static final String EXTRA_CONTENT_DISPOSITION = "content_disposition";
    public static final String EXTRA_MIME = "mime";
    public static final String EXTRA_LENGTH = "length";

    private static final String CHANNEL_ID = "infin8_downloads";
    private static final int NOTIFICATION_ID = 8010;
    private static final String PREFS = "infin8_downloads";
    private static final String KEY_TASKS = "tasks";
    public static final String KEY_SPEED_LIMIT_KBPS = "speed_limit_kbps";

    private final ExecutorService taskPool = Executors.newFixedThreadPool(2);
    private final Map<String, AtomicBoolean> pauseFlags = new ConcurrentHashMap<>();
    private final Map<String, Future<?>> running = new ConcurrentHashMap<>();
    private final Object persistLock = new Object();
    private final Object rateLock = new Object();
    private long rateWindowStarted = System.currentTimeMillis();
    private long rateWindowBytes;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Downloads ready", "INFIN8 download manager"));
        recoverInterruptedTasks();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_ADD.equals(action)) {
            addTask(intent);
        } else if (ACTION_PAUSE.equals(action)) {
            pauseTask(intent.getStringExtra(EXTRA_ID));
        } else if (ACTION_RESUME.equals(action) || ACTION_RETRY.equals(action)) {
            resumeTask(intent.getStringExtra(EXTRA_ID));
        } else if (ACTION_CANCEL.equals(action)) {
            cancelTask(intent.getStringExtra(EXTRA_ID));
        }
        refreshNotification();
        return START_STICKY;
    }

    public static void enqueue(Context context, String url, String userAgent, String contentDisposition, String mime, long length) {
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(ACTION_ADD);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_USER_AGENT, userAgent == null ? "" : userAgent);
        i.putExtra(EXTRA_CONTENT_DISPOSITION, contentDisposition == null ? "" : contentDisposition);
        i.putExtra(EXTRA_MIME, mime == null ? "" : mime);
        i.putExtra(EXTRA_LENGTH, length);
        startServiceCompat(context, i);
    }

    public static void command(Context context, String action, String id) {
        Intent i = new Intent(context, DownloadService.class);
        i.setAction(action);
        i.putExtra(EXTRA_ID, id);
        startServiceCompat(context, i);
    }

    private static void startServiceCompat(Context context, Intent i) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
        else context.startService(i);
    }

    private void addTask(Intent intent) {
        String url = intent.getStringExtra(EXTRA_URL);
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return;
        String ua = intent.getStringExtra(EXTRA_USER_AGENT);
        String disposition = intent.getStringExtra(EXTRA_CONTENT_DISPOSITION);
        String mime = intent.getStringExtra(EXTRA_MIME);
        long length = intent.getLongExtra(EXTRA_LENGTH, -1L);
        String name = safeFilename(URLUtil.guessFileName(url, disposition, mime));
        TaskInfo task = new TaskInfo(UUID.randomUUID().toString(), url, ua, name, mime, length, 0L, "QUEUED", "", 1, System.currentTimeMillis(), "");
        List<TaskInfo> tasks = loadTasks(this);
        tasks.add(0, task);
        saveTasks(this, tasks);
        submit(task.id);
    }

    private void pauseTask(String id) {
        if (id == null) return;
        pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean()).set(true);
        updateTask(id, t -> t.withState("PAUSED", t.error));
    }

    private void resumeTask(String id) {
        if (id == null) return;
        AtomicBoolean flag = pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean());
        flag.set(false);
        updateTask(id, t -> t.withState("QUEUED", ""));
        submit(id);
    }

    private void cancelTask(String id) {
        if (id == null) return;
        pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean()).set(true);
        Future<?> f = running.remove(id);
        if (f != null) f.cancel(true);
        TaskInfo task = findTask(id);
        if (task != null) cleanupTaskFiles(task);
        updateTask(id, t -> t.withState("CANCELLED", ""));
    }

    private void submit(String id) {
        if (id == null || running.containsKey(id)) return;
        Future<?> f = taskPool.submit(() -> {
            try {
                runTask(id);
            } finally {
                running.remove(id);
                refreshNotification();
            }
        });
        running.put(id, f);
    }

    private void runTask(String id) {
        TaskInfo task = findTask(id);
        if (task == null) return;
        AtomicBoolean pause = pauseFlags.computeIfAbsent(id, k -> new AtomicBoolean(false));
        if (pause.get()) return;

        try {
            Probe probe = probe(task.url, task.userAgent, task.totalBytes);
            long total = probe.totalBytes > 0 ? probe.totalBytes : task.totalBytes;
            int segments = chooseSegmentCount(total, probe.acceptRanges);
            File categoryDir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), categoryFor(task.filename, task.mime));
            if (!categoryDir.exists() && !categoryDir.mkdirs()) throw new IllegalStateException("Could not create downloads folder");
            File finalFile = uniqueFinalFile(categoryDir, task.filename, task.outputPath);
            String outputPath = finalFile.getAbsolutePath();

            task = new TaskInfo(task.id, task.url, task.userAgent, finalFile.getName(), task.mime, total, task.downloadedBytes,
                    "DOWNLOADING", outputPath, segments, task.createdAt, "");
            replaceTask(task);

            if (segments > 1 && total > 0) {
                downloadSegmented(task, pause);
            } else {
                downloadSingle(task, pause);
            }

            if (pause.get()) {
                updateTask(id, t -> t.withState("PAUSED", ""));
                return;
            }
            updateTask(id, t -> new TaskInfo(t.id, t.url, t.userAgent, t.filename, t.mime, t.totalBytes,
                    t.totalBytes > 0 ? t.totalBytes : t.downloadedBytes, "COMPLETED", t.outputPath, t.segments, t.createdAt, ""));
        } catch (PausedException e) {
            updateTask(id, t -> t.withState("PAUSED", ""));
        } catch (Throwable e) {
            updateTask(id, t -> t.withState("FAILED", safeError(e)));
        }
    }

    private void downloadSegmented(TaskInfo task, AtomicBoolean pause) throws Exception {
        int segments = Math.max(2, task.segments);
        File finalFile = new File(task.outputPath);
        File tempDir = new File(finalFile.getParentFile(), ".infin8_" + task.id);
        if (!tempDir.exists() && !tempDir.mkdirs()) throw new IllegalStateException("Could not create temporary download folder");

        long piece = task.totalBytes / segments;
        AtomicLong downloaded = new AtomicLong(0L);
        for (int i = 0; i < segments; i++) {
            File part = new File(tempDir, "part_" + i);
            downloaded.addAndGet(part.exists() ? part.length() : 0L);
        }
        publishProgress(task.id, downloaded.get(), task.totalBytes);

        ExecutorService segmentPool = Executors.newFixedThreadPool(Math.min(8, segments));
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < segments; i++) {
            final int index = i;
            final long start = i * piece;
            final long end = (i == segments - 1) ? task.totalBytes - 1 : (start + piece - 1);
            futures.add(segmentPool.submit(() -> {
                try {
                    downloadRange(task, tempDir, index, start, end, pause, downloaded);
                } catch (PausedException e) {
                    throw new RuntimeException(e);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }));
        }

        Throwable failure = null;
        for (Future<?> future : futures) {
            try { future.get(); }
            catch (Throwable e) { failure = e.getCause() == null ? e : e.getCause(); break; }
        }
        if (failure != null) {
            pause.set(pause.get());
            segmentPool.shutdownNow();
            if (containsPaused(failure) || pause.get()) throw new PausedException();
            if (failure instanceof Exception) throw (Exception) failure;
            throw new RuntimeException(failure);
        }
        segmentPool.shutdown();
        if (pause.get()) throw new PausedException();

        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(finalFile, false))) {
            byte[] buffer = new byte[64 * 1024];
            for (int i = 0; i < segments; i++) {
                File part = new File(tempDir, "part_" + i);
                try (InputStream in = new BufferedInputStream(new FileInputStream(part))) {
                    int n;
                    while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
                }
            }
        }
        deleteRecursively(tempDir);
    }

    private void downloadRange(TaskInfo task, File tempDir, int index, long start, long end,
                               AtomicBoolean pause, AtomicLong downloaded) throws Exception {
        File part = new File(tempDir, "part_" + index);
        long expected = end - start + 1;
        long have = part.exists() ? part.length() : 0L;
        if (have >= expected) return;

        int attempt = 0;
        while (attempt < 4) {
            attempt++;
            if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
            HttpURLConnection c = null;
            try {
                long rangeStart = start + have;
                c = open(task.url, task.userAgent);
                c.setRequestProperty("Range", "bytes=" + rangeStart + "-" + end);
                c.connect();
                int code = c.getResponseCode();
                if (code != HttpURLConnection.HTTP_PARTIAL) throw new IllegalStateException("Server stopped supporting range requests");
                try (InputStream in = new BufferedInputStream(c.getInputStream());
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(part, true))) {
                    byte[] buffer = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buffer)) >= 0) {
                        if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
                        throttle(n);
                        out.write(buffer, 0, n);
                        have += n;
                        long now = downloaded.addAndGet(n);
                        publishProgress(task.id, now, task.totalBytes);
                    }
                }
                if (have >= expected) return;
            } catch (PausedException e) {
                throw e;
            } catch (Exception e) {
                if (attempt >= 4) throw e;
                try { Thread.sleep(700L * attempt); } catch (InterruptedException ie) { throw new PausedException(); }
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private void downloadSingle(TaskInfo task, AtomicBoolean pause) throws Exception {
        File finalFile = new File(task.outputPath);
        File part = new File(finalFile.getAbsolutePath() + ".part");
        long have = part.exists() ? part.length() : 0L;
        int attempt = 0;
        while (attempt < 4) {
            attempt++;
            if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
            HttpURLConnection c = null;
            try {
                c = open(task.url, task.userAgent);
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                c.connect();
                int code = c.getResponseCode();
                boolean append = have > 0 && code == HttpURLConnection.HTTP_PARTIAL;
                if (have > 0 && !append) have = 0;
                try (InputStream in = new BufferedInputStream(c.getInputStream());
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(part, append))) {
                    byte[] buffer = new byte[64 * 1024];
                    int n;
                    long progress = have;
                    while ((n = in.read(buffer)) >= 0) {
                        if (pause.get() || Thread.currentThread().isInterrupted()) throw new PausedException();
                        throttle(n);
                        out.write(buffer, 0, n);
                        progress += n;
                        publishProgress(task.id, progress, task.totalBytes);
                    }
                }
                if (!part.renameTo(finalFile)) {
                    copy(part, finalFile);
                    part.delete();
                }
                return;
            } catch (PausedException e) {
                throw e;
            } catch (Exception e) {
                if (attempt >= 4) throw e;
                try { Thread.sleep(700L * attempt); } catch (InterruptedException ie) { throw new PausedException(); }
                have = part.exists() ? part.length() : 0L;
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    private Probe probe(String url, String ua, long knownLength) throws Exception {
        HttpURLConnection c = open(url, ua);
        c.setRequestMethod("HEAD");
        try {
            c.connect();
            int code = c.getResponseCode();
            if (code >= 200 && code < 400) {
                long total = c.getContentLengthLong();
                String ranges = c.getHeaderField("Accept-Ranges");
                boolean accept = ranges != null && ranges.toLowerCase(Locale.ENGLISH).contains("bytes");
                return new Probe(total > 0 ? total : knownLength, accept);
            }
        } finally {
            c.disconnect();
        }

        HttpURLConnection range = open(url, ua);
        range.setRequestProperty("Range", "bytes=0-0");
        try {
            range.connect();
            int code = range.getResponseCode();
            boolean accept = code == HttpURLConnection.HTTP_PARTIAL;
            long total = knownLength;
            String contentRange = range.getHeaderField("Content-Range");
            if (contentRange != null && contentRange.contains("/")) {
                try { total = Long.parseLong(contentRange.substring(contentRange.lastIndexOf('/') + 1).trim()); } catch (Exception ignored) {}
            }
            if (total <= 0) total = range.getContentLengthLong();
            return new Probe(total, accept);
        } finally {
            range.disconnect();
        }
    }

    private HttpURLConnection open(String rawUrl, String ua) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(rawUrl).openConnection();
        c.setConnectTimeout(15_000);
        c.setReadTimeout(30_000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", ua == null || ua.isEmpty() ? "INFIN8 Browser" : ua);
        c.setRequestProperty("Accept-Encoding", "identity");
        return c;
    }

    private int chooseSegmentCount(long total, boolean acceptRanges) {
        if (!acceptRanges || total <= 2L * 1024L * 1024L) return 1;
        if (total < 25L * 1024L * 1024L) return 4;
        if (total < 250L * 1024L * 1024L) return 8;
        if (total < 1024L * 1024L * 1024L) return 16;
        return 32;
    }

    private void throttle(int bytes) throws InterruptedException {
        long kbps = getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_SPEED_LIMIT_KBPS, 0L);
        if (kbps <= 0) return;
        long maxBytes = kbps * 1024L;
        synchronized (rateLock) {
            long now = System.currentTimeMillis();
            if (now - rateWindowStarted >= 1000L) {
                rateWindowStarted = now;
                rateWindowBytes = 0L;
            }
            rateWindowBytes += bytes;
            if (rateWindowBytes > maxBytes) {
                long wait = 1000L - (now - rateWindowStarted);
                if (wait > 0) Thread.sleep(wait);
                rateWindowStarted = System.currentTimeMillis();
                rateWindowBytes = 0L;
            }
        }
    }

    private void publishProgress(String id, long downloaded, long total) {
        long now = System.currentTimeMillis();
        TaskInfo current = findTask(id);
        if (current == null) return;
        if (downloaded - current.downloadedBytes < 256 * 1024L && now - current.lastPersistAt < 900L) return;
        replaceTask(new TaskInfo(current.id, current.url, current.userAgent, current.filename, current.mime,
                total > 0 ? total : current.totalBytes, downloaded, current.state, current.outputPath,
                current.segments, current.createdAt, current.error, now));
        refreshNotification();
    }

    private void recoverInterruptedTasks() {
        List<TaskInfo> tasks = loadTasks(this);
        boolean changed = false;
        for (int i = 0; i < tasks.size(); i++) {
            TaskInfo t = tasks.get(i);
            if ("DOWNLOADING".equals(t.state) || "QUEUED".equals(t.state)) {
                tasks.set(i, t.withState("PAUSED", "App restarted — tap Resume"));
                changed = true;
            }
        }
        if (changed) saveTasks(this, tasks);
    }

    private void cleanupTaskFiles(TaskInfo task) {
        if (task.outputPath == null || task.outputPath.isEmpty()) return;
        File finalFile = new File(task.outputPath);
        new File(finalFile.getAbsolutePath() + ".part").delete();
        deleteRecursively(new File(finalFile.getParentFile(), ".infin8_" + task.id));
    }

    private static void copy(File from, File to) throws Exception {
        try (InputStream in = new BufferedInputStream(new FileInputStream(from));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(to, false))) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
        }
    }

    private static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursively(c);
        }
        f.delete();
    }

    private File uniqueFinalFile(File dir, String name, String existingPath) {
        if (existingPath != null && !existingPath.isEmpty()) return new File(existingPath);
        File file = new File(dir, name);
        if (!file.exists()) return file;
        String base = name, ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        for (int i = 2; i < 1000; i++) {
            File candidate = new File(dir, base + " (" + i + ")" + ext);
            if (!candidate.exists()) return candidate;
        }
        return new File(dir, System.currentTimeMillis() + "_" + name);
    }

    private static String categoryFor(String name, String mime) {
        String lower = (name == null ? "" : name.toLowerCase(Locale.ENGLISH));
        String m = mime == null ? "" : mime.toLowerCase(Locale.ENGLISH);
        if (m.startsWith("video/") || lower.matches(".*\\.(mp4|mkv|webm|mov|avi|ts)$")) return "Videos";
        if (m.startsWith("audio/") || lower.matches(".*\\.(mp3|m4a|aac|flac|wav|ogg)$")) return "Music";
        if (m.startsWith("image/") || lower.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|svg)$")) return "Images";
        if (lower.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|epub)$")) return "Documents";
        if (lower.endsWith(".apk")) return "Apps";
        return "Other";
    }

    private static String safeFilename(String value) {
        String name = value == null || value.trim().isEmpty() ? "download.bin" : value.trim();
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        return name.length() > 160 ? name.substring(name.length() - 160) : name;
    }

    private static String safeError(Throwable e) {
        if (e == null) return "Unknown download error";
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) m = e.getClass().getSimpleName();
        return m.length() > 180 ? m.substring(0, 180) : m;
    }

    private static boolean containsPaused(Throwable t) {
        Throwable c = t;
        for (int i = 0; i < 5 && c != null; i++, c = c.getCause()) if (c instanceof PausedException) return true;
        return false;
    }

    interface TaskMutator { TaskInfo mutate(TaskInfo task); }

    private void updateTask(String id, TaskMutator mutator) {
        synchronized (persistLock) {
            List<TaskInfo> tasks = loadTasks(this);
            for (int i = 0; i < tasks.size(); i++) {
                if (tasks.get(i).id.equals(id)) {
                    tasks.set(i, mutator.mutate(tasks.get(i)));
                    break;
                }
            }
            saveTasks(this, tasks);
        }
    }

    private void replaceTask(TaskInfo replacement) {
        synchronized (persistLock) {
            List<TaskInfo> tasks = loadTasks(this);
            for (int i = 0; i < tasks.size(); i++) {
                if (tasks.get(i).id.equals(replacement.id)) {
                    tasks.set(i, replacement);
                    saveTasks(this, tasks);
                    return;
                }
            }
            tasks.add(0, replacement);
            saveTasks(this, tasks);
        }
    }

    private TaskInfo findTask(String id) {
        for (TaskInfo t : loadTasks(this)) if (t.id.equals(id)) return t;
        return null;
    }

    public static List<TaskInfo> loadTasks(Context context) {
        List<TaskInfo> result = new ArrayList<>();
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray a = new JSONArray(p.getString(KEY_TASKS, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                result.add(TaskInfo.fromJson(o));
            }
        } catch (Exception ignored) {}
        return result;
    }

    private static void saveTasks(Context context, List<TaskInfo> tasks) {
        JSONArray a = new JSONArray();
        try { for (TaskInfo t : tasks) a.put(t.toJson()); } catch (Exception ignored) {}
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TASKS, a.toString()).commit();
    }

    public static long getSpeedLimitKbps(Context context) {
        return context.getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_SPEED_LIMIT_KBPS, 0L);
    }

    public static void setSpeedLimitKbps(Context context, long kbps) {
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong(KEY_SPEED_LIMIT_KBPS, Math.max(0L, kbps)).apply();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "INFIN8 Downloads", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Download progress and queue status");
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification buildNotification(String title, String text) {
        Intent open = new Intent(this, DownloadsActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 20, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return b.setSmallIcon(com.infin8.browser.R.drawable.ic_download)
                .setContentTitle(title).setContentText(text).setContentIntent(pi)
                .setOnlyAlertOnce(true).setOngoing(hasActiveTasks()).setCategory(Notification.CATEGORY_PROGRESS).build();
    }

    private boolean hasActiveTasks() {
        for (TaskInfo t : loadTasks(this)) if ("DOWNLOADING".equals(t.state) || "QUEUED".equals(t.state)) return true;
        return false;
    }

    private void refreshNotification() {
        List<TaskInfo> tasks = loadTasks(this);
        int active = 0;
        for (TaskInfo t : tasks) if ("DOWNLOADING".equals(t.state) || "QUEUED".equals(t.state)) active++;
        String text = active == 0 ? "No active downloads" : active + (active == 1 ? " active download" : " active downloads");
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification("INFIN8 Downloads", text));
        if (active == 0 && running.isEmpty()) {
            stopForeground(true);
            stopSelf();
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        taskPool.shutdownNow();
        super.onDestroy();
    }

    static final class Probe {
        final long totalBytes; final boolean acceptRanges;
        Probe(long totalBytes, boolean acceptRanges) { this.totalBytes = totalBytes; this.acceptRanges = acceptRanges; }
    }

    static final class PausedException extends Exception {}

    public static final class TaskInfo {
        public final String id, url, userAgent, filename, mime, state, outputPath, error;
        public final long totalBytes, downloadedBytes, createdAt, lastPersistAt;
        public final int segments;

        TaskInfo(String id, String url, String userAgent, String filename, String mime, long totalBytes,
                 long downloadedBytes, String state, String outputPath, int segments, long createdAt, String error) {
            this(id, url, userAgent, filename, mime, totalBytes, downloadedBytes, state, outputPath, segments, createdAt, error, System.currentTimeMillis());
        }

        TaskInfo(String id, String url, String userAgent, String filename, String mime, long totalBytes,
                 long downloadedBytes, String state, String outputPath, int segments, long createdAt, String error, long lastPersistAt) {
            this.id=id; this.url=url; this.userAgent=userAgent; this.filename=filename; this.mime=mime;
            this.totalBytes=totalBytes; this.downloadedBytes=downloadedBytes; this.state=state; this.outputPath=outputPath;
            this.segments=segments; this.createdAt=createdAt; this.error=error; this.lastPersistAt=lastPersistAt;
        }

        TaskInfo withState(String state, String error) {
            return new TaskInfo(id,url,userAgent,filename,mime,totalBytes,downloadedBytes,state,outputPath,segments,createdAt,error,lastPersistAt);
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id",id); o.put("url",url); o.put("ua",userAgent); o.put("name",filename); o.put("mime",mime);
            o.put("total",totalBytes); o.put("done",downloadedBytes); o.put("state",state); o.put("path",outputPath);
            o.put("segments",segments); o.put("created",createdAt); o.put("error",error); o.put("persist",lastPersistAt);
            return o;
        }

        static TaskInfo fromJson(JSONObject o) {
            return new TaskInfo(o.optString("id"), o.optString("url"), o.optString("ua"), o.optString("name","download.bin"),
                    o.optString("mime"), o.optLong("total",-1), o.optLong("done",0), o.optString("state","PAUSED"),
                    o.optString("path"), Math.max(1,o.optInt("segments",1)), o.optLong("created",0), o.optString("error"), o.optLong("persist",0));
        }
    }
}
