package com.infin8.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import com.wireguard.android.backend.Tunnel;

/**
 * Foreground process keeper for the user-requested WireGuard tunnel.
 * The actual tunnel is still created by WireGuard's official GoBackend.
 * This service keeps the app process alive after the browser task is dismissed
 * and reconnects the saved profile if Android recreates the process.
 */
public final class VpnKeepAliveService extends Service implements WireGuardManager.Listener {
    public static final String ACTION_START = "com.infin8.browser.vpn.START";
    public static final String ACTION_STOP = "com.infin8.browser.vpn.STOP";

    private static final String CHANNEL_ID = "infin8_vpn";
    private static final int NOTIFICATION_ID = 8008;
    private static final String PREFS = "infin8_browser_data";
    private static final String KEEP_KEY = "keep_vpn_connected";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WireGuardManager wireGuard;
    private boolean stopping;
    private boolean connectQueued;

    private final Runnable healthCheck = new Runnable() {
        @Override public void run() {
            if (stopping) return;
            if (!shouldKeepConnected() || wireGuard == null || !wireGuard.hasConfig()) {
                stopSelfSafely();
                return;
            }
            wireGuard.refreshState();
            handler.postDelayed(this, 20_000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        wireGuard = new WireGuardManager(getApplicationContext(), this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopping = true;
            handler.removeCallbacksAndMessages(null);
            if (wireGuard != null) wireGuard.disconnect();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        stopping = false;
        startForeground(NOTIFICATION_ID, notification("USA network active", "Keeping WireGuard connected"));
        if (!shouldKeepConnected() || wireGuard == null || !wireGuard.hasConfig()) {
            stopSelfSafely();
            return START_NOT_STICKY;
        }

        handler.removeCallbacks(healthCheck);
        wireGuard.refreshState();
        handler.postDelayed(healthCheck, 20_000L);
        return START_STICKY;
    }

    private boolean shouldKeepConnected() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEEP_KEY, false);
    }

    private void queueConnect() {
        if (connectQueued || stopping || !shouldKeepConnected() || wireGuard == null || !wireGuard.hasConfig()) return;
        if (VpnService.prepare(this) != null) {
            updateNotification("VPN permission needed", "Open INFIN8 Browser to reconnect");
            return;
        }
        connectQueued = true;
        handler.postDelayed(() -> {
            connectQueued = false;
            if (!stopping && shouldKeepConnected() && wireGuard != null && !wireGuard.isConnected()) {
                wireGuard.connect();
            }
        }, 700L);
    }

    @Override
    public void onStateChanged(Tunnel.State state) {
        if (state == Tunnel.State.UP) {
            connectQueued = false;
            updateNotification("USA network connected", "INFIN8 WireGuard is active");
        } else if (!stopping && shouldKeepConnected()) {
            updateNotification("Reconnecting USA network…", "WireGuard will stay active until you disconnect it");
            queueConnect();
        }
    }

    @Override
    public void onError(String message, Throwable error) {
        if (!stopping && shouldKeepConnected()) {
            updateNotification("USA network reconnecting…", message == null ? "WireGuard reconnect pending" : message);
            queueConnect();
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Do not stop with the browser task. The user asked for an explicit-disconnect lifetime.
        if (shouldKeepConnected()) {
            handler.removeCallbacks(healthCheck);
            handler.postDelayed(healthCheck, 1_000L);
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (wireGuard != null) wireGuard.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void stopSelfSafely() {
        stopping = true;
        handler.removeCallbacksAndMessages(null);
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "INFIN8 USA Network",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the user-enabled WireGuard tunnel connected");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    private Notification notification(String title, String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(
                this, 11, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(com.infin8.browser.R.drawable.ic_vpn_small)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, notification(title, text));
    }
}
