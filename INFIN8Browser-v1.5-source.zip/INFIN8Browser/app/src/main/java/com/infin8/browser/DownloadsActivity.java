package com.infin8.browser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;

import java.io.File;
import java.util.List;
import java.util.Locale;

public final class DownloadsActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout list;
    private TextView speedLabel;

    private final Runnable refreshLoop = new Runnable() {
        @Override public void run() {
            render();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("INFIN8 Downloads");
        getWindow().setStatusBarColor(0xFF05080D);
        getWindow().setNavigationBarColor(0xFF05080D);
        setContentView(buildUi());
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshLoop);
        handler.post(refreshLoop);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refreshLoop);
        super.onPause();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF05080D);
        root.setPadding(dp(16), dp(18), dp(16), dp(14));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = text("Downloads", 28, 0xFFF4F7FB, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, dp(56), 1f));
        Button close = button("×");
        close.setTextSize(26);
        close.setOnClickListener(v -> finish());
        header.addView(title);
        header.addView(close, new LinearLayout.LayoutParams(dp(50), dp(46)));
        root.addView(header);

        speedLabel = text("Speed: Unlimited", 13, 0xFF8EA0B7, Typeface.NORMAL);
        speedLabel.setPadding(0, dp(6), 0, dp(8));
        root.addView(speedLabel);

        LinearLayout limits = new LinearLayout(this);
        limits.setOrientation(LinearLayout.HORIZONTAL);
        limits.setGravity(Gravity.CENTER_VERTICAL);
        long[] values = {0, 512, 1024, 2048, 5120};
        String[] names = {"∞", "512K", "1M", "2M", "5M"};
        for (int i = 0; i < values.length; i++) {
            final long kbps = values[i];
            Button b = button(names[i]);
            b.setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1f);
            lp.setMargins(i == 0 ? 0 : dp(5), 0, 0, 0);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                DownloadService.setSpeedLimitKbps(this, kbps);
                updateSpeedLabel();
            });
            limits.addView(b);
        }
        root.addView(limits);

        TextView note = text("Dynamic multi-part downloads use up to 32 HTTP range parts when the server supports them.", 11, 0xFF64748B, Typeface.NORMAL);
        note.setPadding(0, dp(9), 0, dp(10));
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(4), 0, dp(20));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void render() {
        if (list == null) return;
        updateSpeedLabel();
        list.removeAllViews();
        List<DownloadService.TaskInfo> tasks = DownloadService.loadTasks(this);
        if (tasks.isEmpty()) {
            TextView empty = text("No downloads yet", 16, 0xFF718096, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(60), 0, 0);
            list.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return;
        }

        for (DownloadService.TaskInfo task : tasks) list.addView(taskCard(task));
    }

    private View taskCard(DownloadService.TaskInfo task) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(0xFF0C1522, 18, 0xFF1E3655));

        TextView name = text(task.filename, 15, 0xFFF5F7FB, Typeface.BOLD);
        name.setSingleLine(true);
        card.addView(name);

        TextView meta = text(task.state + "  •  " + formatBytes(task.downloadedBytes) + (task.totalBytes > 0 ? " / " + formatBytes(task.totalBytes) : "") + "  •  " + task.segments + " part" + (task.segments == 1 ? "" : "s"), 11, 0xFF8EA0B7, Typeface.NORMAL);
        meta.setPadding(0, dp(5), 0, dp(6));
        card.addView(meta);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        int p = task.totalBytes > 0 ? (int) Math.min(1000L, (task.downloadedBytes * 1000L) / task.totalBytes) : 0;
        progress.setProgress(p);
        card.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));

        if (task.error != null && !task.error.isEmpty()) {
            TextView error = text(task.error, 11, 0xFFFF8D8D, Typeface.NORMAL);
            error.setPadding(0, dp(7), 0, 0);
            card.addView(error);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);
        actions.setPadding(0, dp(9), 0, 0);

        if ("DOWNLOADING".equals(task.state) || "QUEUED".equals(task.state)) {
            Button pause = button("Pause");
            pause.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_PAUSE, task.id));
            actions.addView(pause, new LinearLayout.LayoutParams(dp(86), dp(40)));
        } else if ("PAUSED".equals(task.state) || "FAILED".equals(task.state)) {
            Button resume = button("Resume");
            resume.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_RESUME, task.id));
            actions.addView(resume, new LinearLayout.LayoutParams(dp(90), dp(40)));
        } else if ("COMPLETED".equals(task.state)) {
            Button open = button("Open");
            open.setOnClickListener(v -> openFile(task));
            actions.addView(open, new LinearLayout.LayoutParams(dp(80), dp(40)));
        }

        if (!"COMPLETED".equals(task.state) && !"CANCELLED".equals(task.state)) {
            Button cancel = button("Cancel");
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(88), dp(40));
            cp.setMargins(dp(8), 0, 0, 0);
            cancel.setLayoutParams(cp);
            cancel.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_CANCEL, task.id));
            actions.addView(cancel);
        }
        card.addView(actions);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(lp);
        return card;
    }

    private void openFile(DownloadService.TaskInfo task) {
        if (task.outputPath == null || task.outputPath.isEmpty()) return;
        File f = new File(task.outputPath);
        if (!f.exists()) { toast("Downloaded file is missing"); return; }
        // Keep the file manager simple and safe: open its containing folder through ACTION_VIEW when possible.
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse("file://" + f.getAbsolutePath()), task.mime == null || task.mime.isEmpty() ? "*/*" : task.mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception e) { toast("Open this file from INFIN8/Downloads in your file manager"); }
    }

    private void updateSpeedLabel() {
        if (speedLabel == null) return;
        long kbps = DownloadService.getSpeedLimitKbps(this);
        speedLabel.setText(kbps <= 0 ? "Speed: Unlimited" : "Speed limit: " + (kbps >= 1024 ? String.format(Locale.US, "%.1f MB/s", kbps / 1024f) : kbps + " KB/s"));
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(0xFFEAF2FF);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(7), 0, dp(7), 0);
        b.setBackground(round(0xFF101D2E, 14, 0xFF244C78));
        return b;
    }

    private TextView text(String value, float sp, int color, int style) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private static String formatBytes(long b) {
        if (b < 0) return "?";
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", b / 1024f);
        if (b < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", b / (1024f * 1024f));
        return String.format(Locale.US, "%.2f GB", b / (1024f * 1024f * 1024f));
    }
}
