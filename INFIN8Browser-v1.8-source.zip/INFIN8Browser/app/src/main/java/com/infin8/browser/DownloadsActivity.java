package com.infin8.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Premium download center for INFIN8 Browser. */
public final class DownloadsActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, Long> lastBytes = new HashMap<>();
    private final Map<String, Long> lastTimes = new HashMap<>();
    private final Map<String, Long> smoothedSpeeds = new HashMap<>();

    private LinearLayout list;
    private TextView speedLabel;
    private TextView statsLabel;
    private CheckBox wifiOnly;
    private String filter = "ALL";

    private final Runnable refreshLoop = new Runnable() {
        @Override public void run() {
            render();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("INFIN8 Downloads");
        getWindow().setStatusBarColor(0xFF05080D);
        getWindow().setNavigationBarColor(0xFF05080D);
        setContentView(buildUi());
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refreshLoop);
        handler.post(refreshLoop);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(refreshLoop);
        super.onPause();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF05080D);
        root.setPadding(dp(16), dp(18), dp(16), dp(14));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Downloads Pro", 27, 0xFFF4F7FB, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, dp(54), 1f));
        Button close = button("×");
        close.setTextSize(25);
        close.setOnClickListener(v -> finish());
        header.addView(title);
        header.addView(close, new LinearLayout.LayoutParams(dp(50), dp(44)));
        root.addView(header);

        statsLabel = text("0 active • 0 completed", 12, 0xFF7F91A9, Typeface.NORMAL);
        statsLabel.setPadding(0, 0, 0, dp(7));
        root.addView(statsLabel);

        LinearLayout speedRow = new LinearLayout(this);
        speedRow.setOrientation(LinearLayout.HORIZONTAL);
        speedRow.setGravity(Gravity.CENTER_VERTICAL);
        speedLabel = text("Speed: Unlimited", 13, 0xFFAAB9CC, Typeface.NORMAL);
        speedLabel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(40), 1f));
        Button custom = button("Custom");
        custom.setOnClickListener(v -> showCustomSpeedDialog());
        speedRow.addView(speedLabel);
        speedRow.addView(custom, new LinearLayout.LayoutParams(dp(86), dp(38)));
        root.addView(speedRow);

        LinearLayout limits = new LinearLayout(this);
        limits.setOrientation(LinearLayout.HORIZONTAL);
        limits.setGravity(Gravity.CENTER_VERTICAL);
        long[] values = {0, 512, 1024, 2048, 5120};
        String[] names = {"∞", "512K", "1M", "2M", "5M"};
        for (int i = 0; i < values.length; i++) {
            final long kbps = values[i];
            Button b = button(names[i]);
            b.setTextSize(12);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            lp.setMargins(i == 0 ? 0 : dp(5), 0, 0, 0);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                DownloadService.setSpeedLimitKbps(this, kbps);
                updateSpeedLabel();
            });
            limits.addView(b);
        }
        root.addView(limits);

        wifiOnly = new CheckBox(this);
        wifiOnly.setText("Wi-Fi only downloads");
        wifiOnly.setTextColor(0xFFD7E4F5);
        wifiOnly.setTextSize(13);
        wifiOnly.setChecked(DownloadService.isWifiOnly(this));
        wifiOnly.setPadding(0, dp(7), 0, dp(5));
        wifiOnly.setOnCheckedChangeListener((buttonView, isChecked) -> {
            DownloadService.setWifiOnly(this, isChecked);
            toast(isChecked ? "Downloads will wait for Wi-Fi" : "Wi-Fi-only disabled");
        });
        root.addView(wifiOnly);

        LinearLayout concurrency = new LinearLayout(this);
        concurrency.setOrientation(LinearLayout.HORIZONTAL);
        concurrency.setGravity(Gravity.CENTER_VERTICAL);
        TextView concurrencyLabel = text("Parallel downloads", 12, 0xFF8EA0B7, Typeface.NORMAL);
        concurrencyLabel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(40), 1f));
        concurrency.addView(concurrencyLabel);
        for (int i = 1; i <= 3; i++) {
            final int value = i;
            Button b = button(String.valueOf(i));
            b.setTextSize(12);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(44), dp(38));
            bp.setMargins(dp(5), 0, 0, 0);
            concurrency.addView(b, bp);
            b.setOnClickListener(v -> {
                DownloadService.setMaxConcurrent(this, value);
                toast("Parallel downloads: " + value);
            });
        }
        root.addView(concurrency);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        Button retryAll = button("Retry failed");
        retryAll.setOnClickListener(v -> retryAllFailed());
        Button clearDone = button("Clear completed");
        clearDone.setOnClickListener(v -> confirmClearCompleted());
        tools.addView(retryAll, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        clp.setMargins(dp(7), 0, 0, 0);
        tools.addView(clearDone, clp);
        root.addView(tools);

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        String[] filterNames = {"All", "Active", "Done", "Failed"};
        String[] filterValues = {"ALL", "ACTIVE", "COMPLETED", "FAILED"};
        for (int i = 0; i < filterNames.length; i++) {
            final String value = filterValues[i];
            Button b = button(filterNames[i]);
            b.setTextSize(11);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.setMargins(i == 0 ? 0 : dp(5), dp(8), 0, 0);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> { filter = value; render(); });
            filters.addView(b);
        }
        root.addView(filters);

        TextView note = text("Direct + public HLS/DASH • queue reorder • scheduling • 1–3 parallel jobs • live speed + ETA", 11, 0xFF64748B, Typeface.NORMAL);
        note.setPadding(0, dp(9), 0, dp(8));
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(4), 0, dp(20));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void render() {
        if (list == null) return;
        updateSpeedLabel();
        List<DownloadService.TaskInfo> tasks = DownloadService.loadTasks(this);
        int active = 0, completed = 0, failed = 0;
        for (DownloadService.TaskInfo t : tasks) {
            if (isActive(t)) active++;
            if ("COMPLETED".equals(t.state)) completed++;
            if ("FAILED".equals(t.state)) failed++;
        }
        statsLabel.setText(active + " active • " + completed + " completed" + (failed > 0 ? " • " + failed + " failed" : ""));

        list.removeAllViews();
        int shown = 0;
        for (DownloadService.TaskInfo task : tasks) {
            if (!matchesFilter(task)) continue;
            list.addView(taskCard(task));
            shown++;
        }
        if (shown == 0) {
            TextView empty = text(tasks.isEmpty() ? "No downloads yet" : "Nothing in this filter", 16, 0xFF718096, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(60), 0, 0);
            list.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    private boolean matchesFilter(DownloadService.TaskInfo t) {
        if ("ALL".equals(filter)) return true;
        if ("ACTIVE".equals(filter)) return isActive(t);
        return filter.equals(t.state);
    }

    private boolean isActive(DownloadService.TaskInfo t) {
        return "DOWNLOADING".equals(t.state) || "QUEUED".equals(t.state) || "WAITING_WIFI".equals(t.state) || "WAITING_USA".equals(t.state) || "SCHEDULED".equals(t.state);
    }

    private View taskCard(DownloadService.TaskInfo task) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(round(0xFF0C1522, 18, 0xFF1E3655));

        TextView name = text(task.filename, 15, 0xFFF5F7FB, Typeface.BOLD);
        name.setSingleLine(true);
        card.addView(name);

        long now = System.currentTimeMillis();
        long speed = calculateSpeed(task, now);
        String speedEta = "";
        if ("DOWNLOADING".equals(task.state) && speed > 0) {
            speedEta = "  •  " + formatBytes(speed) + "/s";
            if (task.totalBytes > task.downloadedBytes) {
                long eta = (task.totalBytes - task.downloadedBytes) / Math.max(1L, speed);
                speedEta += "  •  ETA " + formatDuration(eta);
            }
        }
        String parts = task.requestedSegments > 0 ? task.requestedSegments + " selected" : task.segments + " auto";
        TextView meta = text(prettyState(task.state) + "  •  " + formatBytes(task.downloadedBytes)
                + (task.totalBytes > 0 ? " / " + formatBytes(task.totalBytes) : "") + "  •  " + parts + " parts" + speedEta,
                11, 0xFF8EA0B7, Typeface.NORMAL);
        meta.setPadding(0, dp(5), 0, dp(6));
        card.addView(meta);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        int p = task.totalBytes > 0 ? (int) Math.min(1000L, (task.downloadedBytes * 1000L) / task.totalBytes) : 0;
        progress.setIndeterminate(task.totalBytes <= 0 && isActive(task));
        progress.setProgress(p);
        card.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));

        if (task.category != null && !task.category.isEmpty()) {
            String kind = task.mediaKind == null || task.mediaKind.isEmpty() ? "DIRECT" : task.mediaKind;
            TextView category = text("Folder: " + task.category + "  •  " + kind, 10, 0xFF6684A5, Typeface.NORMAL);
            category.setPadding(0, dp(5), 0, 0);
            card.addView(category);
        }
        if ("SCHEDULED".equals(task.state) && task.scheduledAt > 0) {
            TextView scheduled = text("Starts: " + formatSchedule(task.scheduledAt), 11, 0xFFFFC76A, Typeface.BOLD);
            scheduled.setPadding(0, dp(5), 0, 0);
            card.addView(scheduled);
        }
        if (task.detail != null && !task.detail.isEmpty()) {
            TextView detail = text(task.detail, 10, 0xFF6F89A7, Typeface.NORMAL);
            detail.setPadding(0, dp(4), 0, 0);
            card.addView(detail);
        }

        if (task.error != null && !task.error.isEmpty()) {
            TextView error = text(task.error, 11, ("WAITING_WIFI".equals(task.state) || "WAITING_USA".equals(task.state)) ? 0xFFFFC76A : 0xFFFF8D8D, Typeface.NORMAL);
            error.setPadding(0, dp(7), 0, 0);
            card.addView(error);
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);
        actions.setPadding(0, dp(9), 0, 0);

        if ("DOWNLOADING".equals(task.state) || "QUEUED".equals(task.state) || "WAITING_WIFI".equals(task.state) || "WAITING_USA".equals(task.state)) {
            Button pause = button("Pause");
            pause.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_PAUSE, task.id));
            actions.addView(pause, new LinearLayout.LayoutParams(dp(78), dp(40)));
        } else if ("SCHEDULED".equals(task.state)) {
            Button now = button("Start now");
            now.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_START_NOW, task.id));
            actions.addView(now, new LinearLayout.LayoutParams(dp(94), dp(40)));
        } else if ("PAUSED".equals(task.state) || "FAILED".equals(task.state)) {
            Button resume = button("Resume");
            resume.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_RESUME, task.id));
            actions.addView(resume, new LinearLayout.LayoutParams(dp(82), dp(40)));
        } else if ("COMPLETED".equals(task.state)) {
            Button open = button("Open");
            open.setOnClickListener(v -> openFile(task));
            actions.addView(open, new LinearLayout.LayoutParams(dp(70), dp(40)));
            Button share = button("Share");
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(74), dp(40));
            slp.setMargins(dp(6), 0, 0, 0);
            actions.addView(share, slp);
            share.setOnClickListener(v -> shareFile(task));
        }

        if (!"COMPLETED".equals(task.state) && !"CANCELLED".equals(task.state) && !"FAILED".equals(task.state)) {
            Button cancel = button("Cancel");
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(82), dp(40));
            cp.setMargins(dp(6), 0, 0, 0);
            cancel.setLayoutParams(cp);
            cancel.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_CANCEL, task.id));
            actions.addView(cancel);
        }

        if ("COMPLETED".equals(task.state) || "FAILED".equals(task.state) || "CANCELLED".equals(task.state)) {
            Button delete = button("Delete");
            LinearLayout.LayoutParams delp = new LinearLayout.LayoutParams(dp(76), dp(40));
            delp.setMargins(dp(6), 0, 0, 0);
            delete.setLayoutParams(delp);
            delete.setOnClickListener(v -> confirmDelete(task));
            actions.addView(delete);
        }
        card.addView(actions);

        if ("QUEUED".equals(task.state) || "SCHEDULED".equals(task.state) || "PAUSED".equals(task.state)) {
            LinearLayout queueActions = new LinearLayout(this);
            queueActions.setOrientation(LinearLayout.HORIZONTAL);
            queueActions.setGravity(Gravity.END);
            queueActions.setPadding(0, dp(6), 0, 0);
            Button up = button("↑ Up");
            up.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_MOVE_UP, task.id));
            Button down = button("↓ Down");
            down.setOnClickListener(v -> DownloadService.command(this, DownloadService.ACTION_MOVE_DOWN, task.id));
            Button schedule = button("Schedule");
            schedule.setOnClickListener(v -> showScheduleDialog(task));
            queueActions.addView(up, new LinearLayout.LayoutParams(dp(70), dp(38)));
            LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(dp(78), dp(38)); dp1.setMargins(dp(5),0,0,0);
            queueActions.addView(down, dp1);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(94), dp(38)); sp.setMargins(dp(5),0,0,0);
            queueActions.addView(schedule, sp);
            card.addView(queueActions);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(lp);
        return card;
    }

    private long calculateSpeed(DownloadService.TaskInfo task, long now) {
        Long oldBytes = lastBytes.get(task.id);
        Long oldTime = lastTimes.get(task.id);
        long speed = smoothedSpeeds.getOrDefault(task.id, 0L);
        if (oldBytes != null && oldTime != null && now > oldTime && task.downloadedBytes >= oldBytes) {
            long instant = ((task.downloadedBytes - oldBytes) * 1000L) / Math.max(1L, now - oldTime);
            speed = speed <= 0 ? instant : (speed * 2 + instant) / 3;
            smoothedSpeeds.put(task.id, speed);
        }
        lastBytes.put(task.id, task.downloadedBytes);
        lastTimes.put(task.id, now);
        return speed;
    }

    private void showScheduleDialog(DownloadService.TaskInfo task) {
        EditText input = new EditText(this);
        input.setHint("Minutes from now");
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText("30");
        int pad = dp(18);
        input.setPadding(pad, dp(8), pad, dp(8));
        new AlertDialog.Builder(this)
                .setTitle("Schedule download")
                .setMessage("Enter how many minutes from now INFIN8 should start this download.")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("1 hour", (d, w) -> DownloadService.schedule(this, task.id, System.currentTimeMillis() + 60L * 60L * 1000L))
                .setPositiveButton("Schedule", (d, w) -> {
                    try {
                        long minutes = Long.parseLong(input.getText().toString().trim());
                        if (minutes < 1 || minutes > 7L * 24L * 60L) throw new IllegalArgumentException();
                        DownloadService.schedule(this, task.id, System.currentTimeMillis() + minutes * 60_000L);
                        toast("Scheduled in " + minutes + " minute" + (minutes == 1 ? "" : "s"));
                    } catch (Exception e) { toast("Enter 1–10080 minutes"); }
                }).show();
    }

    private void showCustomSpeedDialog() {
        EditText input = new EditText(this);
        input.setHint("KB/s — 0 = Unlimited");
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(DownloadService.getSpeedLimitKbps(this)));
        int pad = dp(18);
        input.setPadding(pad, dp(8), pad, dp(8));
        new AlertDialog.Builder(this)
                .setTitle("Custom speed limit")
                .setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    try {
                        long value = Long.parseLong(input.getText().toString().trim());
                        DownloadService.setSpeedLimitKbps(this, value);
                        updateSpeedLabel();
                    } catch (Exception e) { toast("Enter a valid KB/s value"); }
                }).show();
    }

    private void retryAllFailed() {
        int count = 0;
        for (DownloadService.TaskInfo t : DownloadService.loadTasks(this)) {
            if ("FAILED".equals(t.state)) {
                DownloadService.command(this, DownloadService.ACTION_RETRY, t.id);
                count++;
            }
        }
        toast(count == 0 ? "No failed downloads" : "Retrying " + count + " download" + (count == 1 ? "" : "s"));
    }

    private void confirmClearCompleted() {
        int count = 0;
        for (DownloadService.TaskInfo t : DownloadService.loadTasks(this)) if ("COMPLETED".equals(t.state)) count++;
        if (count == 0) { toast("No completed downloads"); return; }
        final int total = count;
        new AlertDialog.Builder(this)
                .setTitle("Clear completed downloads?")
                .setMessage("This deletes " + total + " downloaded file" + (total == 1 ? "" : "s") + " from INFIN8 storage.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    for (DownloadService.TaskInfo t : DownloadService.loadTasks(this)) {
                        if ("COMPLETED".equals(t.state)) DownloadService.command(this, DownloadService.ACTION_DELETE, t.id);
                    }
                    handler.postDelayed(this::render, 350L);
                }).show();
    }

    private void confirmDelete(DownloadService.TaskInfo task) {
        boolean hasFile = task.outputPath != null && !task.outputPath.isEmpty() && new File(task.outputPath).exists();
        new AlertDialog.Builder(this)
                .setTitle("Delete download?")
                .setMessage(hasFile ? "The downloaded file and its entry will be deleted." : "This download entry will be removed.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> DownloadService.command(this, DownloadService.ACTION_DELETE, task.id))
                .show();
    }

    private void openFile(DownloadService.TaskInfo task) {
        Uri uri = contentUri(task);
        if (uri == null) return;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, safeMime(task.mime));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); } catch (Exception e) { toast("No app can open this file type"); }
    }

    private void shareFile(DownloadService.TaskInfo task) {
        Uri uri = contentUri(task);
        if (uri == null) return;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(safeMime(task.mime));
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i, "Share download")); } catch (Exception e) { toast("Could not share file"); }
    }

    private Uri contentUri(DownloadService.TaskInfo task) {
        if (task.outputPath == null || task.outputPath.isEmpty()) { toast("Downloaded file is missing"); return null; }
        File f = new File(task.outputPath);
        if (!f.exists()) { toast("Downloaded file is missing"); return null; }
        try { return FileProvider.getUriForFile(this, getPackageName() + ".files", f); }
        catch (Exception e) { toast("Could not access downloaded file"); return null; }
    }

    private String safeMime(String mime) {
        return mime == null || mime.trim().isEmpty() ? "*/*" : mime;
    }

    private void updateSpeedLabel() {
        if (speedLabel == null) return;
        long kbps = DownloadService.getSpeedLimitKbps(this);
        speedLabel.setText(kbps <= 0 ? "Speed: Unlimited" : "Speed limit: " + (kbps >= 1024 ? String.format(Locale.US, "%.1f MB/s", kbps / 1024f) : kbps + " KB/s"));
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(0xFFEAF2FF);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setBackground(round(0xFF101D2E, 14, 0xFF244C78));
        return b;
    }

    private TextView text(String value, float sp, int color, int style) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private String prettyState(String state) {
        if (state == null) return "Unknown";
        switch (state) {
            case "WAITING_WIFI": return "Waiting for Wi-Fi";
            case "WAITING_USA": return "Waiting for USA verification";
            case "DOWNLOADING": return "Downloading";
            case "COMPLETED": return "Completed";
            case "PAUSED": return "Paused";
            case "QUEUED": return "Queued";
            case "SCHEDULED": return "Scheduled";
            case "FAILED": return "Failed";
            case "CANCELLED": return "Cancelled";
            default: return state;
        }
    }

    private String formatSchedule(long when) {
        return new java.text.SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(new java.util.Date(when));
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private static String formatDuration(long seconds) {
        if (seconds < 60) return seconds + "s";
        if (seconds < 3600) return (seconds / 60) + "m " + (seconds % 60) + "s";
        return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
    }

    private static String formatBytes(long b) {
        if (b < 0) return "?";
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", b / 1024f);
        if (b < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", b / (1024f * 1024f));
        return String.format(Locale.US, "%.2f GB", b / (1024f * 1024f * 1024f));
    }
}
