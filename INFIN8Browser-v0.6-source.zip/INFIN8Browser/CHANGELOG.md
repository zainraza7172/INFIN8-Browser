# Changelog

## 0.5.0
- Replaced the crowded toolbar with logo + address/search bar + overflow menu.
- Added explicit × close control to every tab.
- Fixed Android back navigation to use WebView history before leaving the browser.
- Added Android 13+ OnBackInvoked handling.
- Removed USA MODE badge and enlarged INFIN8 Browser branding.
- Removed all built-in Speed Dial shortcuts; Speed Dial is custom-only.
- Removed the homepage USA Security Gate card while retaining the underlying security gate.

## 0.4.0
- Added horizontal Vivaldi-style tab strip.
- Added one-tap new tab button and long-press tab close.
- Rebuilt the new-tab page into a polished Speed Dial dashboard.
- Added locally persistent custom shortcuts with add/edit/delete controls.
- Added new-tab Google/address search.
- Preserved v0.3 USA verification gate and WireGuard fail-closed behavior.


## v0.3.0 — Automatic USA Security Gate
- Added automatic VPN exit-country verification after WireGuard connects.
- Uses multiple public IP geolocation checks with a tie-breaker to handle stale databases.
- Internet remains blocked until the exit is verified as United States.
- Added a WebView process-level fail-closed proxy gate while unverified/disconnected.
- Re-verifies the exit periodically and when returning to the app after the verification becomes stale.
- USA status button now distinguishes connected/unverified from USA-verified.
- VPN configuration continues to be encrypted locally with Android Keystore.

## v0.2.0
- Embedded WireGuard tunnel support.
- Import Proton WireGuard .conf profiles securely.
- App-only VPN routing for INFIN8 Browser.
- Browser navigation blocked while WireGuard is disconnected.


## v0.6
- Removed left toolbar logo for a cleaner top bar
- Replaced the right toolbar menu icon with the INFIN8 mascot logo
- Refined homepage wordmark styling for a more unique brand font feel
