package com.infin8.browser;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.Executor;

/**
 * Isolated private browsing window.
 * Runs in its own Android process and WebView data directory. The profile is cleared
 * before and after every session and never writes normal browser history/tabs/bookmarks.
 */
public class IncognitoActivity extends Activity {
    private static final String HOME_URL = "https://appassets.androidplatform.net/assets/start.html";
    private static final String LEGACY_HOME_URL = "file:///android_asset/start.html";
    private static final long REVERIFY_MS = 5L * 60L * 1000L;

    private final Executor proxyExecutor = Runnable::run;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView webView;
    private EditText address;
    private ProgressBar progress;
    private TextView privacyStatus;
    private UsaNetworkVerifier verifier;
    private boolean usaVerified;
    private boolean gateOpen;
    private boolean destroyed;
    private long lastVerifiedAt;
    private String pendingUrl = HOME_URL;
    private String searchEngine = "google";
    private String themeMode = "dark";
    private String accentId = "blue";
    private boolean askExternalApps = true;
    private String connectionMode = ConnectionSettings.MODE_WIREGUARD;
    private String proxyUrl = "";
    private boolean proxyConnected;
    private WebViewAssetLoader assetLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { WebView.setDataDirectorySuffix("incognito"); } catch (Exception ignored) {}
        }
        super.onCreate(savedInstanceState);
        Locale.setDefault(Locale.US);
        verifier = new UsaNetworkVerifier();
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { WebView.startSafeBrowsing(this, value -> {}); } catch (Exception ignored) {}
        }
        readLaunchOptions();
        applyTheme();
        clearPrivateProfile();
        setContentView(buildUi());
        closeGate();
        loadLocalHome();
        verifyUsaAndContinue(null, false);
    }

    private void readLaunchOptions() {
        Intent intent = getIntent();
        if (intent == null) return;
        searchEngine = safeEngine(intent.getStringExtra("search_engine"));
        String t = intent.getStringExtra("theme_mode");
        if ("amoled".equals(t)) themeMode = "amoled";
        String a = intent.getStringExtra("accent_color");
        if (a != null && !a.trim().isEmpty()) accentId = a;
        askExternalApps = intent.getBooleanExtra("ask_external_apps", true);
        connectionMode = ConnectionSettings.MODE_PROXY.equals(intent.getStringExtra("connection_mode"))
                ? ConnectionSettings.MODE_PROXY : ConnectionSettings.MODE_WIREGUARD;
        proxyUrl = ConnectionSettings.normalizeProxy(intent.getStringExtra("proxy_url"));
        proxyConnected = intent.getBooleanExtra("proxy_connected", false) && !proxyUrl.isEmpty();
        String initial = intent.getStringExtra("initial_url");
        if (initial != null && !initial.trim().isEmpty()) pendingUrl = normalizeInternalUrl(initial.trim());
    }

    private void applyTheme() {
        int background = backgroundColor();
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(background);
        boolean secure = getIntent() == null || getIntent().getBooleanExtra("secure_screen", true);
        if (secure) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(backgroundColor());

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(10), dp(12), dp(10), dp(8));
        header.setBackgroundColor(surfaceColor());

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = text("PRIVATE", 11, accentColor(), Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(round(0xFF151022, 15, accentColor(), 1));
        titleRow.addView(badge, new LinearLayout.LayoutParams(dp(74), dp(30)));
        TextView title = text("INFIN8 Incognito", 17, Color.WHITE, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(10), 0, 0, 0);
        titleRow.addView(title, titleLp);
        TextView close = text("×", 28, 0xFFEAF2FF, Typeface.NORMAL);
        close.setGravity(Gravity.CENTER);
        close.setBackground(round(0xFF151B24, 18, 0xFF263344, 1));
        close.setOnClickListener(v -> finish());
        titleRow.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
        header.addView(titleRow);

        LinearLayout addressRow = new LinearLayout(this);
        addressRow.setGravity(Gravity.CENTER_VERTICAL);
        addressRow.setPadding(dp(10), 0, dp(10), 0);
        addressRow.setBackground(round(0xFF171D27, 15, 0xFF263344, 1));
        LinearLayout.LayoutParams arp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        arp.setMargins(0, dp(8), 0, 0);
        addressRow.setLayoutParams(arp);

        TextView lock = text("◉", 15, accentColor(), Typeface.BOLD);
        addressRow.addView(lock);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(0xFF7F8C9E);
        address.setHint("Private search or URL");
        address.setTextSize(14);
        address.setBackgroundColor(Color.TRANSPARENT);
        address.setPadding(dp(9), 0, 0, 0);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        addressRow.addView(address);
        header.addView(addressRow);

        privacyStatus = text("Verifying USA exit…", 11, 0xFF8998AC, Typeface.NORMAL);
        privacyStatus.setPadding(dp(3), dp(6), 0, 0);
        header.addView(privacyStatus);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);

        FrameLayout content = new FrameLayout(this);
        content.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        webView = new WebView(this);
        configureWebView();
        content.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(8), dp(5), dp(8), dp(8));
        bottom.setBackgroundColor(surfaceColor());
        TextView back = bottomButton("‹", "Back");
        TextView forward = bottomButton("›", "Forward");
        TextView home = bottomButton("⌂", "Home");
        TextView refresh = bottomButton("↻", "Reload");
        back.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        forward.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });
        home.setOnClickListener(v -> loadLocalHome());
        refresh.setOnClickListener(v -> webView.reload());
        bottom.addView(back, new LinearLayout.LayoutParams(0, dp(54), 1f));
        bottom.addView(forward, new LinearLayout.LayoutParams(0, dp(54), 1f));
        bottom.addView(home, new LinearLayout.LayoutParams(0, dp(54), 1f));
        bottom.addView(refresh, new LinearLayout.LayoutParams(0, dp(54), 1f));

        root.addView(header);
        root.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));
        root.addView(content);
        root.addView(bottom);

        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate(address.getText().toString());
                return true;
            }
            return false;
        });
        return root;
    }

    private TextView bottomButton(String icon, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView symbol = text(icon, 23, 0xFFDCE7F6, Typeface.NORMAL);
        symbol.setGravity(Gravity.CENTER);
        TextView caption = text(label, 10, 0xFF8C9AAD, Typeface.BOLD);
        caption.setGravity(Gravity.CENTER);
        box.addView(symbol, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)));
        box.addView(caption);
        TextView proxy = new TextView(this);
        proxy.setTag(box);
        proxy.setText(label);
        proxy.setTextColor(Color.TRANSPARENT);
        proxy.setBackgroundColor(Color.TRANSPARENT);
        proxy.setGravity(Gravity.CENTER);
        proxy.setOnClickListener(v -> box.performClick());
        box.setClickable(true);
        proxy.setOnClickListener(v -> {});
        // Return a clickable TextView shell while retaining a compact visual label.
        TextView shell = new TextView(this);
        shell.setText(icon + "\n" + label);
        shell.setTextSize(12);
        shell.setGravity(Gravity.CENTER);
        shell.setTextColor(0xFFDCE7F6);
        shell.setBackgroundColor(Color.TRANSPARENT);
        shell.setLines(2);
        return shell;
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { s.setSafeBrowsingEnabled(true); } catch (Exception ignored) {}
        }
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setSaveFormData(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, false);
        installWebRtcShield();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                if (url != null && !HOME_URL.equals(url)) address.setText(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                if (HOME_URL.equals(url)) injectHomeSearchSettings();
                if (url != null && !HOME_URL.equals(url)) address.setText(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null) {
                    WebResourceResponse local = assetLoader == null ? null : assetLoader.shouldInterceptRequest(uri);
                    if (local != null) return local;
                    if (isBlockedHost(uri.getHost())) {
                        return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return true;
                String target = uri.toString();
                if (HOME_URL.equals(target) || target.startsWith(HOME_URL)) return false;
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (!usaVerified || !gateOpen) {
                        pendingUrl = uri.toString();
                        verifyUsaAndContinue(pendingUrl, true);
                        return true;
                    }
                    return false;
                }
                if ("file".equalsIgnoreCase(scheme) || "content".equalsIgnoreCase(scheme)) {
                    toast("Local file/content navigation is blocked");
                    return true;
                }
                return handleExternalNavigation(uri);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                if (handler != null) handler.cancel();
                toast("Blocked page with an invalid SSL certificate");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, false, false);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // Private windows do not persist camera/microphone grants. Keep them blocked.
                request.deny();
                runOnUiThread(() -> toast("Camera/microphone blocked in Incognito"));
            }
        });
    }

    private void navigate(String input) {
        String text = input == null ? "" : input.trim();
        if (text.isEmpty()) return;
        String url;
        if (HOME_URL.equals(text) || LEGACY_HOME_URL.equals(text) || text.startsWith(LEGACY_HOME_URL)) {
            url = HOME_URL;
        } else if (text.startsWith("file://") || text.startsWith("content://")) {
            toast("Local file/content URLs are blocked");
            return;
        } else if (text.startsWith("http://") || text.startsWith("https://")) url = text;
        else if (text.matches("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}([/:?#].*)?$")) url = "https://" + text;
        else url = buildSearchUrl(text);
        if (!HOME_URL.equals(url) && (!usaVerified || !gateOpen)) {
            pendingUrl = url;
            verifyUsaAndContinue(url, true);
            return;
        }
        webView.loadUrl(url);
    }

    private boolean isProxyMode() {
        return ConnectionSettings.MODE_PROXY.equals(connectionMode);
    }

    private String normalizeInternalUrl(String url) {
        if (url == null || url.trim().isEmpty()) return HOME_URL;
        String clean = url.trim();
        if (LEGACY_HOME_URL.equals(clean) || clean.startsWith(LEGACY_HOME_URL)) return HOME_URL;
        return clean;
    }

    private boolean handleExternalNavigation(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.US);
        boolean supported = "mailto".equals(scheme) || "tel".equals(scheme) || "sms".equals(scheme)
                || "smsto".equals(scheme) || "geo".equals(scheme) || "market".equals(scheme)
                || "intent".equals(scheme);
        if (!supported) {
            toast("Blocked unsupported external link");
            return true;
        }

        Runnable open = () -> {
            try {
                Intent external;
                String fallback = "";
                if ("intent".equals(scheme)) {
                    external = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                    fallback = external.getStringExtra("browser_fallback_url");
                    external.removeExtra("browser_fallback_url");
                    external.addCategory(Intent.CATEGORY_BROWSABLE);
                    external.setComponent(null);
                    external.setSelector(null);
                } else {
                    external = new Intent(Intent.ACTION_VIEW, uri);
                }
                if (external.resolveActivity(getPackageManager()) != null) {
                    startActivity(external);
                } else if (fallback != null && fallback.startsWith("https://")) {
                    navigate(fallback);
                } else {
                    toast("No app can open this link");
                }
            } catch (Exception e) {
                toast("External link could not be opened");
            }
        };

        if (askExternalApps) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Leave Incognito?")
                    .setMessage("This private page wants to open an external app (" + scheme + "). The external app is outside INFIN8 Incognito.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open", (d, w) -> open.run())
                    .show();
        } else {
            open.run();
        }
        return true;
    }

    private void loadLocalHome() {
        pendingUrl = HOME_URL;
        if (webView != null) webView.loadUrl(HOME_URL);
        if (address != null) address.setText("");
    }

    private void verifyUsaAndContinue(String afterUrl, boolean announceFailure) {
        if (destroyed || verifier == null) return;
        closeGate();
        privacyStatus.setText(isProxyMode() ? "Verifying USA proxy exit…" : "Verifying USA exit…");

        UsaNetworkVerifier.Callback callback = result -> runOnUiThread(() -> {
            if (destroyed) return;
            usaVerified = result.verifiedUsa;
            lastVerifiedAt = System.currentTimeMillis();
            if (usaVerified) {
                privacyStatus.setText("Private • " + (isProxyMode() ? "Proxy" : "WireGuard VPN") + " • USA verified" + (result.ip.isEmpty() ? "" : " • " + result.ip));
                openGate(() -> {
                    String target = afterUrl;
                    if (target == null || target.trim().isEmpty()) {
                        target = pendingUrl;
                        if (HOME_URL.equals(target)) target = null;
                    }
                    if (target != null && (target.startsWith("http://") || target.startsWith("https://"))) {
                        webView.loadUrl(target);
                    }
                });
            } else {
                privacyStatus.setText("Private • Internet blocked • USA not verified");
                if (announceFailure) showBlockedDialog(result.detail);
            }
        });

        if (isProxyMode()) {
            if (!proxyConnected || proxyUrl.isEmpty()) {
                usaVerified = false;
                privacyStatus.setText("Private • Proxy disconnected • Internet blocked");
                if (announceFailure) showBlockedDialog("Connect the global USA Proxy from the main browser first.");
                return;
            }
            try {
                verifier.verify(ConnectionSettings.toJavaProxy(proxyUrl), callback);
            } catch (Exception e) {
                usaVerified = false;
                privacyStatus.setText("Private • Invalid proxy • Internet blocked");
                if (announceFailure) showBlockedDialog("The configured proxy is invalid.");
            }
        } else {
            verifier.verify(callback);
        }
    }

    private void closeGate() {
        gateOpen = false;
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return;
        try {
            ProxyConfig blocked = new ProxyConfig.Builder().addProxyRule("http://127.0.0.1:9").build();
            ProxyController.getInstance().setProxyOverride(blocked, proxyExecutor, () -> {});
        } catch (Exception ignored) {}
    }

    private void openGate(Runnable afterOpen) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            if (isProxyMode()) {
                gateOpen = false;
                usaVerified = false;
                privacyStatus.setText("Private • Proxy unsupported • Internet blocked");
                return;
            }
            gateOpen = true;
            if (afterOpen != null) afterOpen.run();
            return;
        }
        try {
            if (isProxyMode()) {
                ProxyConfig config = new ProxyConfig.Builder().addProxyRule(proxyUrl).build();
                ProxyController.getInstance().setProxyOverride(config, proxyExecutor, () -> runOnUiThread(() -> {
                    if (destroyed) return;
                    gateOpen = true;
                    if (afterOpen != null) afterOpen.run();
                }));
            } else {
                ProxyController.getInstance().clearProxyOverride(proxyExecutor, () -> runOnUiThread(() -> {
                    if (destroyed) return;
                    gateOpen = true;
                    if (afterOpen != null) afterOpen.run();
                }));
            }
        } catch (Exception e) {
            gateOpen = false;
            usaVerified = false;
            privacyStatus.setText("Private • Secure gate error");
        }
    }

    private void showBlockedDialog(String detail) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(16));
        card.setBackground(round(panelColor(), 24, accentColor(), 1));
        card.addView(text("USA exit required", 22, Color.WHITE, Typeface.BOLD));
        TextView msg = text(detail == null || detail.trim().isEmpty() ? "Private browsing remains blocked until a USA exit is verified." : detail, 13, 0xFF91A1B7, Typeface.NORMAL);
        msg.setPadding(0, dp(8), 0, dp(16));
        card.addView(msg);
        TextView retry = text("Retry verification", 14, Color.WHITE, Typeface.BOLD);
        retry.setGravity(Gravity.CENTER);
        retry.setBackground(round(accentStrongColor(), 18, accentColor(), 1));
        retry.setOnClickListener(v -> { dialog.dismiss(); verifyUsaAndContinue(pendingUrl, true); });
        card.addView(retry, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void injectHomeSearchSettings() {
        try {
            String template = org.json.JSONObject.quote(searchTemplate());
            String label = org.json.JSONObject.quote(searchEngineName());
            webView.evaluateJavascript("window.INFIN8_SEARCH_TEMPLATE=" + template + ";window.INFIN8_SEARCH_LABEL=" + label + ";var q=document.getElementById('q');if(q){q.placeholder='Private search with '+window.INFIN8_SEARCH_LABEL;}", null);
        } catch (Exception ignored) {}
    }

    private void installWebRtcShield() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        String script = "(() => { try {" +
                "Object.defineProperty(window,'RTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'webkitRTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'mozRTCPeerConnection',{value:undefined,configurable:false});" +
                "} catch(e) {} })();";
        try { WebViewCompat.addDocumentStartJavaScript(webView, script, Collections.singleton("*")); } catch (Exception ignored) {}
    }

    private boolean isBlockedHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.US);
        String[] blocked = {
                "doubleclick.net", "googlesyndication.com", "googleadservices.com",
                "facebook.net", "connect.facebook.net", "analytics.google.com",
                "scorecardresearch.com", "taboola.com", "outbrain.com", "adnxs.com"
        };
        for (String suffix : blocked) if (h.equals(suffix) || h.endsWith("." + suffix)) return true;
        return false;
    }

    private String buildSearchUrl(String query) {
        return searchTemplate().replace("%s", urlEncode(query));
    }

    private String searchTemplate() {
        switch (searchEngine) {
            case "startpage": return "https://www.startpage.com/sp/search?query=%s";
            case "duckduckgo": return "https://duckduckgo.com/?q=%s";
            case "bing": return "https://www.bing.com/search?q=%s";
            case "brave": return "https://search.brave.com/search?q=%s";
            default: return "https://www.google.com/search?q=%s";
        }
    }

    private String searchEngineName() {
        switch (searchEngine) {
            case "startpage": return "Startpage";
            case "duckduckgo": return "DuckDuckGo";
            case "bing": return "Bing";
            case "brave": return "Brave Search";
            default: return "Google";
        }
    }

    private String safeEngine(String id) {
        if ("startpage".equals(id) || "duckduckgo".equals(id) || "bing".equals(id) || "brave".equals(id)) return id;
        return "google";
    }

    private String urlEncode(String value) {
        try { return URLEncoder.encode(value, "UTF-8"); }
        catch (Exception ignored) { return value.replace(" ", "+"); }
    }

    private void clearPrivateProfile() {
        try {
            CookieManager cookies = CookieManager.getInstance();
            cookies.removeAllCookies(null);
            cookies.flush();
        } catch (Exception ignored) {}
        try { WebStorage.getInstance().deleteAllData(); } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (lastVerifiedAt > 0 && System.currentTimeMillis() - lastVerifiedAt > REVERIFY_MS) {
            verifyUsaAndContinue(null, false);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else finish();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        closeGate();
        if (verifier != null) verifier.shutdown();
        if (webView != null) {
            try {
                webView.stopLoading();
                webView.clearHistory();
                webView.clearCache(true);
                webView.clearFormData();
                webView.loadUrl("about:blank");
                webView.removeAllViews();
                webView.destroy();
            } catch (Exception ignored) {}
            webView = null;
        }
        clearPrivateProfile();
        super.onDestroy();
    }

    private int backgroundColor() { return "amoled".equals(themeMode) ? 0xFF000000 : 0xFF05080D; }
    private int surfaceColor() { return "amoled".equals(themeMode) ? 0xFF07090D : 0xFF0B0F16; }
    private int panelColor() { return "amoled".equals(themeMode) ? 0xFF070B11 : 0xFF08111D; }
    private int accentColor() {
        if ("purple".equals(accentId)) return 0xFF8B7CFF;
        if ("green".equals(accentId)) return 0xFF35C98B;
        if ("orange".equals(accentId)) return 0xFFFF9B55;
        if ("cyan".equals(accentId)) return 0xFF45C7FF;
        return 0xFF58A6FF;
    }
    private int accentStrongColor() {
        if ("purple".equals(accentId)) return 0xFF6D5FEF;
        if ("green".equals(accentId)) return 0xFF149E67;
        if ("orange".equals(accentId)) return 0xFFDF7331;
        if ("cyan".equals(accentId)) return 0xFF1599D4;
        return 0xFF0967E8;
    }

    private TextView text(String value, int size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }
}
