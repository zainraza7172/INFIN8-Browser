package com.infin8.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Typeface;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import androidx.webkit.Profile;

import com.wireguard.android.backend.Tunnel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.Locale;
import java.util.concurrent.Executor;

public class MainActivity extends Activity implements WireGuardManager.Listener {
    private static final String HOME_URL = "https://appassets.androidplatform.net/assets/start.html";
    private static final String LEGACY_HOME_URL = "file:///android_asset/start.html";
    private static final int FILE_CHOOSER_REQUEST = 501;
    private static final int WG_CONFIG_REQUEST = 502;
    private static final int VPN_PERMISSION_REQUEST = 503;
    private static final long REVERIFY_INTERVAL_MS = 10L * 60L * 1000L;
    private static final String BROWSER_PREFS = "infin8_browser_data";
    private static final String KEY_BOOKMARKS = "bookmarks_json";
    private static final String KEY_HISTORY = "history_json";
    private static final String KEY_TAB_SESSION = "tab_session_json";
    private static final String KEY_CURRENT_TAB = "current_tab_index";
    private static final String TAB_SESSION_FILE = "tab_session_backup.json";
    private static final String KEY_KEEP_VPN_CONNECTED = "keep_vpn_connected";
    private static final String KEY_WELCOME_SHOWN = "welcome_shown_v1";
    private static final String KEY_ADBLOCK_ENABLED = "adblock_enabled";
    private static final String KEY_SEARCH_ENGINE = "search_engine";
    private static final String KEY_THIRD_PARTY_COOKIES = "third_party_cookies";
    private static final String KEY_ALLOW_POPUPS = "allow_popups";
    private static final String KEY_DEFAULT_DESKTOP = "default_desktop_mode";
    private static final String KEY_CLOSED_TABS = "closed_tabs_json";
    private static final String KEY_SITE_PERMISSIONS = "site_permissions_json";
    private static final String KEY_SITE_PERMISSION_MODE = "site_permission_mode";
    private static final String KEY_SITE_PRIVACY = "site_privacy_json";
    private static final String KEY_SYSTEM_AUTOFILL = "system_autofill";
    private static final String KEY_KEEP_BROWSER_ACTIVE = "keep_browser_active_background";
    private static final String KEY_SMART_MEMORY_SAVER = "smart_memory_saver";
    private static final String KEY_ASK_EXTERNAL_APPS = "ask_before_external_apps";
    private static final String KEY_HOME_STORAGE_MIGRATED = "home_storage_migrated_v23";
    private static final String KEY_HOME_SPEED_DIAL_PENDING = "home_speed_dial_pending_v23";
    private static final int WEB_PERMISSION_REQUEST = 504;
    private static final int MAX_SAVED_TABS = 20;
    private static final String DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36";
    private static final int MAX_HISTORY_ITEMS = 100;

    private final List<BrowserTab> tabs = new ArrayList<>();
    private int currentTab = -1;

    private FrameLayout webContainer;
    private LinearLayout navBar;
    private EditText addressBar;
    private ImageButton menuButton;
    private ProgressBar progressBar;
    private HorizontalScrollView tabStripScroll;
    private LinearLayout tabStrip;
    private LinearLayout bottomTabsButton;
    private LinearLayout bottomSearchButton;
    private LinearLayout bottomHomeButton;
    private LinearLayout bottomMenuButton;
    private TextView bottomHomeLabel;
    private TextView bottomTabsLabel;
    private TextView bottomSearchLabel;
    private TextView bottomMenuLabel;
    private ImageView bottomHomeIcon;
    private ImageView bottomTabsIcon;
    private ImageView bottomSearchIcon;
    private ImageView bottomMenuIcon;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingWebPermissionRequest;
    private boolean pendingRememberPermission;
    private String pendingPermissionOrigin = "";
    private String lastThemeSignature = "";
    private WireGuardManager wireGuard;
    private UsaNetworkVerifier usaVerifier;
    private boolean destroyed;
    private boolean restoringSession;
    private View customView;
    private FrameLayout fullscreenContainer;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int originalSystemUiVisibility;
    private int originalRequestedOrientation;
    private boolean usaVerified;
    private boolean webGateOpen;
    private String verificationSummary = "USA exit not verified";
    private String verifiedIp = "";
    private String verifiedLocation = "";
    private long lastVerifiedAt;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Set<String> detectedMedia = Collections.synchronizedSet(new LinkedHashSet<>());
    private OnBackInvokedCallback backInvokedCallback;
    private final Executor proxyExecutor = Runnable::run;
    private WebViewAssetLoader assetLoader;
    private String activeProfileId = BrowserProfiles.DEFAULT_ID;
    private final Runnable periodicReverify = () -> {
        if (destroyed) return;
        if (ConnectionSettings.isProxyMode(this)) {
            if (ConnectionSettings.proxyConnected(this)) verifyProxyExit(false);
        } else if (wireGuard != null && wireGuard.isConnected()) {
            verifyUsaExit(false);
        }
    };
    private final Runnable sessionCheckpoint = new Runnable() {
        @Override
        public void run() {
            if (destroyed) return;
            saveTabSession();
            mainHandler.postDelayed(this, 30_000L);
        }
    };

    private final Runnable reconnectWireGuardAfterUnexpectedDrop = () -> {
        if (destroyed
                || ConnectionSettings.isProxyMode(this)
                || !shouldKeepVpnConnected()
                || wireGuard == null
                || !wireGuard.hasConfig()
                || wireGuard.isConnected()) {
            return;
        }
        if (wireGuard.getVpnPermissionIntent() != null) return;
        startVpnKeepAliveService();
        wireGuard.connect();
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Locale.setDefault(Locale.US);
        lastThemeSignature = ThemePalette.signature(this);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        wireGuard = new WireGuardManager(this, this);
        usaVerifier = new UsaNetworkVerifier();
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        activeProfileId = BrowserProfiles.activeId(this);
        ConnectionSettings.migrateLegacyProfileProxy(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { WebView.startSafeBrowsing(this, value -> {}); } catch (Exception ignored) {}
        }
        setContentView(buildUi());
        migrateLegacyHomeStorageIfNeeded();
        updateSearchUi();
        registerModernBackHandler();
        closeWebGate("USA exit not verified", false);
        if (!restoreTabSession()) createTab(HOME_URL, true);
        updateUsaButton();
        syncBackgroundBrowserService();
        mainHandler.postDelayed(sessionCheckpoint, 30_000L);

        if (savedInstanceState == null && !browserPrefs().getBoolean(KEY_WELCOME_SHOWN, false)) {
            browserPrefs().edit().putBoolean(KEY_WELCOME_SHOWN, true).commit();
            showWelcomeSplash();
        }

        if (ConnectionSettings.isProxyMode(this)) {
            setKeepVpnConnected(false);
            stopVpnKeepAliveService();
            wireGuard.refreshState();
            if (ConnectionSettings.proxyConnected(this) && ConnectionSettings.hasProxy(this)) {
                webContainer.postDelayed(() -> verifyProxyExit(false), 450);
            }
        } else if (wireGuard.hasConfig() && shouldKeepVpnConnected()) {
            startVpnKeepAliveService();
            wireGuard.refreshState();
            webContainer.postDelayed(() -> {
                if (!wireGuard.isConnected() && shouldKeepVpnConnected()) {
                    ensureVpnPermissionThenConnect();
                }
            }, 700);
        }

        handleIncomingIntent(getIntent());
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(ThemePalette.background(this));

        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.HORIZONTAL);
        navBar.setGravity(Gravity.CENTER_VERTICAL);
        navBar.setBackgroundColor(ThemePalette.surface(this));
        navBar.setPadding(dp(10), dp(7), dp(10), dp(7));
        LinearLayout.LayoutParams navLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        navLp.setMargins(0, dp(28), 0, 0);
        navBar.setLayoutParams(navLp);

        LinearLayout addressShell = new LinearLayout(this);
        addressShell.setOrientation(LinearLayout.HORIZONTAL);
        addressShell.setGravity(Gravity.CENTER_VERTICAL);
        addressShell.setBackground(pillBackground(0xFF171D27, 15));
        addressShell.setPadding(dp(10), 0, dp(10), 0);
        addressShell.setLayoutParams(new LinearLayout.LayoutParams(0, dp(40), 1f));

        TextView searchGlyph = new TextView(this);
        searchGlyph.setText("⌕");
        searchGlyph.setTextColor(ThemePalette.accent(this));
        searchGlyph.setTextSize(18);

        addressBar = new EditText(this);
        addressBar.setSingleLine(true);
        addressBar.setHint("Search or type URL");
        addressBar.setTextSize(14);
        addressBar.setTextColor(0xFFFFFFFF);
        addressBar.setHintTextColor(0xFF8E99AA);
        addressBar.setPadding(dp(10), 0, 0, 0);
        addressBar.setBackgroundColor(0x00000000);
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        addressShell.addView(searchGlyph);
        addressShell.addView(addressBar);

        navBar.addView(addressShell);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        webContainer = new FrameLayout(this);
        webContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabStrip.setGravity(Gravity.CENTER_VERTICAL);
        tabStrip.setPadding(dp(8), dp(2), dp(8), dp(5));

        tabStripScroll = new HorizontalScrollView(this);
        tabStripScroll.setHorizontalScrollBarEnabled(false);
        tabStripScroll.setFillViewport(false);
        tabStripScroll.addView(tabStrip, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)));

        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackground(darkRoundedBackground(ThemePalette.surface(this), 0, 0xFF1A2636, 1));
        bottomBar.setPadding(dp(8), dp(5), dp(8), dp(8));

        bottomHomeButton = bottomNavItem(R.drawable.ic_home, "Home", true);
        bottomHomeIcon = (ImageView) bottomHomeButton.getChildAt(0);
        bottomHomeLabel = (TextView) bottomHomeButton.getChildAt(1);
        bottomTabsButton = bottomNavItem(R.drawable.ic_tabs, "Tabs", false);
        bottomTabsIcon = (ImageView) bottomTabsButton.getChildAt(0);
        bottomTabsLabel = (TextView) bottomTabsButton.getChildAt(1);
        bottomSearchButton = bottomNavItem(R.drawable.ic_search, "Search", false);
        bottomSearchIcon = (ImageView) bottomSearchButton.getChildAt(0);
        bottomSearchLabel = (TextView) bottomSearchButton.getChildAt(1);
        bottomMenuButton = bottomNavItem(R.drawable.ic_menu, "Menu", false);
        bottomMenuIcon = (ImageView) bottomMenuButton.getChildAt(0);
        bottomMenuLabel = (TextView) bottomMenuButton.getChildAt(1);

        bottomHomeButton.setLayoutParams(new LinearLayout.LayoutParams(0, dp(58), 1f));
        bottomTabsButton.setLayoutParams(new LinearLayout.LayoutParams(0, dp(58), 1f));
        bottomSearchButton.setLayoutParams(new LinearLayout.LayoutParams(0, dp(58), 1f));
        bottomMenuButton.setLayoutParams(new LinearLayout.LayoutParams(0, dp(58), 1f));

        bottomBar.addView(bottomHomeButton);
        bottomBar.addView(bottomTabsButton);
        bottomBar.addView(bottomSearchButton);
        bottomBar.addView(bottomMenuButton);

        root.addView(navBar);
        root.addView(progressBar);
        root.addView(webContainer);
        root.addView(bottomBar);

        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate(addressBar.getText().toString());
                return true;
            }
            return false;
        });

        bottomHomeButton.setOnClickListener(v -> navigate(HOME_URL));
        bottomTabsButton.setOnClickListener(v -> showTabsDialog());
        bottomSearchButton.setOnClickListener(v -> {
            if (isOnHomePage()) {
                WebView w = currentWebView();
                if (w != null) w.evaluateJavascript("document.getElementById('q') && document.getElementById('q').focus();", null);
            } else {
                addressBar.requestFocus();
                addressBar.selectAll();
            }
        });
        bottomMenuButton.setOnClickListener(this::showMainMenu);

        return root;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(7), 0, dp(7), 0);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    private LinearLayout bottomNavItem(int iconRes, String label, boolean active) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(0, dp(5), 0, dp(3));
        item.setBackgroundColor(0x00000000);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        int color = active ? ThemePalette.accent(this) : 0xFFAAB4C3;
        icon.setColorFilter(color);
        item.addView(icon, new LinearLayout.LayoutParams(dp(23), dp(23)));

        TextView text = new TextView(this);
        text.setText(label);
        text.setTextSize(11);
        text.setTextColor(color);
        text.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        text.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.setMargins(0, dp(2), 0, 0);
        item.addView(text, tlp);
        return item;
    }

    private ImageButton logoMenuButton() {
        ImageButton b = new ImageButton(this);
        b.setScaleType(ImageView.ScaleType.CENTER_CROP);
        b.setAdjustViewBounds(true);
        b.setPadding(dp(3), dp(3), dp(3), dp(3));
        b.setBackground(pillBackground(0xFF111722, 12));
        try (InputStream is = getAssets().open("browser_logo.png")) {
            Bitmap bmp = BitmapFactory.decodeStream(is);
            b.setImageBitmap(bmp);
        } catch (Exception e) {
            b.setImageResource(android.R.drawable.ic_menu_more);
        }
        return b;
    }

    private void createTab(String initialUrl, boolean switchToIt) {
        WebView webView = new WebView(this);
        applyActiveWebViewProfile(webView);
        configureWebView(webView);
        BrowserTab currentBefore = currentBrowserTab();
        BrowserTab tab = new BrowserTab(webView, "New Tab", initialUrl);
        tab.profileId = activeProfileId;
        if (currentBefore != null) tab.groupName = normalizeGroupName(currentBefore.groupName);
        tab.desktopMode = browserPrefs().getBoolean(KEY_DEFAULT_DESKTOP, false);
        if (tab.desktopMode) configureDesktopSettings(tab, true);
        tabs.add(tab);
        if (switchToIt) switchToTab(tabs.size() - 1);
        webView.loadUrl(initialUrl);
        updateTabCount();
        refreshTabStrip();
        if (!restoringSession) saveTabSession();
    }

    private void createRestoredTab(String title, String url, boolean desktopMode, String groupName, boolean switchToIt) {
        WebView webView = new WebView(this);
        applyActiveWebViewProfile(webView);
        configureWebView(webView);
        String savedUrl = normalizeInternalUrl((url == null || url.trim().isEmpty()) ? HOME_URL : url.trim());
        BrowserTab tab = new BrowserTab(webView, title == null || title.trim().isEmpty() ? "New Tab" : title, savedUrl);
        tab.profileId = activeProfileId;
        tab.desktopMode = desktopMode;
        tab.groupName = normalizeGroupName(groupName);
        tabs.add(tab);
        if (!HOME_URL.equals(savedUrl) && isNetworkUrl(savedUrl)) {
            tab.pendingRestoreUrl = savedUrl;
            if (desktopMode) configureDesktopSettings(tab, true);
            webView.loadUrl(HOME_URL);
        } else {
            webView.loadUrl(savedUrl);
        }
        if (switchToIt) switchToTab(tabs.size() - 1);
    }

    private void configureWebView(WebView webView) {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { s.setSafeBrowsingEnabled(true); } catch (Exception ignored) {}
        }
        boolean autofill = browserPrefs().getBoolean(KEY_SYSTEM_AUTOFILL, true);
        s.setSaveFormData(autofill);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.setImportantForAutofill(autofill ? View.IMPORTANT_FOR_AUTOFILL_YES : View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        }
        boolean allowPopups = arePopupsAllowed();
        s.setSupportMultipleWindows(allowPopups);
        s.setJavaScriptCanOpenWindowsAutomatically(allowPopups);
        applyProfileBrowserIdentity(webView);

        CookieManager cm = cookieManagerFor(webView);
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, areThirdPartyCookiesAllowed());
        installWebRtcShield(webView);
        installProfileEnvironment(webView);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                applySiteCookiePolicy(view, url);
                BrowserTab tab = tabFor(view);
                if (tab != null && url != null && !url.trim().isEmpty()) {
                    if (!(HOME_URL.equals(url) && tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty())) tab.url = url;
                    if (!restoringSession) saveTabSession();
                }
                if (!HOME_URL.equals(url)) addressBar.setText(url);
                updateNavState();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                BrowserTab tab = tabFor(view);
                if (tab != null) {
                    boolean holdingRestoredPage = HOME_URL.equals(url) && tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty();
                    if (!holdingRestoredPage) {
                        tab.url = url;
                        tab.title = view.getTitle() == null || view.getTitle().trim().isEmpty() ? url : view.getTitle();
                        if (url != null && url.equals(tab.pendingRestoreUrl)) tab.pendingRestoreUrl = "";
                    }
                    if (tab.desktopMode && url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                        enforceDesktopViewport(view);
                    }
                }
                if (view == currentWebView()) {
                    String shownUrl = tab != null && tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty() ? tab.pendingRestoreUrl : url;
                    addressBar.setText(shownUrl == null || HOME_URL.equals(shownUrl) ? "" : shownUrl);
                }
                if (HOME_URL.equals(url)) injectHomeSearchSettings(view);
                if (url != null && !HOME_URL.equals(url) && isNetworkUrl(url)) {
                    recordHistory(view.getTitle(), url);
                }
                updateNavState();
                refreshTabStrip();
                if (!restoringSession) saveTabSession();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null) {
                    WebResourceResponse local = assetLoader == null ? null : assetLoader.shouldInterceptRequest(uri);
                    if (local != null) return local;
                    maybeRecordMediaUrl(uri.toString());
                    if (isAdBlockEnabledForPage(view) && isBlockedHost(uri.getHost())) {
                        PrivacyStats.recordBlocked(getApplicationContext(), uri.getHost());
                        return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return true;
                String target = uri.toString();
                if (HOME_URL.equals(target) || target.startsWith(HOME_URL)) return false;
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (!isInternetAllowed()) {
                        toast("USA exit must be verified before opening the internet.");
                        showUsaModeDialog();
                        return true;
                    }
                    return false;
                }
                if ("infin8-profile".equalsIgnoreCase(scheme)) {
                    startActivity(new Intent(MainActivity.this, ProfileManagerActivity.class));
                    return true;
                }
                if ("file".equalsIgnoreCase(scheme) || "content".equalsIgnoreCase(scheme)) {
                    toast("Local file/content navigation is blocked");
                    return true;
                }
                return handleExternalNavigation(uri);
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                if (handler != null) handler.cancel();
                toast("Blocked page with an invalid SSL certificate");
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                recoverCrashedRenderer(view);
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                BrowserTab tab = tabFor(view);
                if (tab != null && title != null) tab.title = title;
                refreshTabStrip();
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, false, false);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                handleWebPermissionRequest(request);
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWebPermissionRequest == request) clearPendingWebPermission();
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                showFullscreenVideo(view, callback);
            }

            @Override
            public void onHideCustomView() {
                hideFullscreenVideo();
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!arePopupsAllowed()) return false;
                WebView popup = createPopupTab();
                if (popup == null) return false;
                try {
                    WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                    transport.setWebView(popup);
                    resultMsg.sendToTarget();
                    return true;
                } catch (Exception e) {
                    BrowserTab tab = tabFor(popup);
                    if (tab != null) closeTab(tabs.indexOf(tab));
                    return false;
                }
            }

            @Override
            public void onCloseWindow(WebView window) {
                BrowserTab tab = tabFor(window);
                if (tab != null) {
                    int index = tabs.indexOf(tab);
                    if (index >= 0) closeTab(index);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    toast("No file picker available.");
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
                showDownloadPrompt(url, userAgent, contentDisposition, mimeType, contentLength));
    }

    private void applyDesktopMode(BrowserTab tab, boolean enabled) {
        if (tab == null) return;
        tab.desktopMode = enabled;
        configureDesktopSettings(tab, enabled);
        saveTabSession();
        tab.webView.reload();
    }

    private void configureDesktopSettings(BrowserTab tab, boolean enabled) {
        if (tab == null) return;
        WebSettings settings = tab.webView.getSettings();
        settings.setUserAgentString(enabled ? DESKTOP_UA : profileBaseUserAgent());
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        tab.webView.setInitialScale(0);
    }

    private void enforceDesktopViewport(WebView view) {
        String js = "(function(){try{" +
                "var m=document.querySelector('meta[name=\"viewport\"]');" +
                "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}" +
                "m.setAttribute('content','width=1200, initial-scale=0.3, minimum-scale=0.1, maximum-scale=5.0, user-scalable=yes');" +
                "document.documentElement.style.minWidth='1200px';" +
                "if(document.body){document.body.style.minWidth='1200px';}" +
                "}catch(e){}})();";
        try { view.evaluateJavascript(js, null); } catch (Exception ignored) {}
    }

    private void showFullscreenVideo(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            if (callback != null) callback.onCustomViewHidden();
            return;
        }
        customView = view;
        customViewCallback = callback;
        originalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
        originalRequestedOrientation = getRequestedOrientation();

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addContentView(fullscreenContainer, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR); } catch (Exception ignored) {}
    }

    private void hideFullscreenVideo() {
        if (customView == null) return;
        try {
            if (fullscreenContainer != null && fullscreenContainer.getParent() instanceof ViewGroup) {
                ((ViewGroup) fullscreenContainer.getParent()).removeView(fullscreenContainer);
            }
        } catch (Exception ignored) {}
        customView = null;
        fullscreenContainer = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(originalSystemUiVisibility);
        try { setRequestedOrientation(originalRequestedOrientation); } catch (Exception ignored) {}
        if (customViewCallback != null) {
            try { customViewCallback.onCustomViewHidden(); } catch (Exception ignored) {}
            customViewCallback = null;
        }
    }

    private BrowserTab currentBrowserTab() {
        if (currentTab < 0 || currentTab >= tabs.size()) return null;
        return tabs.get(currentTab);
    }

    private void installWebRtcShield(WebView webView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        String script = "(() => { try {" +
                "Object.defineProperty(window,'RTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'webkitRTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'mozRTCPeerConnection',{value:undefined,configurable:false});" +
                "} catch(e) {} })();";
        try {
            WebViewCompat.addDocumentStartJavaScript(webView, script, Collections.singleton("*"));
        } catch (Exception ignored) {}
    }

    private String getSearchEngineId() {
        String id = browserPrefs().getString(KEY_SEARCH_ENGINE, "google");
        if (id == null) return "google";
        switch (id) {
            case "startpage":
            case "duckduckgo":
            case "bing":
            case "brave":
            case "google":
                return id;
            default:
                return "google";
        }
    }

    private String getSearchEngineName() {
        switch (getSearchEngineId()) {
            case "startpage": return "Startpage";
            case "duckduckgo": return "DuckDuckGo";
            case "bing": return "Bing";
            case "brave": return "Brave Search";
            default: return "Google";
        }
    }

    private String getSearchTemplate() {
        switch (getSearchEngineId()) {
            case "startpage": return "https://www.startpage.com/sp/search?query=%s";
            case "duckduckgo": return "https://duckduckgo.com/?q=%s";
            case "bing": return "https://www.bing.com/search?q=%s";
            case "brave": return "https://search.brave.com/search?q=%s";
            default: return "https://www.google.com/search?q=%s";
        }
    }

    private String buildSearchUrl(String query) {
        return getSearchTemplate().replace("%s", urlEncode(query));
    }

    private void updateSearchUi() {
        if (addressBar != null) addressBar.setHint("Search " + getSearchEngineName() + " or type URL");
    }

    private void injectHomeSearchSettings(WebView view) {
        if (view == null) return;
        try {
            String template = JSONObject.quote(getSearchTemplate());
            String label = JSONObject.quote(getSearchEngineName());
            String profileName = JSONObject.quote(BrowserProfiles.active(this).name);
            view.evaluateJavascript("window.INFIN8_SEARCH_TEMPLATE=" + template + ";window.INFIN8_SEARCH_LABEL=" + label + ";var q=document.getElementById('q');if(q){q.placeholder='Search '+window.INFIN8_SEARCH_LABEL+' or type web address';}var p=document.getElementById('profilePill');if(p){p.textContent='Profile • '+" + profileName + ";}", null);
            String pending = browserPrefs().getString(KEY_HOME_SPEED_DIAL_PENDING, "");
            if (pending != null && !pending.trim().isEmpty()) {
                String migration = "try{if(!localStorage.getItem('infin8_speed_dial_v1')){localStorage.setItem('infin8_speed_dial_v1'," + JSONObject.quote(pending) + ");location.reload();}}catch(e){}";
                view.evaluateJavascript(migration, value ->
                        browserPrefs().edit().remove(KEY_HOME_SPEED_DIAL_PENDING).apply());
            }
        } catch (Exception ignored) {}
    }

    private void migrateLegacyHomeStorageIfNeeded() {
        if (browserPrefs().getBoolean(KEY_HOME_STORAGE_MIGRATED, false)) return;
        try {
            WebView migration = new WebView(this);
            WebSettings s = migration.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowContentAccess(false);
            s.setBlockNetworkLoads(true);
            migration.setWebViewClient(new WebViewClient() {
                private boolean handled;

                @Override
                public void onPageFinished(WebView view, String url) {
                    if (handled || !LEGACY_HOME_URL.equals(url)) return;
                    handled = true;
                    view.evaluateJavascript("(function(){try{return localStorage.getItem('infin8_speed_dial_v1')||'';}catch(e){return '';}})()", result -> {
                        try {
                            String migrated = "";
                            if (result != null && !"null".equals(result)) {
                                JSONArray parsed = new JSONArray("[" + result + "]");
                                migrated = parsed.optString(0, "");
                            }
                            SharedPreferences.Editor editor = browserPrefs().edit()
                                    .putBoolean(KEY_HOME_STORAGE_MIGRATED, true);
                            if (migrated != null && !migrated.trim().isEmpty() && !"[]".equals(migrated.trim())) {
                                editor.putString(KEY_HOME_SPEED_DIAL_PENDING, migrated);
                            }
                            editor.apply();
                        } catch (Exception ignored) {
                            browserPrefs().edit().putBoolean(KEY_HOME_STORAGE_MIGRATED, true).apply();
                        }
                        try {
                            view.stopLoading();
                            view.destroy();
                        } catch (Exception ignored) {}
                        WebView current = currentWebView();
                        if (current != null && HOME_URL.equals(current.getUrl())) injectHomeSearchSettings(current);
                    });
                }
            });
            migration.loadUrl(LEGACY_HOME_URL);
        } catch (Exception ignored) {
            browserPrefs().edit().putBoolean(KEY_HOME_STORAGE_MIGRATED, true).apply();
        }
    }

    private boolean areThirdPartyCookiesAllowed() {
        return browserPrefs().getBoolean(KEY_THIRD_PARTY_COOKIES, true);
    }

    private String hostForUrl(String url) {
        try {
            Uri uri = Uri.parse(url == null ? "" : url);
            String host = uri.getHost();
            return host == null ? "" : host.toLowerCase(Locale.US);
        } catch (Exception ignored) {
            return "";
        }
    }

    private JSONObject sitePrivacyRoot() {
        try {
            return new JSONObject(browserPrefs().getString(KEY_SITE_PRIVACY, "{}"));
        } catch (Exception ignored) {
            return new JSONObject();
        }
    }

    private JSONObject sitePrivacyFor(String url) {
        String host = hostForUrl(url);
        if (host.isEmpty()) return null;
        return sitePrivacyRoot().optJSONObject(host);
    }

    private boolean areThirdPartyCookiesAllowedFor(String url) {
        JSONObject site = sitePrivacyFor(url);
        if (site != null && site.has("thirdPartyCookies")) return site.optBoolean("thirdPartyCookies", areThirdPartyCookiesAllowed());
        return areThirdPartyCookiesAllowed();
    }

    private boolean isAdBlockEnabledForPage(WebView view) {
        BrowserTab tab = tabFor(view);
        String pageUrl = tab == null ? "" : (tab.url == null ? "" : tab.url);
        JSONObject site = sitePrivacyFor(pageUrl);
        if (site != null && site.has("adblock")) return site.optBoolean("adblock", isAdBlockEnabled());
        return isAdBlockEnabled();
    }

    private void applySiteCookiePolicy(WebView view, String url) {
        if (view == null) return;
        try { CookieManager.getInstance().setAcceptThirdPartyCookies(view, areThirdPartyCookiesAllowedFor(url)); } catch (Exception ignored) {}
    }

    private void saveSitePrivacy(String host, Boolean adblock, Boolean thirdPartyCookies) {
        if (host == null || host.trim().isEmpty()) return;
        try {
            JSONObject root = sitePrivacyRoot();
            if (adblock == null && thirdPartyCookies == null) {
                root.remove(host);
            } else {
                JSONObject item = root.optJSONObject(host);
                if (item == null) item = new JSONObject();
                if (adblock == null) item.remove("adblock"); else item.put("adblock", adblock.booleanValue());
                if (thirdPartyCookies == null) item.remove("thirdPartyCookies"); else item.put("thirdPartyCookies", thirdPartyCookies.booleanValue());
                if (item.length() == 0) root.remove(host); else root.put(host, item);
            }
            browserPrefs().edit().putString(KEY_SITE_PRIVACY, root.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void showSitePrivacyDialog() {
        BrowserTab tab = currentBrowserTab();
        if (tab == null) return;
        String url = tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty() ? tab.pendingRestoreUrl : tab.url;
        String host = hostForUrl(url);
        if (host.isEmpty()) { toast("Site privacy is available on web pages"); return; }
        JSONObject saved = sitePrivacyFor(url);
        boolean currentAdblock = saved != null && saved.has("adblock") ? saved.optBoolean("adblock") : isAdBlockEnabled();
        boolean currentCookies = saved != null && saved.has("thirdPartyCookies") ? saved.optBoolean("thirdPartyCookies") : areThirdPartyCookiesAllowed();

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(darkRoundedBackground(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));
        card.addView(dialogText("Site privacy", 23, Color.WHITE, Typeface.BOLD));
        TextView hostView = dialogText(host, 12, 0xFF8494AA, Typeface.NORMAL);
        hostView.setPadding(0, dp(4), 0, dp(14));
        card.addView(hostView);

        TextView ad = dialogText("Ad & tracker protection: " + (currentAdblock ? "ON" : "OFF"), 15, 0xFFEAF2FF, Typeface.BOLD);
        ad.setGravity(Gravity.CENTER_VERTICAL); ad.setPadding(dp(14),0,dp(14),0);
        ad.setBackground(darkRoundedBackground(0xFF0D1A2A,16,0xFF1A3555,1));
        card.addView(ad, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        TextView cookies = dialogText("Third-party cookies: " + (currentCookies ? "ON" : "OFF"), 15, 0xFFEAF2FF, Typeface.BOLD);
        cookies.setGravity(Gravity.CENTER_VERTICAL); cookies.setPadding(dp(14),0,dp(14),0);
        cookies.setBackground(darkRoundedBackground(0xFF0D1A2A,16,0xFF1A3555,1));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)); clp.setMargins(0,dp(8),0,0);
        card.addView(cookies, clp);
        TextView reset = dialogText("Use global defaults", 14, ThemePalette.accent(this), Typeface.BOLD);
        reset.setGravity(Gravity.CENTER); reset.setPadding(0,dp(14),0,0); card.addView(reset);

        final boolean[] adState = {currentAdblock};
        final boolean[] cookieState = {currentCookies};
        ad.setOnClickListener(v -> {
            adState[0] = !adState[0];
            saveSitePrivacy(host, adState[0], cookieState[0]);
            ad.setText("Ad & tracker protection: " + (adState[0] ? "ON" : "OFF"));
            WebView w = currentWebView(); if (w != null) w.reload();
        });
        cookies.setOnClickListener(v -> {
            cookieState[0] = !cookieState[0];
            saveSitePrivacy(host, adState[0], cookieState[0]);
            cookies.setText("Third-party cookies: " + (cookieState[0] ? "ON" : "OFF"));
            applySiteCookiePolicy(currentWebView(), url);
        });
        reset.setOnClickListener(v -> {
            saveSitePrivacy(host, null, null);
            applySiteCookiePolicy(currentWebView(), url);
            dialog.dismiss();
            WebView w = currentWebView(); if (w != null) w.reload();
            toast("Site privacy reset to global defaults");
        });
        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT; lp.gravity = Gravity.CENTER; window.setAttributes(lp);
        }
        dialog.show();
    }

    private boolean arePopupsAllowed() {
        return browserPrefs().getBoolean(KEY_ALLOW_POPUPS, false);
    }

    private void applyBrowserPreferencesToTabs() {
        updateSearchUi();
        for (BrowserTab tab : tabs) {
            try {
                WebSettings settings = tab.webView.getSettings();
                boolean allowPopups = arePopupsAllowed();
                settings.setSupportMultipleWindows(allowPopups);
                settings.setJavaScriptCanOpenWindowsAutomatically(allowPopups);
                String currentUrl = tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty() ? tab.pendingRestoreUrl : tab.url;
                CookieManager.getInstance().setAcceptThirdPartyCookies(tab.webView, areThirdPartyCookiesAllowedFor(currentUrl));
                boolean autofill = browserPrefs().getBoolean(KEY_SYSTEM_AUTOFILL, true);
                settings.setSaveFormData(autofill);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    tab.webView.setImportantForAutofill(autofill ? View.IMPORTANT_FOR_AUTOFILL_YES : View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
                }
                if (HOME_URL.equals(tab.webView.getUrl())) injectHomeSearchSettings(tab.webView);
            } catch (Exception ignored) {}
        }
    }

    private WebView createPopupTab() {
        try {
            WebView webView = new WebView(this);
            configureWebView(webView);
            BrowserTab sourceTab = currentBrowserTab();
            BrowserTab tab = new BrowserTab(webView, "New Tab", "about:blank");
            if (sourceTab != null) tab.groupName = normalizeGroupName(sourceTab.groupName);
            tab.desktopMode = browserPrefs().getBoolean(KEY_DEFAULT_DESKTOP, false);
            if (tab.desktopMode) configureDesktopSettings(tab, true);
            tabs.add(tab);
            switchToTab(tabs.size() - 1);
            updateTabCount();
            refreshTabStrip();
            saveTabSession();
            return webView;
        } catch (Exception e) {
            toast("Could not open new window");
            return null;
        }
    }

    private void openIncognitoWindow() {
        try {
            Intent intent = new Intent(this, IncognitoActivity.class);
            intent.putExtra("search_engine", getSearchEngineId());
            intent.putExtra("theme_mode", browserPrefs().getString(ThemePalette.KEY_THEME_MODE, "dark"));
            intent.putExtra("accent_color", browserPrefs().getString(ThemePalette.KEY_ACCENT, "blue"));
            intent.putExtra("secure_screen", browserPrefs().getBoolean(ThemePalette.KEY_INCOGNITO_SECURE, true));
            intent.putExtra("ask_external_apps", browserPrefs().getBoolean(KEY_ASK_EXTERNAL_APPS, true));
            intent.putExtra("connection_mode", ConnectionSettings.mode(this));
            intent.putExtra("proxy_url", ConnectionSettings.proxyUrl(this));
            intent.putExtra("proxy_connected", ConnectionSettings.proxyConnected(this));
            startActivity(intent);
        } catch (Exception e) {
            toast("Could not open Incognito");
        }
    }

    private void duplicateCurrentTab() {
        duplicateTabAt(currentTab);
    }

    private void duplicateTabAt(int index) {
        if (index < 0 || index >= tabs.size()) return;
        BrowserTab tab = tabs.get(index);
        String url = tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty()
                ? tab.pendingRestoreUrl
                : (tab.webView.getUrl() == null ? tab.url : tab.webView.getUrl());
        if (url == null || url.trim().isEmpty()) url = HOME_URL;
        createTab(normalizeInternalUrl(url), true);
        BrowserTab duplicated = currentBrowserTab();
        if (duplicated != null) {
            duplicated.groupName = normalizeGroupName(tab.groupName);
            if (tab.desktopMode != duplicated.desktopMode) applyDesktopMode(duplicated, tab.desktopMode);
            saveTabSession();
        }
    }

    private void showTabActions(int tabIndex) {
        if (tabIndex < 0 || tabIndex >= tabs.size()) return;
        BrowserTab tab = tabs.get(tabIndex);
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(darkRoundedBackground(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));
        card.addView(dialogText(shortTitle(tab.title), 20, Color.WHITE, Typeface.BOLD));
        String host = hostForUrl(tab.url);
        TextView sub = dialogText(host.isEmpty() ? "Tab actions" : host, 11, 0xFF7F91AA, Typeface.NORMAL);
        sub.setPadding(0, dp(3), 0, dp(10));
        card.addView(sub);

        TextView duplicate = menuRow("⧉", "Duplicate tab", true);
        TextView group = menuRow("▦", "Move to group", true);
        TextView copy = menuRow("⧉", "Copy link", tab.url != null && isNetworkUrl(tab.url) && !HOME_URL.equals(tab.url));
        TextView closeOthers = menuRow("×", "Close other tabs", tabs.size() > 1);
        TextView close = menuRow("×", "Close tab", true);
        TextView[] rows = {duplicate, group, copy, closeOthers, close};
        for (TextView row : rows) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            lp.setMargins(0, dp(7), 0, 0);
            card.addView(row, lp);
        }

        duplicate.setOnClickListener(v -> { dialog.dismiss(); duplicateTabAt(tabIndex); });
        group.setOnClickListener(v -> { dialog.dismiss(); showGroupPicker(tabIndex, this::refreshTabStrip); });
        copy.setOnClickListener(v -> {
            if (tab.url == null || !isNetworkUrl(tab.url) || HOME_URL.equals(tab.url)) return;
            dialog.dismiss();
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("INFIN8 link", tab.url));
            toast("Link copied");
        });
        closeOthers.setOnClickListener(v -> {
            if (tabs.size() <= 1) return;
            dialog.dismiss();
            closeOtherTabs(tabIndex);
        });
        close.setOnClickListener(v -> { dialog.dismiss(); closeTab(tabIndex); });

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void closeOtherTabs(int keepIndex) {
        if (keepIndex < 0 || keepIndex >= tabs.size()) return;
        BrowserTab keep = tabs.get(keepIndex);
        for (int i = 0; i < tabs.size(); i++) {
            if (i == keepIndex) continue;
            BrowserTab tab = tabs.get(i);
            rememberClosedTab(tab);
            try {
                if (tab.webView.getParent() instanceof ViewGroup) {
                    ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
                }
                tab.webView.stopLoading();
                tab.webView.destroy();
            } catch (Exception ignored) {}
        }
        tabs.clear();
        tabs.add(keep);
        currentTab = 0;
        switchToTab(0);
        saveTabSession();
        toast("Other tabs closed");
    }

    private boolean isNetworkUrl(String url) {
        return url != null && (url.startsWith("https://") || url.startsWith("http://"));
    }

    private String normalizeInternalUrl(String url) {
        if (url == null || url.trim().isEmpty()) return HOME_URL;
        String clean = url.trim();
        if (LEGACY_HOME_URL.equals(clean) || clean.startsWith(LEGACY_HOME_URL)) return HOME_URL;
        return clean;
    }

    private boolean handleExternalNavigation(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.US);
        boolean supported = "mailto".equals(scheme) || "tel".equals(scheme) || "sms".equals(scheme)
                || "smsto".equals(scheme) || "geo".equals(scheme) || "market".equals(scheme)
                || "intent".equals(scheme);
        if (!supported) {
            toast("Blocked unsupported external link");
            return true;
        }

        Runnable open = () -> {
            try {
                Intent external;
                String fallback = "";
                if ("intent".equals(scheme)) {
                    external = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                    fallback = external.getStringExtra("browser_fallback_url");
                    external.removeExtra("browser_fallback_url");
                    external.addCategory(Intent.CATEGORY_BROWSABLE);
                    external.setComponent(null);
                    external.setSelector(null);
                } else {
                    external = new Intent(Intent.ACTION_VIEW, uri);
                }
                if (external.resolveActivity(getPackageManager()) != null) {
                    startActivity(external);
                } else if (fallback != null && fallback.startsWith("https://")) {
                    navigate(fallback);
                } else {
                    toast("No app can open this link");
                }
            } catch (Exception e) {
                toast("External link could not be opened");
            }
        };

        if (browserPrefs().getBoolean(KEY_ASK_EXTERNAL_APPS, true)) {
            new AlertDialog.Builder(this)
                    .setTitle("Open another app?")
                    .setMessage("This website wants to open an external app (" + scheme + ").")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Open", (d, w) -> open.run())
                    .show();
        } else {
            open.run();
        }
        return true;
    }

    private void rememberClosedTab(BrowserTab tab) {
        if (tab == null) return;
        String url = tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty()
                ? tab.pendingRestoreUrl
                : (tab.webView.getUrl() == null ? tab.url : tab.webView.getUrl());
        if (url == null || url.trim().isEmpty() || HOME_URL.equals(url)) return;
        try {
            JSONArray array = new JSONArray(browserPrefs().getString(profileScopedKey(KEY_CLOSED_TABS), "[]"));
            JSONArray next = new JSONArray();
            JSONObject item = new JSONObject();
            item.put("title", tab.title == null ? "Closed tab" : tab.title);
            item.put("url", url);
            item.put("desktop", tab.desktopMode);
            item.put("group", normalizeGroupName(tab.groupName));
            next.put(item);
            for (int i = 0; i < array.length() && next.length() < 10; i++) {
                JSONObject old = array.optJSONObject(i);
                if (old != null) next.put(old);
            }
            browserPrefs().edit().putString(profileScopedKey(KEY_CLOSED_TABS), next.toString()).apply();
        } catch (Exception ignored) {}
    }

    private boolean hasClosedTabs() {
        try {
            return new JSONArray(browserPrefs().getString(profileScopedKey(KEY_CLOSED_TABS), "[]")).length() > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void reopenLastClosedTab() {
        try {
            JSONArray array = new JSONArray(browserPrefs().getString(profileScopedKey(KEY_CLOSED_TABS), "[]"));
            if (array.length() == 0) {
                toast("No recently closed tabs");
                return;
            }
            JSONObject item = array.optJSONObject(0);
            JSONArray next = new JSONArray();
            for (int i = 1; i < array.length(); i++) {
                JSONObject old = array.optJSONObject(i);
                if (old != null) next.put(old);
            }
            browserPrefs().edit().putString(profileScopedKey(KEY_CLOSED_TABS), next.toString()).apply();
            if (item == null) return;
            String url = item.optString("url", HOME_URL);
            boolean desktop = item.optBoolean("desktop", false);
            String group = item.optString("group", "Ungrouped");
            createTab(url, true);
            BrowserTab reopened = currentBrowserTab();
            if (reopened != null) {
                reopened.groupName = normalizeGroupName(group);
                if (desktop != reopened.desktopMode) applyDesktopMode(reopened, desktop);
                saveTabSession();
            }
        } catch (Exception e) {
            toast("Could not reopen tab");
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) return;
        runOnUiThread(() -> {
            String[] resources = request.getResources();
            boolean recognized = true;
            for (String resource : resources) {
                if (!PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                        && !PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                    recognized = false;
                    break;
                }
            }
            if (!recognized) {
                request.deny();
                return;
            }

            String origin = request.getOrigin() == null ? "unknown" : request.getOrigin().toString();
            String mode = browserPrefs().getString(KEY_SITE_PERMISSION_MODE, "ask");
            if ("block".equals(mode)) {
                request.deny();
                return;
            }
            String decision = getSitePermissionDecision(origin);
            if ("block".equals(decision)) {
                request.deny();
                return;
            }
            if ("allow".equals(decision)) {
                requestWebPermissionWithAndroidGrant(request, origin, true);
                return;
            }
            showWebPermissionPrompt(request, origin);
        });
    }

    private void showWebPermissionPrompt(PermissionRequest request, String origin) {
        String host = origin;
        try {
            Uri uri = Uri.parse(origin);
            if (uri.getHost() != null) host = uri.getHost();
        } catch (Exception ignored) {}
        final String displayHost = host;
        new AlertDialog.Builder(this)
                .setTitle("Site permission")
                .setMessage(displayHost + " wants to use your camera or microphone.")
                .setPositiveButton("Allow once", (dialog, which) -> requestWebPermissionWithAndroidGrant(request, origin, false))
                .setNeutralButton("Always allow", (dialog, which) -> requestWebPermissionWithAndroidGrant(request, origin, true))
                .setNegativeButton("Block", (dialog, which) -> {
                    setSitePermissionDecision(origin, "block");
                    request.deny();
                })
                .setOnCancelListener(dialog -> request.deny())
                .show();
    }

    private void requestWebPermissionWithAndroidGrant(PermissionRequest request, String origin, boolean remember) {
        boolean needsCamera = false;
        boolean needsMic = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) needsCamera = true;
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) needsMic = true;
        }
        List<String> missing = new ArrayList<>();
        if (needsCamera && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.CAMERA);
        }
        if (needsMic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.RECORD_AUDIO);
        }
        if (missing.isEmpty()) {
            if (remember) setSitePermissionDecision(origin, "allow");
            request.grant(request.getResources());
            return;
        }
        pendingWebPermissionRequest = request;
        pendingRememberPermission = remember;
        pendingPermissionOrigin = origin;
        requestPermissions(missing.toArray(new String[0]), WEB_PERMISSION_REQUEST);
    }

    private String getSitePermissionDecision(String origin) {
        try {
            JSONObject json = new JSONObject(browserPrefs().getString(KEY_SITE_PERMISSIONS, "{}"));
            return json.optString(origin, "");
        } catch (Exception ignored) {
            return "";
        }
    }

    private void setSitePermissionDecision(String origin, String decision) {
        try {
            JSONObject json = new JSONObject(browserPrefs().getString(KEY_SITE_PERMISSIONS, "{}"));
            if (decision == null || decision.isEmpty()) json.remove(origin);
            else json.put(origin, decision);
            browserPrefs().edit().putString(KEY_SITE_PERMISSIONS, json.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void clearPendingWebPermission() {
        pendingWebPermissionRequest = null;
        pendingRememberPermission = false;
        pendingPermissionOrigin = "";
    }

    private void navigate(String input) {
        WebView webView = currentWebView();
        if (webView == null) return;
        String text = input == null ? "" : input.trim();
        if (text.isEmpty()) return;

        String url;
        if (HOME_URL.equals(text) || LEGACY_HOME_URL.equals(text) || text.startsWith(LEGACY_HOME_URL)) {
            url = HOME_URL;
        } else if (text.startsWith("file://") || text.startsWith("content://")) {
            toast("Local file/content URLs are blocked");
            return;
        } else if (text.startsWith("http://") || text.startsWith("https://")) {
            url = text;
        } else if (text.matches("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}([/:?#].*)?$")) {
            url = "https://" + text;
        } else {
            url = buildSearchUrl(text);
        }

        BrowserTab activeTab = currentBrowserTab();
        if (activeTab != null && HOME_URL.equals(url)) activeTab.pendingRestoreUrl = "";

        if (!HOME_URL.equals(url) && isNetworkUrl(url) && !isInternetAllowed()) {
            toast("USA exit is not verified. Direct internet fallback is blocked.");
            showUsaModeDialog();
            return;
        }
        if (activeTab != null && !HOME_URL.equals(url) && isNetworkUrl(url)) activeTab.pendingRestoreUrl = "";
        webView.loadUrl(url);
    }

    private void switchToTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        webContainer.removeAllViews();
        currentTab = index;
        WebView webView = tabs.get(index).webView;
        ViewGroup parent = (ViewGroup) webView.getParent();
        if (parent != null) parent.removeView(webView);
        webContainer.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        BrowserTab tab = tabs.get(index);
        restoreTabIfPending(tab);
        updateRendererPriorities();
        String url = tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty() ? tab.pendingRestoreUrl : webView.getUrl();
        addressBar.setText(url == null || HOME_URL.equals(url) ? "" : url);
        updateNavState();
        updateTabCount();
        refreshTabStrip();
        if (!restoringSession) saveTabSession();
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        BrowserTab tab = tabs.get(index);
        rememberClosedTab(tab);
        tab = tabs.remove(index);
        if (tab.webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
        }
        tab.webView.stopLoading();
        tab.webView.destroy();

        if (tabs.isEmpty()) {
            currentTab = -1;
            createTab(HOME_URL, true);
            saveTabSession();
            return;
        }
        int next = Math.min(index, tabs.size() - 1);
        switchToTab(next);
        saveTabSession();
    }

    private void refreshTabStrip() {
        if (tabStrip == null) return;
        tabStrip.removeAllViews();

        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            BrowserTab tab = tabs.get(i);

            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), 0, dp(4), 0);
            chip.setBackground(pillBackground(index == currentTab ? 0xFFE7ECFF : 0xFFFFFFFF, 14));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(150), dp(34));
            cp.setMargins(0, 0, dp(7), 0);
            chip.setLayoutParams(cp);

            TextView title = new TextView(this);
            title.setText(shortTitleCompact(tab.title));
            title.setTextSize(12);
            title.setSingleLine(true);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setTextColor(0xFF111827);
            title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

            Button close = new Button(this);
            close.setText("×");
            close.setTextSize(17);
            close.setAllCaps(false);
            close.setMinWidth(0);
            close.setMinimumWidth(0);
            close.setPadding(0, 0, 0, 0);
            close.setBackgroundColor(0x00000000);
            close.setContentDescription("Close tab");
            close.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));

            View.OnClickListener openTab = v -> switchToTab(index);
            chip.setOnClickListener(openTab);
            title.setOnClickListener(openTab);
            chip.setOnLongClickListener(v -> { showTabActions(index); return true; });
            title.setOnLongClickListener(v -> { showTabActions(index); return true; });
            close.setOnClickListener(v -> closeTab(index));

            chip.addView(title);
            chip.addView(close);
            tabStrip.addView(chip);
        }

        Button plus = new Button(this);
        plus.setText("+");
        plus.setTextSize(18);
        plus.setAllCaps(false);
        plus.setMinWidth(0);
        plus.setMinimumWidth(0);
        plus.setPadding(0, 0, 0, 0);
        plus.setBackground(pillBackground(0xFFF1F3F7, 17));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(38), dp(34));
        plus.setLayoutParams(pp);
        plus.setOnClickListener(v -> createTab(HOME_URL, true));
        tabStrip.addView(plus);

        if (tabStripScroll != null && currentTab >= 0) {
            tabStripScroll.post(() -> {
                int x = Math.max(0, currentTab * dp(157) - dp(24));
                tabStripScroll.smoothScrollTo(x, 0);
            });
        }
    }

    private GradientDrawable pillBackground(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), 0xFFE1E5EC);
        return d;
    }

    private GradientDrawable darkRoundedBackground(int color, int radiusDp, int strokeColor, int strokeWidthDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeWidthDp > 0) d.setStroke(dp(strokeWidthDp), strokeColor);
        return d;
    }

    private TextView dialogText(String text, float sizeSp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sizeSp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private TextView menuRow(String icon, String label, boolean enabled) {
        TextView row = dialogText(icon + "   " + label + "                                      ›", 16, enabled ? 0xFFF4F7FB : 0xFF566174, Typeface.NORMAL);
        row.setSingleLine(true);
        row.setPadding(dp(18), 0, dp(12), 0);
        row.setBackground(darkRoundedBackground(0xFF0E1724, 18, enabled ? 0xFF1E3552 : 0xFF172231, 1));
        row.setAlpha(enabled ? 1f : 0.55f);
        row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        return row;
    }

    private String shortTitleCompact(String title) {
        if (title == null || title.trim().isEmpty() || HOME_URL.equals(title)) return "New Tab";
        String clean = title.replace("INFIN8 — ", "").trim();
        return clean.length() > 18 ? clean.substring(0, 18) + "…" : clean;
    }

    private void showMainMenu(View anchor) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackground(darkRoundedBackground(0xFF08111D, 24, 0xFF2587FF, 1));

        WebView w = currentWebView();
        boolean canBack = w != null && w.canGoBack();
        boolean canForward = w != null && w.canGoForward();

        BrowserTab activeTab = currentBrowserTab();
        String activeUrl = activeTab == null ? "" : activeTab.url;
        boolean pageBookmarkable = activeUrl != null && !HOME_URL.equals(activeUrl) && isNetworkUrl(activeUrl);
        boolean bookmarked = pageBookmarkable && isBookmarked(activeUrl);

        TextView back = menuRow("←", "Back", canBack);
        TextView forward = menuRow("→", "Forward", canForward);
        TextView reload = menuRow("↻", "Reload", w != null);
        TextView home = menuRow("⌂", "Home", true);
        TextView newTab = menuRow("＋", "New tab", true);
        TextView incognito = menuRow("◈", "New incognito window", true);
        TextView profiles = menuRow("◎", "Profiles • " + BrowserProfiles.active(this).name, true);
        TextView reopenClosed = menuRow("↶", "Reopen closed tab", hasClosedTabs());
        TextView duplicateTab = menuRow("⧉", "Duplicate tab", activeTab != null);
        TextView tabsRow = menuRow("▣", "Tabs", true);
        TextView bookmarkPage = menuRow("★", bookmarked ? "Remove bookmark" : "Bookmark page", pageBookmarkable);
        TextView bookmarks = menuRow("☆", "Bookmarks", true);
        TextView history = menuRow("◷", "History", true);
        TextView findPage = menuRow("⌕", "Find in page", w != null && !isOnHomePage());
        TextView copyLink = menuRow("⧉", "Copy page link", pageBookmarkable);
        TextView sharePage = menuRow("↗", "Share page", pageBookmarkable);
        TextView sitePrivacy = menuRow("◉", "Site privacy", pageBookmarkable);
        TextView settings = menuRow("⚙", "Settings", true);
        TextView downloads = menuRow("↓", "Downloads", true);
        TextView media = menuRow("▶", "Media found (" + detectedMedia.size() + ")", true);
        TextView grabber = menuRow("⌁", "Grab page files", !isOnHomePage());
        TextView adblock = menuRow("◇", "Ad blocker: " + (isAdBlockEnabled() ? "On" : "Off"), true);
        TextView desktop = menuRow("▤", (activeTab != null && activeTab.desktopMode) ? "Mobile site" : "Desktop site", activeTab != null && !isOnHomePage());
        TextView usa = menuRow("🇺🇸", "USA network", true);
        TextView ip = menuRow("◎", "Check US IP", true);

        TextView[] rows = {back, forward, reload, home, newTab, incognito, profiles, reopenClosed, duplicateTab, tabsRow, bookmarkPage, bookmarks, history, findPage, copyLink, sharePage, sitePrivacy, settings, downloads, media, grabber, adblock, desktop, usa, ip};
        for (int i = 0; i < rows.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            if (i > 0) lp.setMargins(0, dp(4), 0, 0);
            rows[i].setLayoutParams(lp);
            panel.addView(rows[i]);
        }

        back.setOnClickListener(v -> { if (canBack) { dialog.dismiss(); handleBackNavigation(false); } });
        forward.setOnClickListener(v -> { if (canForward && w != null) { dialog.dismiss(); w.goForward(); } });
        reload.setOnClickListener(v -> { if (w != null) { dialog.dismiss(); w.reload(); } });
        home.setOnClickListener(v -> { dialog.dismiss(); navigate(HOME_URL); });
        newTab.setOnClickListener(v -> { dialog.dismiss(); createTab(HOME_URL, true); });
        incognito.setOnClickListener(v -> { dialog.dismiss(); openIncognitoWindow(); });
        profiles.setOnClickListener(v -> { dialog.dismiss(); startActivity(new Intent(this, ProfileManagerActivity.class)); });
        reopenClosed.setOnClickListener(v -> { if (hasClosedTabs()) { dialog.dismiss(); reopenLastClosedTab(); } });
        duplicateTab.setOnClickListener(v -> { if (activeTab != null) { dialog.dismiss(); duplicateCurrentTab(); } });
        tabsRow.setOnClickListener(v -> { dialog.dismiss(); showTabsDialog(); });
        bookmarkPage.setOnClickListener(v -> {
            if (!pageBookmarkable || activeTab == null) return;
            dialog.dismiss();
            if (isBookmarked(activeUrl)) {
                removeBookmark(activeUrl);
                toast("Bookmark removed");
            } else {
                addBookmark(activeTab.title, activeUrl);
                toast("Page bookmarked");
            }
        });
        bookmarks.setOnClickListener(v -> { dialog.dismiss(); showBookmarksDialog(); });
        history.setOnClickListener(v -> { dialog.dismiss(); showHistoryDialog(); });
        findPage.setOnClickListener(v -> { dialog.dismiss(); showFindInPageDialog(); });
        copyLink.setOnClickListener(v -> { dialog.dismiss(); copyCurrentPageLink(); });
        sharePage.setOnClickListener(v -> { dialog.dismiss(); shareCurrentPage(); });
        sitePrivacy.setOnClickListener(v -> { if (pageBookmarkable) { dialog.dismiss(); showSitePrivacyDialog(); } });
        settings.setOnClickListener(v -> { dialog.dismiss(); startActivity(new Intent(this, SettingsActivity.class)); });
        downloads.setOnClickListener(v -> { dialog.dismiss(); startActivity(new Intent(this, DownloadsActivity.class)); });
        media.setOnClickListener(v -> { dialog.dismiss(); showDetectedMediaDialog(); });
        grabber.setOnClickListener(v -> { dialog.dismiss(); runPageGrabber(); });
        adblock.setOnClickListener(v -> {
            boolean next = !isAdBlockEnabled();
            browserPrefs().edit().putBoolean(KEY_ADBLOCK_ENABLED, next).apply();
            dialog.dismiss();
            toast(next ? "Ad blocker enabled" : "Ad blocker disabled");
            WebView current = currentWebView();
            if (current != null) current.reload();
        });
        desktop.setOnClickListener(v -> {
            if (activeTab == null || isOnHomePage()) return;
            dialog.dismiss();
            applyDesktopMode(activeTab, !activeTab.desktopMode);
            toast(activeTab.desktopMode ? "Desktop site enabled" : "Mobile site enabled");
        });
        usa.setOnClickListener(v -> { dialog.dismiss(); showUsaModeDialog(); });
        ip.setOnClickListener(v -> { dialog.dismiss(); openIpCheck(); });

        ScrollView menuScroll = new ScrollView(this);
        menuScroll.setFillViewport(true);
        menuScroll.addView(panel);
        dialog.setContentView(menuScroll);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0x00000000));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = dp(330);
            lp.height = Math.min(getResources().getDisplayMetrics().heightPixels - dp(110), dp(760));
            lp.gravity = Gravity.END | Gravity.BOTTOM;
            lp.dimAmount = 0.34f;
            lp.x = dp(12);
            lp.y = dp(72);
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void copyCurrentPageLink() {
        BrowserTab tab = currentBrowserTab();
        if (tab == null || tab.url == null || !(tab.url.startsWith("http://") || tab.url.startsWith("https://"))) {
            toast("No webpage link to copy");
            return;
        }
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("INFIN8 page link", tab.url));
                toast("Page link copied");
            }
        } catch (Exception e) {
            toast("Could not copy link");
        }
    }

    private void shareCurrentPage() {
        BrowserTab tab = currentBrowserTab();
        if (tab == null || tab.url == null || !(tab.url.startsWith("http://") || tab.url.startsWith("https://"))) {
            toast("No webpage to share");
            return;
        }
        try {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            String title = tab.title == null || tab.title.trim().isEmpty() ? "INFIN8 Browser" : tab.title.trim();
            share.putExtra(Intent.EXTRA_SUBJECT, title);
            share.putExtra(Intent.EXTRA_TEXT, title + "\n" + tab.url);
            startActivity(Intent.createChooser(share, "Share page"));
        } catch (Exception e) {
            toast("No share app available");
        }
    }

    private void showFindInPageDialog() {
        WebView webView = currentWebView();
        if (webView == null || isOnHomePage()) {
            toast("Open a webpage first");
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(16));
        card.setBackground(darkRoundedBackground(0xFF07111E, 24, 0xFF2587FF, 1));

        TextView title = dialogText("Find in page", 22, 0xFFFFFFFF, Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        EditText query = new EditText(this);
        query.setSingleLine(true);
        query.setHint("Type text to find");
        query.setTextColor(0xFFFFFFFF);
        query.setHintTextColor(0xFF708096);
        query.setTextSize(15);
        query.setInputType(InputType.TYPE_CLASS_TEXT);
        query.setPadding(dp(13), 0, dp(13), 0);
        query.setBackground(darkRoundedBackground(0xFF0E1724, 14, 0xFF1E3552, 1));
        card.addView(query, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        TextView status = dialogText("Enter a search term", 12, 0xFF8EA0B7, Typeface.NORMAL);
        status.setPadding(dp(2), dp(8), 0, dp(10));
        card.addView(status);

        webView.setFindListener((activeMatchOrdinal, numberOfMatches, isDoneCounting) -> {
            if (!isDoneCounting) return;
            if (numberOfMatches <= 0) status.setText("No matches");
            else status.setText((activeMatchOrdinal + 1) + " of " + numberOfMatches);
        });

        Runnable runFind = () -> {
            String text = query.getText().toString();
            if (text.trim().isEmpty()) {
                webView.clearMatches();
                status.setText("Enter a search term");
            } else {
                webView.findAllAsync(text);
            }
        };
        query.setOnEditorActionListener((v, actionId, event) -> { runFind.run(); return true; });

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.END);
        TextView prev = dialogText("Previous", 13, 0xFFDCE7F6, Typeface.BOLD);
        prev.setGravity(Gravity.CENTER);
        prev.setBackground(darkRoundedBackground(0xFF102033, 18, 0xFF1C3857, 1));
        TextView next = dialogText("Next", 13, 0xFFDCE7F6, Typeface.BOLD);
        next.setGravity(Gravity.CENTER);
        next.setBackground(darkRoundedBackground(0xFF102033, 18, 0xFF1C3857, 1));
        TextView done = dialogText("Done", 13, 0xFFFFFFFF, Typeface.BOLD);
        done.setGravity(Gravity.CENTER);
        done.setBackground(darkRoundedBackground(0xFF0967E8, 18, 0xFF36A3FF, 1));
        prev.setOnClickListener(v -> { runFind.run(); webView.findNext(false); });
        next.setOnClickListener(v -> { runFind.run(); webView.findNext(true); });
        done.setOnClickListener(v -> { webView.clearMatches(); webView.setFindListener(null); dialog.dismiss(); });
        actions.addView(prev, new LinearLayout.LayoutParams(dp(92), dp(44)));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(dp(76), dp(44));
        nlp.setMargins(dp(7), 0, 0, 0);
        actions.addView(next, nlp);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(70), dp(44));
        dlp.setMargins(dp(7), 0, 0, 0);
        actions.addView(done, dlp);
        card.addView(actions);

        dialog.setOnDismissListener(d -> {
            try { webView.clearMatches(); webView.setFindListener(null); } catch (Exception ignored) {}
        });
        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0x00000000));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(500));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            window.setAttributes(lp);
        }
        dialog.show();
        query.requestFocus();
        if (window != null) window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    private String normalizeGroupName(String value) {
        if (value == null) return "Ungrouped";
        String clean = value.trim();
        if (clean.isEmpty()) return "Ungrouped";
        if (clean.length() > 24) clean = clean.substring(0, 24);
        return clean;
    }

    private List<String> existingTabGroups() {
        LinkedHashSet<String> names = new LinkedHashSet<>();
        names.add("Ungrouped");
        for (BrowserTab tab : tabs) names.add(normalizeGroupName(tab.groupName));
        return new ArrayList<>(names);
    }

    private void showGroupPicker(int tabIndex, Runnable afterChange) {
        if (tabIndex < 0 || tabIndex >= tabs.size()) return;
        BrowserTab target = tabs.get(tabIndex);
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18),dp(18),dp(18),dp(18));
        card.setBackground(darkRoundedBackground(ThemePalette.panel(this),24,ThemePalette.accent(this),1));
        card.addView(dialogText("Move tab to group",22,Color.WHITE,Typeface.BOLD));
        TextView hint = dialogText(shortTitle(target.title),12,0xFF8190A5,Typeface.NORMAL); hint.setPadding(0,dp(4),0,dp(10)); card.addView(hint);
        for (String group : existingTabGroups()) {
            String g = group;
            boolean selected = normalizeGroupName(target.groupName).equals(g);
            TextView row = dialogText((selected ? "✓  " : "     ") + g,15,selected ? ThemePalette.accent(this) : 0xFFEAF2FF,selected ? Typeface.BOLD : Typeface.NORMAL);
            row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14),0,dp(14),0); row.setBackground(darkRoundedBackground(0xFF0D1A2A,16,0xFF1A3555,1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(50)); lp.setMargins(0,dp(7),0,0); card.addView(row,lp);
            row.setOnClickListener(v -> { target.groupName=g; saveTabSession(); dialog.dismiss(); if(afterChange!=null) afterChange.run(); });
        }
        EditText custom = new EditText(this);
        custom.setSingleLine(true); custom.setHint("New group name"); custom.setTextColor(Color.WHITE); custom.setHintTextColor(0xFF6F8097); custom.setTextSize(14); custom.setPadding(dp(13),0,dp(13),0); custom.setBackground(darkRoundedBackground(0xFF101927,16,0xFF253A56,1));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(50)); ep.setMargins(0,dp(12),0,0); card.addView(custom,ep);
        TextView create = dialogText("Create & move",14,Color.WHITE,Typeface.BOLD); create.setGravity(Gravity.CENTER); create.setBackground(darkRoundedBackground(ThemePalette.accentStrong(this),18,ThemePalette.accent(this),1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(46)); cp.setMargins(0,dp(8),0,0); card.addView(create,cp);
        create.setOnClickListener(v -> { String name=normalizeGroupName(custom.getText().toString()); if("Ungrouped".equals(name) && custom.getText().toString().trim().isEmpty()){ custom.requestFocus(); return; } target.groupName=name; saveTabSession(); dialog.dismiss(); if(afterChange!=null) afterChange.run(); });
        dialog.setContentView(card);
        Window w=dialog.getWindow(); if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));WindowManager.LayoutParams lp=w.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(28),dp(470));lp.height=WindowManager.LayoutParams.WRAP_CONTENT;lp.gravity=Gravity.CENTER;w.setAttributes(lp);} dialog.show();
    }

    private void showTabsDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(darkRoundedBackground(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titleCol = new LinearLayout(this); titleCol.setOrientation(LinearLayout.VERTICAL); titleCol.setLayoutParams(new LinearLayout.LayoutParams(0,dp(56),1f));
        titleCol.addView(dialogText("Tabs",26,Color.WHITE,Typeface.BOLD));
        titleCol.addView(dialogText(tabs.size()+" open • long-press a tab for actions",11,0xFF7F91AA,Typeface.NORMAL));
        TextView closeDialog = dialogText("×",30,0xFFEAF2FF,Typeface.NORMAL); closeDialog.setGravity(Gravity.CENTER); closeDialog.setBackground(darkRoundedBackground(0xFF10233A,22,0xFF1E6EC8,1));
        closeDialog.setOnClickListener(v -> dialog.dismiss());
        header.addView(titleCol); header.addView(closeDialog,new LinearLayout.LayoutParams(dp(48),dp(48))); card.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,dp(8),0,dp(8)); scroll.addView(list);
        Map<String,List<Integer>> grouped = new LinkedHashMap<>();
        for(int i=0;i<tabs.size();i++){String g=normalizeGroupName(tabs.get(i).groupName); grouped.computeIfAbsent(g,k->new ArrayList<>()).add(i);}
        for(Map.Entry<String,List<Integer>> entry:grouped.entrySet()){
            TextView groupHeader=dialogText(entry.getKey().toUpperCase(Locale.US)+"  •  "+entry.getValue().size(),11,ThemePalette.accent(this),Typeface.BOLD); groupHeader.setLetterSpacing(.08f); groupHeader.setPadding(dp(4),dp(12),0,dp(7)); list.addView(groupHeader);
            for(Integer boxed:entry.getValue()){
                final int index=boxed; BrowserTab tab=tabs.get(index);
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(11),dp(7),dp(8),dp(7)); row.setBackground(darkRoundedBackground(index==currentTab?0xFF10263F:0xFF0C1827,17,index==currentTab?ThemePalette.accent(this):0xFF1C3552,1));
                LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(76)); rlp.setMargins(0,0,0,dp(7)); row.setLayoutParams(rlp);
                ImageView icon=new ImageView(this); icon.setScaleType(ImageView.ScaleType.CENTER_CROP); icon.setBackground(darkRoundedBackground(0xFF000000,11,0xFF152B45,1)); try(InputStream is=getAssets().open("browser_logo.png")){icon.setImageBitmap(BitmapFactory.decodeStream(is));}catch(Exception ignored){}
                LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(dp(42),dp(42)); ilp.setMargins(0,0,dp(11),0); row.addView(icon,ilp);
                LinearLayout textCol=new LinearLayout(this); textCol.setOrientation(LinearLayout.VERTICAL); textCol.setGravity(Gravity.CENTER_VERTICAL); textCol.setLayoutParams(new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,1f));
                TextView t=dialogText(shortTitle(tab.title),15,0xFFF4F7FB,Typeface.BOLD); t.setSingleLine(true); TextView u=dialogText(hostForUrl(tab.url).isEmpty()?"New tab":hostForUrl(tab.url),11,0xFF75869D,Typeface.NORMAL); u.setSingleLine(true); textCol.addView(t); textCol.addView(u); row.addView(textCol);
                TextView groupBtn=dialogText("▦",20,ThemePalette.accent(this),Typeface.NORMAL); groupBtn.setGravity(Gravity.CENTER); groupBtn.setBackground(darkRoundedBackground(0xFF10243B,18,0xFF1A4F83,1)); LinearLayout.LayoutParams glp=new LinearLayout.LayoutParams(dp(42),dp(42)); glp.setMargins(dp(6),0,dp(6),0); row.addView(groupBtn,glp);
                TextView x=dialogText("×",26,0xFFDDEBFF,Typeface.NORMAL); x.setGravity(Gravity.CENTER); x.setBackground(darkRoundedBackground(0xFF10243B,18,0xFF1A4F83,1)); row.addView(x,new LinearLayout.LayoutParams(dp(42),dp(42)));
                row.setOnClickListener(v->{switchToTab(index);dialog.dismiss();}); textCol.setOnClickListener(v->{switchToTab(index);dialog.dismiss();});
                row.setOnLongClickListener(v->{dialog.dismiss();showTabActions(index);return true;});
                textCol.setOnLongClickListener(v->{dialog.dismiss();showTabActions(index);return true;});
                groupBtn.setOnClickListener(v->{dialog.dismiss();showGroupPicker(index,this::showTabsDialog);});
                x.setOnClickListener(v->{dialog.dismiss();closeTab(index);showTabsDialog();}); list.addView(row);
            }
        }
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f); slp.setMargins(0,dp(5),0,dp(10)); card.addView(scroll,slp);

        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView newTab=dialogText("＋ New Tab",15,Color.WHITE,Typeface.BOLD); newTab.setGravity(Gravity.CENTER); newTab.setBackground(darkRoundedBackground(ThemePalette.accentStrong(this),20,ThemePalette.accent(this),1)); newTab.setOnClickListener(v->{dialog.dismiss();createTab(HOME_URL,true);});
        TextView group=dialogText("▦ Group Current",14,0xFFEAF2FF,Typeface.BOLD); group.setGravity(Gravity.CENTER); group.setBackground(darkRoundedBackground(0xFF0E1D2F,20,0xFF1A3555,1)); group.setOnClickListener(v->{int idx=currentTab;dialog.dismiss();showGroupPicker(idx,this::showTabsDialog);});
        actions.addView(newTab,new LinearLayout.LayoutParams(0,dp(52),1f)); LinearLayout.LayoutParams ag=new LinearLayout.LayoutParams(0,dp(52),1f);ag.setMargins(dp(8),0,0,0);actions.addView(group,ag);card.addView(actions);

        dialog.setContentView(card);
        Window window=dialog.getWindow(); if(window!=null){window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);WindowManager.LayoutParams lp=window.getAttributes();lp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(24),dp(500));lp.height=Math.min(getResources().getDisplayMetrics().heightPixels-dp(90),dp(760));lp.gravity=Gravity.CENTER;lp.dimAmount=.50f;window.setAttributes(lp);} dialog.show();
    }

    private void saveTabSession() {
        if (restoringSession) return;
        JSONArray array = new JSONArray();
        try {
            int start = Math.max(0, tabs.size() - MAX_SAVED_TABS);
            for (int i = start; i < tabs.size(); i++) {
                BrowserTab tab = tabs.get(i);
                JSONObject item = new JSONObject();
                String sessionUrl = tab.pendingRestoreUrl != null && !tab.pendingRestoreUrl.isEmpty()
                        ? tab.pendingRestoreUrl
                        : (tab.webView.getUrl() == null ? tab.url : tab.webView.getUrl());
                if (sessionUrl == null || sessionUrl.trim().isEmpty()) sessionUrl = HOME_URL;
                item.put("title", tab.title == null ? "New Tab" : tab.title);
                item.put("url", sessionUrl);
                item.put("desktop", tab.desktopMode);
                item.put("group", normalizeGroupName(tab.groupName));
                array.put(item);
            }
        } catch (Exception ignored) {}
        int adjustedCurrent = Math.max(0, currentTab - Math.max(0, tabs.size() - MAX_SAVED_TABS));
        String serialized = array.toString();
        browserPrefs().edit()
                .putString(profileScopedKey(KEY_TAB_SESSION), serialized)
                .putInt(profileScopedKey(KEY_CURRENT_TAB), adjustedCurrent)
                .commit();
        try (java.io.FileOutputStream out = openFileOutput(profileSessionFile(), MODE_PRIVATE)) {
            JSONObject backup = new JSONObject();
            backup.put("tabs", array);
            backup.put("current", adjustedCurrent);
            out.write(backup.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
        } catch (Exception ignored) {}
    }

    private boolean restoreTabSession() {
        String raw = browserPrefs().getString(profileScopedKey(KEY_TAB_SESSION), "[]");
        int selectedFromBackup = -1;
        if (raw == null || raw.trim().isEmpty() || "[]".equals(raw.trim())) {
            try (InputStream in = openFileInput(profileSessionFile())) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
                JSONObject backup = new JSONObject(out.toString(StandardCharsets.UTF_8.name()));
                raw = backup.optJSONArray("tabs") == null ? "[]" : backup.optJSONArray("tabs").toString();
                selectedFromBackup = backup.optInt("current", 0);
            } catch (Exception ignored) {}
        }
        if (raw == null || raw.trim().isEmpty() || "[]".equals(raw.trim())) return false;
        restoringSession = true;
        try {
            JSONArray array = new JSONArray(raw);
            if (array.length() == 0) return false;
            int count = Math.min(array.length(), MAX_SAVED_TABS);
            for (int i = 0; i < count; i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String url = normalizeInternalUrl(item.optString("url", HOME_URL));
                String title = item.optString("title", "New Tab");
                boolean desktop = item.optBoolean("desktop", false);
                String group = item.optString("group", "Ungrouped");
                createRestoredTab(title, url, desktop, group, false);
            }
            if (tabs.isEmpty()) return false;
            int selected = selectedFromBackup >= 0 ? selectedFromBackup : browserPrefs().getInt(profileScopedKey(KEY_CURRENT_TAB), 0);
            selected = Math.max(0, Math.min(selected, tabs.size() - 1));
            switchToTab(selected);
            updateTabCount();
            refreshTabStrip();
            return true;
        } catch (Exception ignored) {
            return false;
        } finally {
            restoringSession = false;
        }
    }

    private void restorePendingTabs() {
        BrowserTab current = currentBrowserTab();
        if (current != null) restoreTabIfPending(current);
    }

    private void restoreTabIfPending(BrowserTab tab) {
        if (tab == null || !isInternetAllowed()) return;
        String target = tab.pendingRestoreUrl;
        if (target == null || target.isEmpty()) return;
        tab.pendingRestoreUrl = "";
        configureDesktopSettings(tab, tab.desktopMode);
        tab.webView.loadUrl(target);
        saveTabSession();
    }

    private SharedPreferences browserPrefs() {
        return getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE);
    }

    private List<SavedPage> loadPages(String key) {
        List<SavedPage> result = new ArrayList<>();
        try {
            String raw = browserPrefs().getString(profileScopedKey(key), "[]");
            JSONArray array = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String title = item.optString("title", "");
                String url = item.optString("url", "");
                long time = item.optLong("time", 0L);
                if (!url.isEmpty()) result.add(new SavedPage(title, url, time));
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void savePages(String key, List<SavedPage> pages) {
        JSONArray array = new JSONArray();
        try {
            for (SavedPage page : pages) {
                JSONObject item = new JSONObject();
                item.put("title", page.title);
                item.put("url", page.url);
                item.put("time", page.time);
                array.put(item);
            }
        } catch (Exception ignored) {}
        browserPrefs().edit().putString(profileScopedKey(key), array.toString()).apply();
    }

    private void recordHistory(String title, String url) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return;
        List<SavedPage> history = loadPages(KEY_HISTORY);
        for (int i = history.size() - 1; i >= 0; i--) {
            if (url.equals(history.get(i).url)) history.remove(i);
        }
        history.add(0, new SavedPage(cleanPageTitle(title, url), url, System.currentTimeMillis()));
        while (history.size() > MAX_HISTORY_ITEMS) history.remove(history.size() - 1);
        savePages(KEY_HISTORY, history);
    }

    private String cleanPageTitle(String title, String url) {
        if (title != null && !title.trim().isEmpty()) return title.trim();
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            return host == null ? url : host.replaceFirst("^www\\.", "");
        } catch (Exception ignored) {
            return url;
        }
    }

    private boolean isBookmarked(String url) {
        if (url == null) return false;
        for (SavedPage page : loadPages(KEY_BOOKMARKS)) if (url.equals(page.url)) return true;
        return false;
    }

    private void addBookmark(String title, String url) {
        if (url == null || url.isEmpty()) return;
        List<SavedPage> bookmarks = loadPages(KEY_BOOKMARKS);
        for (SavedPage page : bookmarks) if (url.equals(page.url)) return;
        bookmarks.add(0, new SavedPage(cleanPageTitle(title, url), url, System.currentTimeMillis()));
        savePages(KEY_BOOKMARKS, bookmarks);
    }

    private void removeBookmark(String url) {
        List<SavedPage> bookmarks = loadPages(KEY_BOOKMARKS);
        for (int i = bookmarks.size() - 1; i >= 0; i--) if (url.equals(bookmarks.get(i).url)) bookmarks.remove(i);
        savePages(KEY_BOOKMARKS, bookmarks);
    }

    private void showBookmarksDialog() { showSavedPagesDialog("Bookmarks", KEY_BOOKMARKS, true); }
    private void showHistoryDialog() { showSavedPagesDialog("History", KEY_HISTORY, false); }

    private void showSavedPagesDialog(String titleText, String key, boolean bookmarksMode) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(darkRoundedBackground(0xFF07111E, 24, 0xFF2587FF, 1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = dialogText(titleText, 26, 0xFFFFFFFF, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, dp(50), 1f));
        TextView close = dialogText("×", 30, 0xFFEAF2FF, Typeface.NORMAL);
        close.setGravity(Gravity.CENTER);
        close.setBackground(darkRoundedBackground(0xFF10233A, 22, 0xFF1E6EC8, 1));
        close.setLayoutParams(new LinearLayout.LayoutParams(dp(50), dp(50)));
        close.setOnClickListener(v -> dialog.dismiss());
        header.addView(title);
        header.addView(close);
        card.addView(header);

        List<SavedPage> pages = loadPages(key);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(12), 0, 0);

        if (pages.isEmpty()) {
            TextView empty = dialogText(bookmarksMode ? "No bookmarks yet" : "No browsing history yet", 15, 0xFF8795A9, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(34), 0, dp(34));
            list.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            for (SavedPage page : pages) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(14), dp(8), dp(8), dp(8));
                row.setBackground(darkRoundedBackground(0xFF0C1827, 18, 0xFF1C3552, 1));

                LinearLayout textCol = new LinearLayout(this);
                textCol.setOrientation(LinearLayout.VERTICAL);
                textCol.setGravity(Gravity.CENTER_VERTICAL);
                textCol.setLayoutParams(new LinearLayout.LayoutParams(0, dp(62), 1f));
                TextView rowTitle = dialogText(shortTitle(page.title), 15, 0xFFF4F7FB, Typeface.BOLD);
                rowTitle.setSingleLine(true);
                TextView rowUrl = dialogText(page.url, 11, 0xFF8090A5, Typeface.NORMAL);
                rowUrl.setSingleLine(true);
                textCol.addView(rowTitle);
                textCol.addView(rowUrl);

                TextView remove = dialogText("×", 25, 0xFFDDEBFF, Typeface.NORMAL);
                remove.setGravity(Gravity.CENTER);
                remove.setBackground(darkRoundedBackground(0xFF10243B, 20, 0xFF1A4F83, 1));
                remove.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
                row.addView(textCol);
                row.addView(remove);

                row.setOnClickListener(v -> { dialog.dismiss(); navigate(page.url); });
                textCol.setOnClickListener(v -> { dialog.dismiss(); navigate(page.url); });
                remove.setOnClickListener(v -> {
                    List<SavedPage> current = loadPages(key);
                    for (int i = current.size() - 1; i >= 0; i--) if (page.url.equals(current.get(i).url)) current.remove(i);
                    savePages(key, current);
                    dialog.dismiss();
                    if (bookmarksMode) showBookmarksDialog(); else showHistoryDialog();
                });

                LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78));
                rowLp.setMargins(0, 0, 0, dp(8));
                list.addView(row, rowLp);
            }
        }

        scroll.addView(list);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.setMargins(0, dp(6), 0, dp(10));
        card.addView(scroll, scrollLp);

        if (!bookmarksMode) {
            TextView clear = dialogText("Clear history", 15, 0xFF67A9FF, Typeface.BOLD);
            clear.setGravity(Gravity.CENTER);
            clear.setBackground(darkRoundedBackground(0xFF0E1D2F, 22, 0xFF1A3555, 1));
            clear.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            clear.setOnClickListener(v -> {
                browserPrefs().edit().putString(profileScopedKey(KEY_HISTORY), "[]").apply();
                dialog.dismiss();
                toast("History cleared");
            });
            card.addView(clear);
        }

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0x00000000));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(30), dp(450));
            lp.height = Math.min(getResources().getDisplayMetrics().heightPixels - dp(120), dp(650));
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = 0.48f;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void showUsaModeDialog() {
        boolean proxyMode = ConnectionSettings.isProxyMode(this);
        boolean proxyActive = proxyMode && ConnectionSettings.proxyConnected(this) && usaVerified && webGateOpen;
        boolean wireGuardActive = !proxyMode && wireGuard != null && wireGuard.isConnected() && usaVerified && webGateOpen;

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22), dp(8), dp(22), 0);

        TextView status = new TextView(this);
        String stateText = proxyMode
                ? (proxyActive ? "🟢 Proxy • USA verified" : ConnectionSettings.proxyConnected(this) ? "🟡 Proxy • checking/blocked" : "⚪ Proxy disconnected")
                : (wireGuardActive ? "🟢 WireGuard • USA verified" : wireGuard.isConnected() ? "🟡 WireGuard connected • browsing blocked" : "⚪ WireGuard disconnected");
        status.setText(stateText + "\nMode: " + ConnectionSettings.modeLabel(this));
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(10));

        TextView description = new TextView(this);
        description.setText("Choose either the imported WireGuard .conf or a proxy. Only one USA connection path is active at a time, and browsing stays blocked until that path verifies as a US exit.");
        description.setTextSize(13);
        description.setPadding(0, dp(4), 0, dp(10));

        Button wireGuardMode = new Button(this);
        wireGuardMode.setAllCaps(false);
        wireGuardMode.setText((proxyMode ? "○" : "●") + "  WireGuard VPN (.conf)");

        Button proxyModeButton = new Button(this);
        proxyModeButton.setAllCaps(false);
        proxyModeButton.setText((proxyMode ? "●" : "○") + "  Proxy");

        Button configure = new Button(this);
        configure.setAllCaps(false);
        configure.setText(proxyMode ? "Configure proxy" : "Import / replace WireGuard .conf");

        Button connect = new Button(this);
        connect.setAllCaps(false);
        if (proxyMode) connect.setText(ConnectionSettings.proxyConnected(this) ? "Disconnect Proxy" : "Connect Proxy");
        else connect.setText(wireGuard.isConnected() ? "Disconnect WireGuard" : "Connect WireGuard");

        Button verifyNow = new Button(this);
        verifyNow.setAllCaps(false);
        verifyNow.setText("Verify USA exit now");
        verifyNow.setEnabled(proxyMode ? ConnectionSettings.proxyConnected(this) : wireGuard.isConnected());

        TextView verification = new TextView(this);
        String extra = proxyMode
                ? (ConnectionSettings.hasProxy(this) ? "\nProxy: " + ConnectionSettings.proxyUrl(this) : "\nProxy: Not configured")
                : "\n" + wireGuard.getServerLabel();
        verification.setText("Security gate: " + verificationSummary
                + extra
                + (verifiedIp.isEmpty() ? "" : "\nIP: " + verifiedIp)
                + (verifiedLocation.isEmpty() ? "" : "\nLocation: " + verifiedLocation));
        verification.setTextSize(13);
        verification.setPadding(0, dp(8), 0, dp(8));

        TextView note = new TextView(this);
        note.setText("Profiles are separate from this setting. Your selected connection mode applies globally to INFIN8 browsing. If verification fails, direct internet fallback remains blocked.");
        note.setTextSize(12);
        note.setPadding(0, dp(10), 0, 0);

        layout.addView(status);
        layout.addView(description);
        layout.addView(wireGuardMode);
        layout.addView(proxyModeButton);
        layout.addView(configure);
        layout.addView(connect);
        layout.addView(verifyNow);
        layout.addView(verification);
        layout.addView(note);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("🇺🇸 USA Connection")
                .setView(layout)
                .setNegativeButton("Close", null)
                .create();

        wireGuardMode.setOnClickListener(v -> {
            selectWireGuardConnectionMode();
            dialog.dismiss();
            webContainer.postDelayed(this::showUsaModeDialog, 120);
        });

        proxyModeButton.setOnClickListener(v -> {
            selectProxyConnectionMode();
            dialog.dismiss();
            webContainer.postDelayed(this::showUsaModeDialog, 120);
        });

        configure.setOnClickListener(v -> {
            dialog.dismiss();
            if (ConnectionSettings.isProxyMode(this)) showProxyConfigDialog();
            else chooseWireGuardConfig();
        });

        connect.setOnClickListener(v -> {
            dialog.dismiss();
            if (ConnectionSettings.isProxyMode(this)) {
                if (ConnectionSettings.proxyConnected(this)) disconnectGlobalProxy();
                else connectGlobalProxy(true);
            } else {
                if (wireGuard.isConnected()) {
                    DownloadService.pauseAllForNetworkChange(this);
                    setKeepVpnConnected(false);
                    stopVpnKeepAliveService();
                    closeWebGate("WireGuard disconnected", true);
                    wireGuard.disconnect();
                } else if (!wireGuard.hasConfig()) {
                    toast("Import your US WireGuard .conf first.");
                    chooseWireGuardConfig();
                } else {
                    setKeepVpnConnected(true);
                    ensureVpnPermissionThenConnect();
                }
            }
        });

        verifyNow.setOnClickListener(v -> {
            dialog.dismiss();
            if (ConnectionSettings.isProxyMode(this)) verifyProxyExit(true);
            else verifyUsaExit(true);
        });

        dialog.show();
    }

    private void selectWireGuardConnectionMode() {
        if (ConnectionSettings.isWireGuardMode(this)) return;
        DownloadService.pauseAllForNetworkChange(this);
        ConnectionSettings.setProxyConnected(this, false);
        ConnectionSettings.setMode(this, ConnectionSettings.MODE_WIREGUARD);
        usaVerified = false;
        verifiedIp = "";
        verifiedLocation = "";
        closeWebGate("WireGuard selected — connect to verify USA exit", true);
        toast("Connection mode: WireGuard VPN");
    }

    private void selectProxyConnectionMode() {
        if (ConnectionSettings.isProxyMode(this)) return;
        DownloadService.pauseAllForNetworkChange(this);
        ConnectionSettings.setMode(this, ConnectionSettings.MODE_PROXY);
        setKeepVpnConnected(false);
        stopVpnKeepAliveService();
        if (wireGuard != null && wireGuard.isConnected()) wireGuard.disconnect();
        ConnectionSettings.setProxyConnected(this, false);
        usaVerified = false;
        verifiedIp = "";
        verifiedLocation = "";
        closeWebGate("Proxy selected — connect to verify USA exit", true);
        toast("Connection mode: Proxy");
    }

    private void showProxyConfigDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22), dp(10), dp(22), 0);

        EditText endpoint = new EditText(this);
        endpoint.setSingleLine(true);
        endpoint.setText(ConnectionSettings.proxyUrl(this));
        endpoint.setHint("http://host:port or socks://host:port");
        endpoint.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        form.addView(endpoint);

        TextView help = new TextView(this);
        help.setText("Supported: HTTP, HTTPS and SOCKS/SOCKS5 host:port. Proxy usernames/passwords inside the URL are intentionally rejected because WebView's proxy API does not provide a reliable secure authentication hook.");
        help.setTextSize(12);
        help.setPadding(0, dp(8), 0, 0);
        form.addView(help);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Configure USA Proxy")
                .setView(form)
                .setPositiveButton("Save & Connect", null)
                .setNeutralButton("Clear", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String normalized = ConnectionSettings.normalizeProxy(endpoint.getText().toString());
                if (normalized.isEmpty()) {
                    toast("Enter a valid proxy host and port");
                    return;
                }
                DownloadService.pauseAllForNetworkChange(this);
                ConnectionSettings.setProxyUrl(this, normalized);
                ConnectionSettings.setMode(this, ConnectionSettings.MODE_PROXY);
                ConnectionSettings.setProxyConnected(this, false);
                dialog.dismiss();
                connectGlobalProxy(true);
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                ConnectionSettings.setProxyConnected(this, false);
                ConnectionSettings.setProxyUrl(this, "");
                closeWebGate("Proxy configuration cleared", true);
                dialog.dismiss();
                toast("Proxy cleared");
            });
        });
        dialog.show();
    }

    private void connectGlobalProxy(boolean announce) {
        String proxyUrl = ConnectionSettings.proxyUrl(this);
        if (proxyUrl.isEmpty()) {
            showProxyConfigDialog();
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            DownloadService.pauseAllForNetworkChange(this);
            ConnectionSettings.setProxyConnected(this, false);
            closeWebGate("This Android WebView does not support proxy override", true);
            toast("Proxy mode is not supported by this WebView");
            return;
        }

        ConnectionSettings.setMode(this, ConnectionSettings.MODE_PROXY);
        setKeepVpnConnected(false);
        stopVpnKeepAliveService();
        if (wireGuard != null && wireGuard.isConnected()) wireGuard.disconnect();

        usaVerified = false;
        verifiedIp = "";
        verifiedLocation = "";
        verificationSummary = "Checking proxy USA exit…";
        closeWebGate(verificationSummary, false);

        final java.net.Proxy javaProxy;
        try {
            javaProxy = ConnectionSettings.toJavaProxy(proxyUrl);
        } catch (Exception e) {
            DownloadService.pauseAllForNetworkChange(this);
            ConnectionSettings.setProxyConnected(this, false);
            closeWebGate("Invalid proxy configuration", true);
            toast("Invalid proxy configuration");
            return;
        }

        usaVerifier.verify(javaProxy, result -> runOnUiThread(() -> {
            if (destroyed || !ConnectionSettings.isProxyMode(this)) return;
            verifiedIp = result.ip;
            verifiedLocation = result.location;
            verificationSummary = result.detail;
            if (!result.verifiedUsa) {
                DownloadService.pauseAllForNetworkChange(this);
                ConnectionSettings.setProxyConnected(this, false);
                usaVerified = false;
                closeWebGate(result.detail, true);
                updateUsaButton();
                toast("Proxy is not verified as a USA exit. Browsing remains blocked.");
                return;
            }
            applyVerifiedGlobalProxy(proxyUrl, result, announce);
        }));
    }

    private void verifyProxyExit(boolean announce) {
        if (!ConnectionSettings.isProxyMode(this) || !ConnectionSettings.hasProxy(this)) {
            ConnectionSettings.setProxyConnected(this, false);
            usaVerified = false;
            closeWebGate("Proxy is not configured", true);
            if (announce) toast("Configure a proxy first");
            return;
        }
        connectGlobalProxy(announce);
    }

    private void applyVerifiedGlobalProxy(String proxyUrl, UsaNetworkVerifier.Result result, boolean announce) {
        try {
            ProxyConfig config = new ProxyConfig.Builder().addProxyRule(proxyUrl).build();
            ProxyController.getInstance().setProxyOverride(config, proxyExecutor, () -> runOnUiThread(() -> {
                if (destroyed || !ConnectionSettings.isProxyMode(this)) return;
                ConnectionSettings.setProxyConnected(this, true);
                usaVerified = true;
                webGateOpen = true;
                lastVerifiedAt = System.currentTimeMillis();
                verifiedIp = result.ip;
                verifiedLocation = result.location;
                verificationSummary = result.detail;
                restorePendingTabs();
                DownloadService.wake(this);
                updateUsaButton();
                mainHandler.removeCallbacks(periodicReverify);
                mainHandler.postDelayed(periodicReverify, REVERIFY_INTERVAL_MS);
                if (announce) toast("🇺🇸 Proxy USA exit verified" + (verifiedIp.isEmpty() ? "" : " • " + verifiedIp));
            }));
        } catch (Exception e) {
            DownloadService.pauseAllForNetworkChange(this);
            ConnectionSettings.setProxyConnected(this, false);
            usaVerified = false;
            closeWebGate("Could not apply proxy", true);
            updateUsaButton();
            toast("Proxy connection failed: " + safeMessage(e));
        }
    }

    private void disconnectGlobalProxy() {
        DownloadService.pauseAllForNetworkChange(this);
        ConnectionSettings.setProxyConnected(this, false);
        usaVerified = false;
        verifiedIp = "";
        verifiedLocation = "";
        mainHandler.removeCallbacks(periodicReverify);
        closeWebGate("Proxy disconnected", true);
        updateUsaButton();
        toast("Proxy disconnected");
    }

    private boolean shouldKeepVpnConnected() {
        return browserPrefs().getBoolean(KEY_KEEP_VPN_CONNECTED, false);
    }

    private void setKeepVpnConnected(boolean keepConnected) {
        browserPrefs().edit().putBoolean(KEY_KEEP_VPN_CONNECTED, keepConnected).apply();
    }

    private void showWelcomeSplash() {
        final Dialog splash = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        splash.setCancelable(false);

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setPadding(dp(28), dp(40), dp(28), dp(40));
        wrap.setBackgroundColor(0xFF05080D);

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try (InputStream is = getAssets().open("browser_logo.png")) {
            logo.setImageBitmap(BitmapFactory.decodeStream(is));
        } catch (Exception ignored) {}
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(108), dp(108));
        logoLp.setMargins(0, 0, 0, dp(26));
        wrap.addView(logo, logoLp);

        TextView welcome = new TextView(this);
        welcome.setText("WELCOME TO\nINFIN8 BROWSER");
        welcome.setTextColor(0xFFF4F7FB);
        welcome.setTextSize(28);
        welcome.setTypeface(Typeface.DEFAULT_BOLD);
        welcome.setGravity(Gravity.CENTER);
        welcome.setLetterSpacing(0.08f);
        wrap.addView(welcome, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView provider = new TextView(this);
        provider.setText("PROVIDED BY  JIN BABA");
        provider.setTextColor(0xFF6EA8FF);
        provider.setTextSize(12);
        provider.setGravity(Gravity.CENTER);
        provider.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams providerLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        providerLp.setMargins(0, dp(18), 0, 0);
        wrap.addView(provider, providerLp);

        splash.setContentView(wrap);
        Window w = splash.getWindow();
        if (w != null) {
            w.setStatusBarColor(0xFF05080D);
            w.setNavigationBarColor(0xFF05080D);
        }
        splash.show();
        mainHandler.postDelayed(() -> {
            if (!destroyed && splash.isShowing()) splash.dismiss();
        }, 1600);
    }

    private void chooseWireGuardConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "application/octet-stream"});
        startActivityForResult(intent, WG_CONFIG_REQUEST);
    }

    private void importWireGuardConfig(Uri uri) {
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IllegalArgumentException("Could not read selected file");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int read;
            while ((read = input.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                if (out.size() > 128 * 1024) throw new IllegalArgumentException("Configuration file is too large");
            }
            String raw = out.toString(StandardCharsets.UTF_8.name());
            DownloadService.pauseAllForNetworkChange(this);
            wireGuard.importConfig(raw);
            ConnectionSettings.setMode(this, ConnectionSettings.MODE_WIREGUARD);
            ConnectionSettings.setProxyConnected(this, false);
            setKeepVpnConnected(true);
            updateUsaButton();
            toast("WireGuard profile imported securely");
            ensureVpnPermissionThenConnect();
        } catch (Exception e) {
            toast("Import failed: " + safeMessage(e));
        }
    }

    private void ensureVpnPermissionThenConnect() {
        if (ConnectionSettings.isProxyMode(this)) DownloadService.pauseAllForNetworkChange(this);
        ConnectionSettings.setMode(this, ConnectionSettings.MODE_WIREGUARD);
        ConnectionSettings.setProxyConnected(this, false);
        if (!wireGuard.hasConfig()) {
            showUsaModeDialog();
            return;
        }
        Intent permission = wireGuard.getVpnPermissionIntent();
        if (permission == null) {
            closeWebGate("Connecting USA Mode…", false);
            toast("Connecting USA Mode…");
            startVpnKeepAliveService();
            wireGuard.connect();
        } else {
            startActivityForResult(permission, VPN_PERMISSION_REQUEST);
        }
    }

    private void startVpnKeepAliveService() {
        if (!shouldKeepVpnConnected() || wireGuard == null || !wireGuard.hasConfig()) return;
        Intent i = new Intent(this, VpnKeepAliveService.class);
        i.setAction(VpnKeepAliveService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void stopVpnKeepAliveService() {
        Intent i = new Intent(this, VpnKeepAliveService.class);
        i.setAction(VpnKeepAliveService.ACTION_STOP);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {
            try { stopService(new Intent(this, VpnKeepAliveService.class)); } catch (Exception ignoredAgain) {}
        }
    }

    private void handleIncomingIntent(Intent incoming) {
        if (incoming == null) return;
        if (incoming.getBooleanExtra("open_usa_settings", false)) {
            incoming.removeExtra("open_usa_settings");
            webContainer.postDelayed(this::showUsaModeDialog, 220);
            return;
        }
        if (Intent.ACTION_VIEW.equals(incoming.getAction()) && incoming.getData() != null) {
            String requested = incoming.getData().toString();
            webContainer.postDelayed(() -> navigate(requested), 350);
            return;
        }
        if (Intent.ACTION_SEND.equals(incoming.getAction()) && "text/plain".equals(incoming.getType())) {
            String shared = incoming.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null && (shared.startsWith("http://") || shared.startsWith("https://"))) {
                webContainer.postDelayed(() -> navigate(shared), 350);
            }
        }
    }

    private boolean isAdBlockEnabled() {
        return browserPrefs().getBoolean(KEY_ADBLOCK_ENABLED, true);
    }

    private boolean isBlockedHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ENGLISH);
        String[] blocked = {
                "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
                "google-analytics.com", "googletagmanager.com", "googletagservices.com", "analytics.google.com",
                "ads-twitter.com", "analytics.twitter.com", "connect.facebook.net", "pixel.facebook.com",
                "facebook.net", "scorecardresearch.com", "quantserve.com", "hotjar.com", "hotjar.io",
                "segment.io", "segment.com", "mixpanel.com", "amplitude.com", "app-measurement.com",
                "branch.io", "adjust.com", "appsflyer.com", "taboola.com", "outbrain.com", "criteo.com",
                "criteo.net", "adnxs.com", "rubiconproject.com", "pubmatic.com", "openx.net",
                "moatads.com", "amazon-adsystem.com", "adsrvr.org", "mathtag.com", "demdex.net"
        };
        for (String domain : blocked) if (h.equals(domain) || h.endsWith("." + domain)) return true;
        return false;
    }

    private void maybeRecordMediaUrl(String url) {
        if (url == null) return;
        String lower = url.toLowerCase(Locale.ENGLISH);
        if (!(lower.contains(".mp4") || lower.contains(".webm") || lower.contains(".mp3") || lower.contains(".m4a") || lower.contains(".aac") || lower.contains(".wav") || lower.contains(".m3u8") || lower.contains(".mpd") || lower.contains(".pdf") || lower.contains(".zip") || lower.contains(".apk"))) return;
        synchronized (detectedMedia) {
            if (detectedMedia.size() >= 100) {
                String first = detectedMedia.iterator().next();
                detectedMedia.remove(first);
            }
            detectedMedia.add(url);
        }
    }

    private boolean isDirectDownloadUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ENGLISH);
        return lower.matches(".*\\.(mp4|webm|mp3|m4a|aac|wav|flac|m3u8|mpd|jpg|jpeg|png|gif|webp|pdf|zip|rar|7z|apk|doc|docx|xls|xlsx|ppt|pptx)(\\?.*)?$");
    }

    private void showDownloadPrompt(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
        if (!isInternetAllowed()) {
            toast("USA exit must be verified before downloading.");
            return;
        }

        String guessed = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType);
        String size = contentLength > 0 ? formatBytes(contentLength) : "Unknown size";
        final int[] partOptions = {0, 1, 4, 8, 16, 32};
        final String[] partLabels = {"Auto", "1", "4", "8", "16", "32"};
        final String[] categoryOptions = {"", "Videos", "Music", "Images", "Documents", "Apps", "Other"};
        final String[] categoryLabels = {"Auto folder", "Videos", "Music", "Images", "Documents", "Apps", "Other"};
        final long[] scheduleDelays = {0L, 15L * 60_000L, 60L * 60_000L, 3L * 60L * 60_000L};
        final String[] scheduleLabels = {"Now", "15 min", "1 hour", "3 hours"};
        final int[] partIndex = {0};
        final int[] categoryIndex = {0};
        final int[] scheduleIndex = {0};

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(16));
        card.setBackground(darkRoundedBackground(0xFF07111E, 24, 0xFF2587FF, 1));

        String mediaKind = DownloadService.detectMediaKind(url, mimeType);
        TextView title = dialogText("DIRECT".equals(mediaKind) ? "Download file" : "Download " + mediaKind + " stream", 22, 0xFFF4F7FB, Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        TextView info = dialogText(("DIRECT".equals(mediaKind) ? size : "Public clear stream") + "  •  INFIN8 resumable downloader", 12, 0xFF8EA0B7, Typeface.NORMAL);
        info.setPadding(0, 0, 0, dp(10));
        card.addView(info);

        EditText filename = new EditText(this);
        filename.setSingleLine(true);
        filename.setText(guessed);
        filename.setHint("File name");
        filename.setTextColor(0xFFF4F7FB);
        filename.setHintTextColor(0xFF718096);
        filename.setTextSize(14);
        filename.setPadding(dp(12), 0, dp(12), 0);
        filename.setBackground(darkRoundedBackground(0xFF0E1724, 14, 0xFF1E3552, 1));
        card.addView(filename, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        LinearLayout optionRow = new LinearLayout(this);
        optionRow.setOrientation(LinearLayout.HORIZONTAL);
        optionRow.setPadding(0, dp(10), 0, 0);

        Button parts = new Button(this);
        parts.setAllCaps(false);
        parts.setText("Parts: Auto");
        parts.setTextColor(0xFFEAF2FF);
        parts.setTextSize(12);
        parts.setBackground(darkRoundedBackground(0xFF10243B, 14, 0xFF1A4F83, 1));
        parts.setOnClickListener(v -> {
            partIndex[0] = (partIndex[0] + 1) % partOptions.length;
            parts.setText("Parts: " + partLabels[partIndex[0]]);
        });

        Button folder = new Button(this);
        folder.setAllCaps(false);
        folder.setText("Folder: Auto");
        folder.setTextColor(0xFFEAF2FF);
        folder.setTextSize(12);
        folder.setBackground(darkRoundedBackground(0xFF10243B, 14, 0xFF1A4F83, 1));
        folder.setOnClickListener(v -> {
            categoryIndex[0] = (categoryIndex[0] + 1) % categoryOptions.length;
            folder.setText("Folder: " + categoryLabels[categoryIndex[0]]);
        });

        optionRow.addView(parts, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        flp.setMargins(dp(8), 0, 0, 0);
        optionRow.addView(folder, flp);
        card.addView(optionRow);

        Button schedule = new Button(this);
        schedule.setAllCaps(false);
        schedule.setText("Start: Now");
        schedule.setTextColor(0xFFEAF2FF);
        schedule.setTextSize(12);
        schedule.setBackground(darkRoundedBackground(0xFF10243B, 14, 0xFF1A4F83, 1));
        LinearLayout.LayoutParams schedLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        schedLp.setMargins(0, dp(8), 0, 0);
        card.addView(schedule, schedLp);
        schedule.setOnClickListener(v -> {
            scheduleIndex[0] = (scheduleIndex[0] + 1) % scheduleDelays.length;
            schedule.setText("Start: " + scheduleLabels[scheduleIndex[0]]);
        });

        String hintText = "DIRECT".equals(mediaKind)
                ? "Auto chooses the safest part count from file size and server range support. Manual 32 parts still falls back to 1 if the server does not support ranges."
                : "Public clear HLS/DASH only. Encrypted/DRM streams are refused. HLS TS is remuxed to MP4 when Android supports the stream codecs.";
        TextView hint = dialogText(hintText, 10, 0xFF64748B, Typeface.NORMAL);
        hint.setPadding(0, dp(9), 0, dp(12));
        card.addView(hint);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END);
        Button cancel = new Button(this);
        cancel.setText("Cancel");
        cancel.setAllCaps(false);
        cancel.setTextColor(0xFFEAF2FF);
        cancel.setBackground(darkRoundedBackground(0xFF0E1D2F, 20, 0xFF1A3555, 1));
        Button download = new Button(this);
        download.setText("Download");
        download.setAllCaps(false);
        download.setTextColor(0xFFFFFFFF);
        download.setTypeface(Typeface.DEFAULT_BOLD);
        download.setBackground(darkRoundedBackground(0xFF0967E8, 20, 0xFF36A3FF, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());
        download.setOnClickListener(v -> {
            String chosenName = filename.getText().toString().trim();
            if (chosenName.isEmpty()) chosenName = guessed;
            long scheduledAt = scheduleDelays[scheduleIndex[0]] <= 0 ? 0L : System.currentTimeMillis() + scheduleDelays[scheduleIndex[0]];
            DownloadService.enqueueAdvanced(this, url, userAgent, contentDisposition, mimeType, contentLength,
                    chosenName, partOptions[partIndex[0]], categoryOptions[categoryIndex[0]], scheduledAt);
            dialog.dismiss();
            toast("Added to Downloads");
        });
        actions.addView(cancel, new LinearLayout.LayoutParams(dp(96), dp(44)));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(118), dp(44));
        dlp.setMargins(dp(8), 0, 0, 0);
        actions.addView(download, dlp);
        card.addView(actions);

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0x00000000));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(520));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = 0.62f;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void showDetectedMediaDialog() {
        List<String> items;
        synchronized (detectedMedia) { items = new ArrayList<>(detectedMedia); }
        if (items.isEmpty()) {
            toast("No downloadable media detected on this tab yet.");
            return;
        }
        Collections.reverse(items);
        int limit = Math.min(items.size(), 20);
        String[] labels = new String[limit];
        for (int i = 0; i < limit; i++) {
            String u = items.get(i);
            String lower = u.toLowerCase(Locale.ENGLISH);
            String kind = lower.contains(".m3u8") ? "HLS manifest" : lower.contains(".mpd") ? "DASH manifest" : "Direct file";
            labels[i] = kind + " • " + (u.length() > 62 ? u.substring(0, 62) + "…" : u);
        }
        new AlertDialog.Builder(this)
                .setTitle("Detected media")
                .setItems(labels, (d, which) -> {
                    String u = items.get(which);
                    String lower = u.toLowerCase(Locale.ENGLISH);
                    String mime = lower.contains(".m3u8") ? "application/vnd.apple.mpegurl" : lower.contains(".mpd") ? "application/dash+xml" : "";
                    showDownloadPrompt(u, currentWebView() == null ? "" : currentWebView().getSettings().getUserAgentString(), "", mime, -1L);
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void runPageGrabber() {
        WebView w = currentWebView();
        if (w == null || isOnHomePage()) return;
        String js = "(function(){var s=new Set();document.querySelectorAll('a[href],img[src],video[src],audio[src],source[src]').forEach(function(e){var u=e.href||e.src;if(u&&/^https?:/i.test(u))s.add(u);});return JSON.stringify(Array.from(s).slice(0,160));})()";
        w.evaluateJavascript(js, value -> {
            try {
                Object decoded = new org.json.JSONTokener(value).nextValue();
                String raw = decoded instanceof String ? (String) decoded : "[]";
                JSONArray arr = new JSONArray(raw);
                List<String> downloadable = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    String u = arr.optString(i, "");
                    maybeRecordMediaUrl(u);
                    if (isDirectDownloadUrl(u)) downloadable.add(u);
                }
                if (downloadable.isEmpty()) {
                    toast("Page scan finished: no downloadable files or public stream manifests found.");
                    return;
                }

                int count = Math.min(downloadable.size(), 50);
                String[] labels = new String[count];
                boolean[] checked = new boolean[count];
                for (int i = 0; i < count; i++) {
                    String u = downloadable.get(i);
                    String name = android.webkit.URLUtil.guessFileName(u, "", "");
                    labels[i] = name + "\n" + (u.length() > 72 ? u.substring(0, 72) + "…" : u);
                }

                AlertDialog grabDialog = new AlertDialog.Builder(this)
                        .setTitle("Page Grabber • " + downloadable.size() + " files")
                        .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                        .setNeutralButton("Select all", null)
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Download selected", (d, which) -> {
                            String ua = w.getSettings().getUserAgentString();
                            int queued = 0;
                            for (int i = 0; i < count; i++) {
                                if (!checked[i]) continue;
                                String item = downloadable.get(i);
                                String lower = item.toLowerCase(Locale.ENGLISH);
                                String mime = lower.contains(".m3u8") ? "application/vnd.apple.mpegurl" : lower.contains(".mpd") ? "application/dash+xml" : "";
                                DownloadService.enqueue(this, item, ua, "", mime, -1L);
                                queued++;
                            }
                            toast(queued == 0 ? "No files selected" : queued + " files added to Downloads");
                        })
                        .create();
                grabDialog.setOnShowListener(d -> {
                    Button all = grabDialog.getButton(AlertDialog.BUTTON_NEUTRAL);
                    all.setOnClickListener(v -> {
                        android.widget.ListView lv = grabDialog.getListView();
                        boolean anyOff = false;
                        for (boolean c : checked) if (!c) { anyOff = true; break; }
                        for (int i = 0; i < count; i++) { checked[i] = anyOff; lv.setItemChecked(i, anyOff); }
                        all.setText(anyOff ? "Clear all" : "Select all");
                    });
                });
                grabDialog.show();
            } catch (Exception e) {
                toast("Could not scan this page.");
            }
        });
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", bytes / 1024f);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f));
        return String.format(Locale.US, "%.2f GB", bytes / (1024f * 1024f * 1024f));
    }

    private void openIpCheck() {
        if (!isInternetAllowed()) {
            toast("USA exit must be verified first.");
            showUsaModeDialog();
            return;
        }
        navigate("https://ipinfo.io/");
    }

    private void updateUsaButton() {
        // USA/WireGuard controls live in the overflow menu in v0.5.
    }

    private void updateNavState() {
        if (navBar != null) navBar.setVisibility(isOnHomePage() ? View.GONE : View.VISIBLE);
        setBottomNavColor(bottomHomeIcon, bottomHomeLabel, isOnHomePage() ? ThemePalette.accent(this) : 0xFFAAB4C3);
        setBottomNavColor(bottomTabsIcon, bottomTabsLabel, 0xFFAAB4C3);
        setBottomNavColor(bottomSearchIcon, bottomSearchLabel, 0xFFAAB4C3);
        setBottomNavColor(bottomMenuIcon, bottomMenuLabel, 0xFFAAB4C3);
    }

    private void setBottomNavColor(ImageView icon, TextView label, int color) {
        if (icon != null) icon.setColorFilter(color);
        if (label != null) label.setTextColor(color);
    }

    private void updateTabCount() {
        // Tab count is available in the Tabs dialog; keep the bottom bar minimal.
    }

    private boolean isOnHomePage() {
        WebView w = currentWebView();
        String url = w == null ? null : w.getUrl();
        return url == null || HOME_URL.equals(url) || url.startsWith(HOME_URL);
    }

    private BrowserTab tabFor(WebView webView) {
        for (BrowserTab tab : tabs) if (tab.webView == webView) return tab;
        return null;
    }

    private WebView currentWebView() {
        if (currentTab < 0 || currentTab >= tabs.size()) return null;
        return tabs.get(currentTab).webView;
    }

    private String shortTitle(String title) {
        if (title == null || title.trim().isEmpty()) return "New Tab";
        return title.length() > 36 ? title.substring(0, 36) + "…" : title;
    }

    private String urlEncode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception ignored) {
            return value.replace(" ", "+");
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        if (!destroyed) Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String safeMessage(Throwable error) {
        if (error == null) return "Unknown error";
        String message = error.getMessage();
        if (message == null || message.trim().isEmpty()) return error.getClass().getSimpleName();
        // Never echo configuration text/private keys into the UI.
        return message.length() > 160 ? message.substring(0, 160) : message;
    }

    @Override
    public void onStateChanged(Tunnel.State state) {
        runOnUiThread(() -> {
            if (destroyed) return;

            // Proxy mode and WireGuard are mutually exclusive. A stale/restarted
            // WireGuard service must never replace the user's selected proxy path.
            if (ConnectionSettings.isProxyMode(this)) {
                if (state == Tunnel.State.UP) {
                    setKeepVpnConnected(false);
                    stopVpnKeepAliveService();
                    wireGuard.disconnect();
                }
                return;
            }

            if (state == Tunnel.State.UP) {
                mainHandler.removeCallbacks(reconnectWireGuardAfterUnexpectedDrop);
                if (shouldKeepVpnConnected()) startVpnKeepAliveService();
                usaVerified = false;
                verifiedIp = "";
                verifiedLocation = "";
                verificationSummary = "WireGuard connected; verifying USA exit…";
                closeWebGate(verificationSummary, false);
                updateUsaButton();
                toast("WireGuard connected • verifying USA exit…");
                verifyUsaExit(true);
            } else if (state == Tunnel.State.DOWN) {
                DownloadService.pauseAllForNetworkChange(this);
                mainHandler.removeCallbacks(periodicReverify);
                usaVerified = false;
                verifiedIp = "";
                verifiedLocation = "";
                verificationSummary = "VPN tunnel is disconnected";
                closeWebGate(verificationSummary, true);
                updateUsaButton();

                // If the tunnel dropped unexpectedly while the user's keep-connected
                // preference is still enabled, make one conservative reconnect attempt.
                // Manual disconnect clears that preference before requesting DOWN.
                mainHandler.removeCallbacks(reconnectWireGuardAfterUnexpectedDrop);
                if (shouldKeepVpnConnected()) {
                    mainHandler.postDelayed(reconnectWireGuardAfterUnexpectedDrop, 1_200L);
                }
            }
        });
    }

    @Override
    public void onError(String message, Throwable error) {
        runOnUiThread(() -> {
            if (destroyed) return;
            usaVerified = false;
            verificationSummary = message;
            closeWebGate(message, true);
            updateUsaButton();
            toast(message + ": " + safeMessage(error));
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) {
                ConnectionSettings.setMode(this, ConnectionSettings.MODE_WIREGUARD);
                ConnectionSettings.setProxyConnected(this, false);
                closeWebGate("Connecting USA Mode…", false);
                toast("Connecting USA Mode…");
                startVpnKeepAliveService();
                wireGuard.connect();
            } else {
                toast("VPN permission is required for USA Mode.");
            }
            return;
        }

        if (requestCode == WG_CONFIG_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                importWireGuardConfig(data.getData());
            }
            return;
        }

        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        String currentThemeSignature = ThemePalette.signature(this);
        if (!lastThemeSignature.isEmpty() && !lastThemeSignature.equals(currentThemeSignature)) {
            recreate();
            return;
        }
        lastThemeSignature = currentThemeSignature;
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        applyBrowserPreferencesToTabs();
        syncBackgroundBrowserService();
        updateRendererPriorities();
        if (ConnectionSettings.isProxyMode(this)) {
            if (ConnectionSettings.proxyConnected(this)
                    && System.currentTimeMillis() - lastVerifiedAt > REVERIFY_INTERVAL_MS) {
                verifyProxyExit(false);
            }
        } else {
            if (wireGuard != null && wireGuard.hasConfig() && shouldKeepVpnConnected()) {
                wireGuard.refreshState();
            }
            if (wireGuard != null && wireGuard.isConnected() && usaVerified
                    && System.currentTimeMillis() - lastVerifiedAt > REVERIFY_INTERVAL_MS) {
                verifyUsaExit(false);
            }
        }
    }

    private boolean isInternetAllowed() {
        if (ConnectionSettings.isProxyMode(this)) {
            return ConnectionSettings.proxyConnected(this) && usaVerified && webGateOpen;
        }
        return wireGuard != null && wireGuard.isConnected() && usaVerified && webGateOpen;
    }

    private void verifyUsaExit(boolean announce) {
        if (ConnectionSettings.isProxyMode(this)) {
            verifyProxyExit(announce);
            return;
        }
        if (destroyed || wireGuard == null || !wireGuard.isConnected()) {
            usaVerified = false;
            verificationSummary = "VPN tunnel is not connected";
            closeWebGate(verificationSummary, true);
            updateUsaButton();
            return;
        }

        boolean alreadyVerified = usaVerified && webGateOpen;
        if (!alreadyVerified) {
            usaVerified = false;
            verificationSummary = "Checking current VPN exit country…";
            closeWebGate(verificationSummary, false);
            updateUsaButton();
        }

        usaVerifier.verify(result -> runOnUiThread(() -> {
            if (destroyed || ConnectionSettings.isProxyMode(this) || wireGuard == null || !wireGuard.isConnected()) return;

            verifiedIp = result.ip;
            verifiedLocation = result.location;
            verificationSummary = result.detail;

            if (result.verifiedUsa) {
                usaVerified = true;
                lastVerifiedAt = System.currentTimeMillis();
                openWebGate(() -> {
                    updateUsaButton();
                    if (announce) toast("🇺🇸 USA exit verified" + (verifiedIp.isEmpty() ? "" : " • " + verifiedIp));
                });
                mainHandler.removeCallbacks(periodicReverify);
                mainHandler.postDelayed(periodicReverify, REVERIFY_INTERVAL_MS);
            } else {
                usaVerified = false;
                closeWebGate(verificationSummary, true);
                updateUsaButton();
                toast("USA verification failed. Browsing remains blocked.");
            }
        }));
    }

    private void openWebGate(Runnable afterOpen) {
        if (ConnectionSettings.isProxyMode(this)) {
            if (ConnectionSettings.proxyConnected(this)) {
                verifyProxyExit(false);
            } else {
                closeWebGate("Proxy is not connected", true);
            }
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            webGateOpen = true;
            restorePendingTabs();
            DownloadService.wake(this);
            if (afterOpen != null) afterOpen.run();
            return;
        }
        try {
            ProxyController.getInstance().clearProxyOverride(proxyExecutor, () -> runOnUiThread(() -> {
                if (destroyed) return;
                webGateOpen = true;
                restorePendingTabs();
                DownloadService.wake(this);
                if (afterOpen != null) afterOpen.run();
            }));
        } catch (Exception e) {
            webGateOpen = false;
            usaVerified = false;
            verificationSummary = "Could not open the secure WebView gate";
            updateUsaButton();
            toast("Secure browsing gate error: " + safeMessage(e));
        }
    }


    private void closeWebGate(String reason, boolean preserveInternetTabs) {
        webGateOpen = false;
        if (reason != null && !reason.trim().isEmpty()) verificationSummary = reason;

        if (preserveInternetTabs) {
            // Keep the already-rendered page exactly where it is when VPN/proxy access
            // drops. The secure network gate below blocks new internet traffic without
            // replacing the visible tab with the browser home page.
            for (BrowserTab tab : tabs) {
                String current = tab.webView.getUrl();
                if (current != null && (current.startsWith("http://") || current.startsWith("https://"))) {
                    tab.url = current;
                }
            }
            saveTabSession();
        }

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return;
        try {
            ProxyConfig blocked = new ProxyConfig.Builder()
                    .addProxyRule("http://127.0.0.1:9")
                    .build();
            ProxyController.getInstance().setProxyOverride(blocked, proxyExecutor, () -> { });
        } catch (Exception ignored) {
            // Software navigation checks remain active even if this WebView feature is unavailable at runtime.
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String requested = intent == null ? null : intent.getStringExtra("switch_profile");
        boolean forceProfileReload = intent != null && intent.getBooleanExtra("force_profile_reload", false);
        if (requested != null && !requested.trim().isEmpty() && (forceProfileReload || !requested.equals(activeProfileId))) {
            switchActiveProfile(requested);
            return;
        }
        handleIncomingIntent(intent);
    }

    private void switchActiveProfile(String profileId) {
        saveTabSession();
        for (BrowserTab tab : new ArrayList<>(tabs)) {
            try { tab.webView.stopLoading(); tab.webView.destroy(); } catch (Exception ignored) {}
        }
        tabs.clear();
        currentTab = -1;
        webContainer.removeAllViews();
        BrowserProfiles.setActive(this, profileId);
        activeProfileId = BrowserProfiles.activeId(this);
        usaVerified = false;
        closeWebGate("Profile switched — verifying USA exit", false);
        restoringSession = false;
        if (!restoreTabSession()) createTab(HOME_URL, true);
        refreshTabStrip();
        updateTabCount();
        updateSearchUi();
        if (ConnectionSettings.isProxyMode(this)) {
            if (ConnectionSettings.proxyConnected(this)) verifyProxyExit(false);
        } else if (wireGuard != null && wireGuard.isConnected()) {
            verifyUsaExit(false);
        }
        toast("Profile: " + BrowserProfiles.active(this).name);
    }

    private void applyActiveWebViewProfile(WebView webView) {
        if (webView == null || BrowserProfiles.DEFAULT_ID.equals(activeProfileId)) return;
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            toast("This WebView does not support isolated profiles");
            return;
        }
        try { WebViewCompat.setProfile(webView, BrowserProfiles.active(this).webViewProfileName()); }
        catch (Exception e) { toast("Could not attach isolated browser profile"); }
    }

    private CookieManager cookieManagerFor(WebView webView) {
        if (webView != null && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            try { return WebViewCompat.getProfile(webView).getCookieManager(); } catch (Exception ignored) {}
        }
        return CookieManager.getInstance();
    }

    private void applyProfileBrowserIdentity(WebView webView) {
        BrowserProfiles.ProfileData p = BrowserProfiles.active(this);
        WebSettings s = webView.getSettings();
        if ("desktop".equals(p.uaMode)) s.setUserAgentString(DESKTOP_UA);
        else if ("custom".equals(p.uaMode) && p.customUa != null && !p.customUa.trim().isEmpty()) s.setUserAgentString(p.customUa.trim());
        else s.setUserAgentString(WebSettings.getDefaultUserAgent(this));
    }

    private String profileBaseUserAgent() {
        BrowserProfiles.ProfileData p = BrowserProfiles.active(this);
        if ("desktop".equals(p.uaMode)) return DESKTOP_UA;
        if ("custom".equals(p.uaMode) && p.customUa != null && !p.customUa.trim().isEmpty()) return p.customUa.trim();
        return WebSettings.getDefaultUserAgent(this);
    }

    private void installProfileEnvironment(WebView webView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        try { WebViewCompat.addDocumentStartJavaScript(webView, BrowserProfiles.environmentScript(BrowserProfiles.active(this)), Collections.singleton("*")); }
        catch (Exception ignored) {}
    }

    private String profileScopedKey(String base) {
        return BrowserProfiles.scopedKey(this, base);
    }

    private String profileSessionFile() {
        return BrowserProfiles.DEFAULT_ID.equals(activeProfileId) ? TAB_SESSION_FILE : "tab_session_" + activeProfileId + ".json";
    }

    private void registerModernBackHandler() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            backInvokedCallback = () -> handleBackNavigation(true);
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backInvokedCallback);
        }
    }

    private boolean handleBackNavigation(boolean allowBackground) {
        if (customView != null) {
            hideFullscreenVideo();
            return true;
        }
        WebView w = currentWebView();
        if (w != null && w.canGoBack()) {
            w.goBack();
            return true;
        }

        if (w != null) {
            String url = w.getUrl();
            if (url != null && !HOME_URL.equals(url)) {
                w.loadUrl(HOME_URL);
                return true;
            }
        }

        if (tabs.size() > 1) {
            closeTab(currentTab);
            return true;
        }

        if (allowBackground) {
            moveTaskToBack(true);
            return true;
        }
        return false;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != WEB_PERMISSION_REQUEST || pendingWebPermissionRequest == null) return;
        boolean granted = grantResults.length > 0;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }
        PermissionRequest request = pendingWebPermissionRequest;
        String origin = pendingPermissionOrigin;
        boolean remember = pendingRememberPermission;
        clearPendingWebPermission();
        if (granted) {
            if (remember) setSitePermissionDecision(origin, "allow");
            try { request.grant(request.getResources()); } catch (Exception ignored) {}
        } else {
            try { request.deny(); } catch (Exception ignored) {}
            toast("Android permission denied");
        }
    }

    @Override
    public void onBackPressed() {
        handleBackNavigation(true);
    }

    @Override
    protected void onPause() {
        saveTabSession();
        if (shouldKeepBrowserActive()) startBrowserKeepAliveService();
        super.onPause();
    }

    @Override
    protected void onStop() {
        saveTabSession();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        saveTabSession();
        hideFullscreenVideo();
        destroyed = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backInvokedCallback != null) {
            try {
                getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backInvokedCallback);
            } catch (Exception ignored) {}
            backInvokedCallback = null;
        }
        mainHandler.removeCallbacks(periodicReverify);
        mainHandler.removeCallbacks(reconnectWireGuardAfterUnexpectedDrop);
        if (usaVerifier != null) usaVerifier.shutdown();
        if (wireGuard != null) {
            // Do not disconnect here. The user explicitly controls VPN disconnect from USA Network.
            // Closing the browser UI must not tear down an active WireGuard tunnel.
            wireGuard.shutdown();
        }
        for (BrowserTab tab : tabs) {
            if (tab.webView.getParent() instanceof ViewGroup) {
                ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
            }
            tab.webView.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }

    private boolean shouldKeepBrowserActive() {
        return browserPrefs().getBoolean(KEY_KEEP_BROWSER_ACTIVE, true);
    }

    private boolean smartMemorySaverEnabled() {
        return browserPrefs().getBoolean(KEY_SMART_MEMORY_SAVER, true);
    }

    private void syncBackgroundBrowserService() {
        if (shouldKeepBrowserActive()) startBrowserKeepAliveService();
        else stopBrowserKeepAliveService();
    }

    private void startBrowserKeepAliveService() {
        Intent intent = new Intent(this, BrowserKeepAliveService.class).setAction(BrowserKeepAliveService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
            else startService(intent);
        } catch (Exception ignored) {}
    }

    private void stopBrowserKeepAliveService() {
        try {
            Intent intent = new Intent(this, BrowserKeepAliveService.class).setAction(BrowserKeepAliveService.ACTION_STOP);
            startService(intent);
        } catch (Exception ignored) {
            try { stopService(new Intent(this, BrowserKeepAliveService.class)); } catch (Exception ignoredAgain) {}
        }
    }

    private void updateRendererPriorities() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        boolean memorySaver = smartMemorySaverEnabled();
        boolean keepBackground = shouldKeepBrowserActive();
        WebView current = currentWebView();
        for (BrowserTab tab : tabs) {
            WebView w = tab.webView;
            if (w == null) continue;
            try {
                if (w == current) {
                    w.setRendererPriorityPolicy(
                            keepBackground ? WebView.RENDERER_PRIORITY_IMPORTANT : WebView.RENDERER_PRIORITY_BOUND,
                            false);
                } else if (memorySaver) {
                    w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true);
                } else {
                    w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, false);
                }
            } catch (Exception ignored) {}
        }
    }

    private void recoverCrashedRenderer(WebView crashed) {
        BrowserTab tab = tabFor(crashed);
        if (tab == null || destroyed) return;
        int index = tabs.indexOf(tab);
        if (index < 0) return;

        String target = tab.pendingRestoreUrl;
        if (target == null || target.isEmpty()) target = crashed.getUrl();
        if (target == null || target.isEmpty()) target = tab.url;
        if (target == null || target.isEmpty()) target = HOME_URL;

        boolean wasCurrent = index == currentTab;
        if (crashed.getParent() instanceof ViewGroup) {
            ((ViewGroup) crashed.getParent()).removeView(crashed);
        }
        try { crashed.destroy(); } catch (Exception ignored) {}

        WebView replacement = new WebView(this);
        applyActiveWebViewProfile(replacement);
        configureWebView(replacement);
        tab.webView = replacement;
        if (tab.desktopMode) configureDesktopSettings(tab, true);

        if (target.startsWith("http://") || target.startsWith("https://")) {
            if (isInternetAllowed()) {
                tab.pendingRestoreUrl = "";
                replacement.loadUrl(target);
            } else {
                tab.pendingRestoreUrl = target;
                replacement.loadUrl(HOME_URL);
            }
        } else {
            tab.pendingRestoreUrl = "";
            replacement.loadUrl(target);
        }

        if (wasCurrent) {
            webContainer.removeAllViews();
            webContainer.addView(replacement, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        updateRendererPriorities();
        saveTabSession();
        toast("Tab recovered after a WebView crash");
    }

    @Override
    public void onTrimMemory(int level) {
        saveTabSession();
        updateRendererPriorities();
        super.onTrimMemory(level);
    }

    @Override
    public void onLowMemory() {
        saveTabSession();
        updateRendererPriorities();
        super.onLowMemory();
    }

    private static final class BrowserTab {
        WebView webView;
        String title;
        String url;
        boolean desktopMode;
        String groupName = "Ungrouped";
        String pendingRestoreUrl = "";
        String profileId = BrowserProfiles.DEFAULT_ID;

        BrowserTab(WebView webView, String title, String url) {
            this.webView = webView;
            this.title = title;
            this.url = url;
            this.desktopMode = false;
        }
    }

    private static final class SavedPage {
        final String title;
        final String url;
        final long time;

        SavedPage(String title, String url, long time) {
            this.title = title == null ? "" : title;
            this.url = url == null ? "" : url;
            this.time = time;
        }
    }
}
