package com.infin8.browser;

import android.content.Context;
import android.content.SharedPreferences;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.util.Locale;

/**
 * Global USA connection selector for INFIN8 Browser.
 *
 * The browser can use exactly one active transport at a time:
 *  - WireGuard: the embedded app-scoped WireGuard tunnel.
 *  - Proxy: a user supplied HTTP/HTTPS/SOCKS proxy applied to WebView and INFIN8 downloads.
 *
 * Profile/account isolation is intentionally separate from this connection choice.
 */
final class ConnectionSettings {
    static final String PREFS = "infin8_browser_data";
    static final String MODE_WIREGUARD = "wireguard";
    static final String MODE_PROXY = "proxy";

    private static final String KEY_MODE = "usa_connection_mode_v26";
    private static final String KEY_PROXY_URL = "usa_global_proxy_url_v26";
    private static final String KEY_PROXY_CONNECTED = "usa_global_proxy_connected_v26";
    private static final String KEY_LEGACY_PROXY_MIGRATED = "usa_profile_proxy_migrated_v26";

    private ConnectionSettings() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String mode(Context c) {
        String raw = prefs(c).getString(KEY_MODE, MODE_WIREGUARD);
        return MODE_PROXY.equals(raw) ? MODE_PROXY : MODE_WIREGUARD;
    }

    static boolean isProxyMode(Context c) {
        return MODE_PROXY.equals(mode(c));
    }

    static boolean isWireGuardMode(Context c) {
        return !isProxyMode(c);
    }

    static void setMode(Context c, String mode) {
        prefs(c).edit().putString(KEY_MODE, MODE_PROXY.equals(mode) ? MODE_PROXY : MODE_WIREGUARD).apply();
    }

    static String proxyUrl(Context c) {
        return normalizeProxy(prefs(c).getString(KEY_PROXY_URL, ""));
    }

    static void setProxyUrl(Context c, String raw) {
        String normalized = normalizeProxy(raw);
        prefs(c).edit().putString(KEY_PROXY_URL, normalized).apply();
        if (normalized.isEmpty()) setProxyConnected(c, false);
    }

    static boolean hasProxy(Context c) {
        return !proxyUrl(c).isEmpty();
    }

    static boolean proxyConnected(Context c) {
        return prefs(c).getBoolean(KEY_PROXY_CONNECTED, false) && hasProxy(c);
    }

    static void setProxyConnected(Context c, boolean connected) {
        prefs(c).edit().putBoolean(KEY_PROXY_CONNECTED, connected && hasProxy(c)).apply();
    }

    static String normalizeProxy(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        if (!s.contains("://")) s = "http://" + s;
        try {
            URI u = URI.create(s);
            String scheme = u.getScheme() == null ? "http" : u.getScheme().toLowerCase(Locale.ENGLISH);
            if ("socks5".equals(scheme)) scheme = "socks";
            if (!("http".equals(scheme) || "https".equals(scheme) || "socks".equals(scheme))) return "";
            // AndroidX WebView ProxyController does not provide a reliable secure credential store/auth hook.
            // Do not silently persist proxy passwords in a URL.
            if (u.getUserInfo() != null && !u.getUserInfo().isEmpty()) return "";
            String host = u.getHost();
            if (host == null || host.trim().isEmpty()) return "";
            int port = u.getPort();
            if (port < 0) port = "https".equals(scheme) ? 443 : "socks".equals(scheme) ? 1080 : 80;
            return scheme + "://" + host + ":" + port;
        } catch (Exception e) {
            return "";
        }
    }

    static Proxy toJavaProxy(String normalizedProxyUrl) {
        String value = normalizeProxy(normalizedProxyUrl);
        if (value.isEmpty()) throw new IllegalArgumentException("Proxy address is missing or invalid");
        URI u = URI.create(value);
        String scheme = u.getScheme() == null ? "http" : u.getScheme().toLowerCase(Locale.ENGLISH);
        Proxy.Type type = "socks".equals(scheme) ? Proxy.Type.SOCKS : Proxy.Type.HTTP;
        return new Proxy(type, new InetSocketAddress(u.getHost(), u.getPort()));
    }

    static Proxy activeJavaProxy(Context c) {
        if (!isProxyMode(c) || !proxyConnected(c)) return null;
        return toJavaProxy(proxyUrl(c));
    }


    static void migrateLegacyProfileProxy(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getBoolean(KEY_LEGACY_PROXY_MIGRATED, false)) return;
        try {
            if (!hasProxy(c)) {
                BrowserProfiles.ProfileData legacy = BrowserProfiles.active(c);
                if (legacy != null && legacy.hasProxy()) {
                    setProxyUrl(c, legacy.proxyUrl);
                }
            }
        } catch (Exception ignored) {}
        p.edit().putBoolean(KEY_LEGACY_PROXY_MIGRATED, true).apply();
    }

    static String modeLabel(Context c) {
        return isProxyMode(c) ? "Proxy" : "WireGuard VPN";
    }
}
