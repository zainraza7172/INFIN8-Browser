package com.infin8.browser;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.webkit.CookieManager;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Public, clear-stream HLS/DASH downloader used by INFIN8.
 *
 * Security boundary: this helper intentionally refuses encrypted HLS and DASH
 * manifests that declare ContentProtection. It is not a DRM bypass module.
 */
final class StreamDownloader {
    interface Control {
        boolean isPaused();
        void onBytes(long totalDownloaded);
        void throttle(int bytes) throws InterruptedException;
    }

    static final class Result {
        final File file;
        final String mime;
        final long bytes;
        final String detail;
        Result(File file, String mime, long bytes, String detail) {
            this.file = file; this.mime = mime; this.bytes = bytes; this.detail = detail;
        }
    }

    private static final int CONNECT_TIMEOUT = 15_000;
    private static final int READ_TIMEOUT = 30_000;

    private StreamDownloader() {}

    static Result downloadHls(String manifestUrl, String ua, File preferredMp4, Proxy proxy, Control control) throws Exception {
        String master = fetchText(manifestUrl, ua, proxy, control);
        if (containsEncryptedHls(master)) throw new IllegalStateException("Encrypted/DRM HLS is not supported");
        String mediaUrl = selectHlsVariant(manifestUrl, master);
        String playlist = mediaUrl.equals(manifestUrl) ? master : fetchText(mediaUrl, ua, proxy, control);

        if (containsEncryptedHls(playlist)) {
            throw new IllegalStateException("Encrypted/DRM HLS is not supported");
        }
        if (playlist.contains("#EXT-X-BYTERANGE")) {
            throw new IllegalStateException("HLS byte-range playlists are not supported yet");
        }

        HlsPlan plan = parseHls(mediaUrl, playlist);
        if (plan.segments.isEmpty()) throw new IllegalStateException("No HLS media segments found");

        File workDir = new File(preferredMp4.getParentFile(), ".stream_" + Math.abs((manifestUrl + preferredMp4.getName()).hashCode()));
        if (!workDir.exists() && !workDir.mkdirs()) throw new IllegalStateException("Could not create stream work folder");

        long downloaded = 0L;
        File init = null;
        if (plan.initUrl != null) {
            init = new File(workDir, "init.bin");
            if (!init.exists() || init.length() == 0) downloadUrlToFile(plan.initUrl, ua, init, proxy, control, downloaded);
            downloaded += init.length();
            control.onBytes(downloaded);
        }

        List<File> segmentFiles = new ArrayList<>();
        for (int i = 0; i < plan.segments.size(); i++) {
            ensureNotPaused(control);
            File seg = new File(workDir, String.format(Locale.US, "seg_%06d.bin", i));
            if (!seg.exists() || seg.length() == 0) downloadUrlToFile(plan.segments.get(i), ua, seg, proxy, control, downloaded);
            downloaded += seg.length();
            control.onBytes(downloaded);
            segmentFiles.add(seg);
        }

        if (plan.fragmentedMp4) {
            try (OutputStream out = new BufferedOutputStream(new FileOutputStream(preferredMp4, false))) {
                if (init != null) appendFile(init, out);
                for (File f : segmentFiles) appendFile(f, out);
            }
            deleteRecursively(workDir);
            return new Result(preferredMp4, "video/mp4", preferredMp4.length(), "HLS fMP4");
        }

        File mergedTs = new File(workDir, "merged.ts");
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(mergedTs, false))) {
            for (File f : segmentFiles) appendFile(f, out);
        }
        ensureNotPaused(control);

        boolean remuxed = false;
        try { remuxTsToMp4(mergedTs, preferredMp4); remuxed = preferredMp4.exists() && preferredMp4.length() > 0; }
        catch (Throwable ignored) { remuxed = false; }

        if (remuxed) {
            deleteRecursively(workDir);
            return new Result(preferredMp4, "video/mp4", preferredMp4.length(), "HLS TS remuxed to MP4");
        }

        File tsFallback = siblingWithExtension(preferredMp4, ".ts");
        if (tsFallback.exists()) tsFallback.delete();
        copyFile(mergedTs, tsFallback);
        deleteRecursively(workDir);
        return new Result(tsFallback, "video/mp2t", tsFallback.length(), "HLS TS (MP4 remux unsupported for this codec)");
    }

    static Result downloadDash(String manifestUrl, String ua, File preferredMp4, Proxy proxy, Control control) throws Exception {
        String xml = fetchText(manifestUrl, ua, proxy, control);
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(false);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        Document doc = f.newDocumentBuilder().parse(new java.io.ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        Element mpd = doc.getDocumentElement();
        if (mpd == null || !"MPD".equalsIgnoreCase(mpd.getTagName())) throw new IllegalStateException("Invalid DASH manifest");
        String type = mpd.getAttribute("type");
        if ("dynamic".equalsIgnoreCase(type)) throw new IllegalStateException("Live/dynamic DASH recording is not supported yet");

        DashRepresentation rep = chooseDashRepresentation(mpd, manifestUrl);
        if (rep == null) throw new IllegalStateException("No downloadable DASH representation found");
        if (rep.protectedContent) throw new IllegalStateException("DRM/protected DASH is not supported");

        if (rep.directUrl != null) {
            long bytes = downloadUrlToFile(rep.directUrl, ua, preferredMp4, proxy, control, 0L);
            return new Result(preferredMp4, rep.mime, bytes, "DASH direct representation");
        }

        if (rep.segmentUrls.isEmpty()) throw new IllegalStateException("Unsupported DASH segment layout");
        File workDir = new File(preferredMp4.getParentFile(), ".dash_" + Math.abs((manifestUrl + preferredMp4.getName()).hashCode()));
        if (!workDir.exists() && !workDir.mkdirs()) throw new IllegalStateException("Could not create DASH work folder");
        long downloaded = 0L;
        List<File> parts = new ArrayList<>();
        int index = 0;
        if (rep.initializationUrl != null && !rep.initializationUrl.isEmpty()) {
            File init = new File(workDir, "init.mp4");
            if (!init.exists() || init.length() == 0) downloadUrlToFile(rep.initializationUrl, ua, init, proxy, control, downloaded);
            downloaded += init.length(); control.onBytes(downloaded); parts.add(init);
        }
        for (String u : rep.segmentUrls) {
            ensureNotPaused(control);
            File seg = new File(workDir, String.format(Locale.US, "seg_%06d.m4s", index++));
            if (!seg.exists() || seg.length() == 0) downloadUrlToFile(u, ua, seg, proxy, control, downloaded);
            downloaded += seg.length(); control.onBytes(downloaded); parts.add(seg);
        }
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(preferredMp4, false))) {
            for (File p : parts) appendFile(p, out);
        }
        deleteRecursively(workDir);
        return new Result(preferredMp4, rep.mime == null || rep.mime.isEmpty() ? "video/mp4" : rep.mime,
                preferredMp4.length(), "DASH static representation");
    }

    private static String fetchText(String rawUrl, String ua, Proxy proxy, Control control) throws Exception {
        ensureNotPaused(control);
        HttpURLConnection c = open(rawUrl, ua, proxy);
        try {
            c.connect();
            int code = c.getResponseCode();
            if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
            try (InputStream in = new BufferedInputStream(c.getInputStream());
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b = new byte[32 * 1024];
                int n;
                while ((n = in.read(b)) >= 0) {
                    ensureNotPaused(control);
                    out.write(b, 0, n);
                }
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { c.disconnect(); }
    }

    private static long downloadUrlToFile(String rawUrl, String ua, File target, Proxy proxy, Control control, long baseProgress) throws Exception {
        ensureNotPaused(control);
        if (target.getParentFile() != null && !target.getParentFile().exists()) target.getParentFile().mkdirs();
        long have = target.exists() ? target.length() : 0L;
        int attempt = 0;
        while (attempt++ < 4) {
            HttpURLConnection c = null;
            try {
                c = open(rawUrl, ua, proxy);
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                c.connect();
                int code = c.getResponseCode();
                boolean append = have > 0 && code == HttpURLConnection.HTTP_PARTIAL;
                if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
                if (have > 0 && !append) have = 0;
                try (InputStream in = new BufferedInputStream(c.getInputStream());
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(target, append))) {
                    byte[] b = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(b)) >= 0) {
                        ensureNotPaused(control);
                        control.throttle(n);
                        out.write(b, 0, n);
                        have += n;
                        control.onBytes(baseProgress + have);
                    }
                }
                return target.length();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new PauseException();
            } catch (PauseException e) {
                throw e;
            } catch (Exception e) {
                if (attempt >= 4) throw e;
                try { Thread.sleep(600L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new PauseException(); }
                have = target.exists() ? target.length() : 0L;
            } finally { if (c != null) c.disconnect(); }
        }
        return target.length();
    }

    private static HttpURLConnection open(String rawUrl, String ua, Proxy proxy) throws Exception {
        URL url = new URL(rawUrl);
        HttpURLConnection c = (HttpURLConnection)(proxy == null ? url.openConnection() : url.openConnection(proxy));
        c.setConnectTimeout(CONNECT_TIMEOUT);
        c.setReadTimeout(READ_TIMEOUT);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", ua == null || ua.isEmpty() ? "INFIN8 Browser" : ua);
        c.setRequestProperty("Accept-Encoding", "identity");
        try {
            String cookie = CookieManager.getInstance().getCookie(rawUrl);
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        } catch (Throwable ignored) {}
        return c;
    }

    private static String selectHlsVariant(String masterUrl, String text) throws Exception {
        if (!text.contains("#EXT-X-STREAM-INF")) return masterUrl;
        String[] lines = text.split("\\r?\\n");
        long bestBandwidth = -1L;
        String best = null;
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (!line.startsWith("#EXT-X-STREAM-INF")) continue;
            long bw = attrLong(line, "BANDWIDTH", 0L);
            String next = null;
            for (int j = i + 1; j < lines.length; j++) {
                String n = lines[j].trim();
                if (n.isEmpty()) continue;
                if (!n.startsWith("#")) { next = n; break; }
            }
            if (next != null && bw >= bestBandwidth) { bestBandwidth = bw; best = resolve(masterUrl, next); }
        }
        if (best == null) throw new IllegalStateException("No HLS media variant found");
        return best;
    }

    private static boolean containsEncryptedHls(String playlist) {
        for (String raw : playlist.split("\\r?\\n")) {
            String s = raw.trim();
            if (!(s.startsWith("#EXT-X-KEY") || s.startsWith("#EXT-X-SESSION-KEY"))) continue;
            String method = attrString(s, "METHOD");
            if (method == null || !"NONE".equalsIgnoreCase(method)) return true;
        }
        return false;
    }

    private static HlsPlan parseHls(String playlistUrl, String text) throws Exception {
        HlsPlan p = new HlsPlan();
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXT-X-MAP")) {
                String uri = attrString(line, "URI");
                if (uri != null) { p.initUrl = resolve(playlistUrl, uri); p.fragmentedMp4 = true; }
            } else if (!line.startsWith("#")) {
                p.segments.add(resolve(playlistUrl, line));
                String lower = line.toLowerCase(Locale.ENGLISH);
                if (lower.contains(".m4s") || lower.contains(".mp4")) p.fragmentedMp4 = true;
            }
        }
        return p;
    }

    private static DashRepresentation chooseDashRepresentation(Element mpd, String manifestUrl) throws Exception {
        String mpdBase = firstChildText(mpd, "BaseURL");
        String rootBase = mpdBase == null ? manifestUrl : resolve(manifestUrl, mpdBase);
        double totalSeconds = parseDurationSeconds(mpd.getAttribute("mediaPresentationDuration"));

        List<DashRepresentation> candidates = new ArrayList<>();
        NodeList adaptations = mpd.getElementsByTagName("AdaptationSet");
        for (int ai = 0; ai < adaptations.getLength(); ai++) {
            Element adaptation = (Element)adaptations.item(ai);
            String aMime = adaptation.getAttribute("mimeType");
            String contentType = adaptation.getAttribute("contentType");
            boolean video = aMime.startsWith("video/") || "video".equalsIgnoreCase(contentType) || aMime.isEmpty();
            if (!video) continue;
            boolean protectedContent = adaptation.getElementsByTagName("ContentProtection").getLength() > 0;
            String aBaseText = firstChildText(adaptation, "BaseURL");
            String aBase = aBaseText == null ? rootBase : resolve(rootBase, aBaseText);
            Element inheritedTemplate = firstChildElement(adaptation, "SegmentTemplate");
            Element inheritedList = firstChildElement(adaptation, "SegmentList");

            NodeList reps = adaptation.getElementsByTagName("Representation");
            for (int ri = 0; ri < reps.getLength(); ri++) {
                Element r = (Element)reps.item(ri);
                DashRepresentation d = new DashRepresentation();
                d.id = r.getAttribute("id");
                d.bandwidth = parseLong(r.getAttribute("bandwidth"), 0L);
                d.mime = r.getAttribute("mimeType"); if (d.mime.isEmpty()) d.mime = aMime;
                d.protectedContent = protectedContent || r.getElementsByTagName("ContentProtection").getLength() > 0;
                String rBaseText = firstChildText(r, "BaseURL");
                String rBase = rBaseText == null ? aBase : resolve(aBase, rBaseText);
                Element template = firstChildElement(r, "SegmentTemplate"); if (template == null) template = inheritedTemplate;
                Element list = firstChildElement(r, "SegmentList"); if (list == null) list = inheritedList;
                if (template != null) fillFromSegmentTemplate(d, template, rBase, totalSeconds);
                else if (list != null) fillFromSegmentList(d, list, rBase);
                else if (rBaseText != null) d.directUrl = rBase;
                if (d.directUrl != null || !d.segmentUrls.isEmpty()) candidates.add(d);
            }
        }
        if (candidates.isEmpty()) return null;
        candidates.sort(Comparator.comparingLong((DashRepresentation x) -> x.bandwidth).reversed());
        return candidates.get(0);
    }

    private static void fillFromSegmentList(DashRepresentation d, Element list, String base) throws Exception {
        Element init = firstChildElement(list, "Initialization");
        if (init != null) {
            String src = init.getAttribute("sourceURL");
            if (!src.isEmpty()) d.initializationUrl = resolve(base, src);
        }
        NodeList segs = list.getElementsByTagName("SegmentURL");
        for (int i = 0; i < segs.getLength(); i++) {
            Element e = (Element)segs.item(i);
            String media = e.getAttribute("media");
            if (!media.isEmpty()) d.segmentUrls.add(resolve(base, media));
        }
    }

    private static void fillFromSegmentTemplate(DashRepresentation d, Element t, String base, double totalSeconds) throws Exception {
        String media = t.getAttribute("media");
        String init = t.getAttribute("initialization");
        long startNumber = parseLong(t.getAttribute("startNumber"), 1L);
        long timescale = parseLong(t.getAttribute("timescale"), 1L);
        long duration = parseLong(t.getAttribute("duration"), 0L);
        if (!init.isEmpty()) d.initializationUrl = resolve(base, expandTemplate(init, d, startNumber, 0L));

        Element timeline = firstChildElement(t, "SegmentTimeline");
        if (timeline != null) {
            long number = startNumber;
            long currentTime = 0L;
            NodeList ss = timeline.getElementsByTagName("S");
            for (int i = 0; i < ss.getLength(); i++) {
                Element s = (Element)ss.item(i);
                long dur = parseLong(s.getAttribute("d"), 0L);
                if (dur <= 0) continue;
                if (s.hasAttribute("t")) currentTime = parseLong(s.getAttribute("t"), currentTime);
                long repeat = parseLong(s.getAttribute("r"), 0L);
                if (repeat < 0) {
                    if (totalSeconds <= 0) repeat = 0;
                    else repeat = Math.max(0L, (long)Math.ceil((totalSeconds * timescale - currentTime) / (double)dur) - 1L);
                }
                repeat = Math.min(repeat, 50_000L);
                for (long r = 0; r <= repeat; r++) {
                    d.segmentUrls.add(resolve(base, expandTemplate(media, d, number++, currentTime)));
                    currentTime += dur;
                }
            }
            return;
        }
        if (duration > 0 && totalSeconds > 0) {
            long count = Math.min(100_000L, Math.max(1L, (long)Math.ceil(totalSeconds * timescale / duration)));
            for (long i = 0; i < count; i++) {
                long number = startNumber + i;
                long time = i * duration;
                d.segmentUrls.add(resolve(base, expandTemplate(media, d, number, time)));
            }
        }
    }

    private static String expandTemplate(String template, DashRepresentation d, long number, long time) {
        if (template == null) return "";
        String out = template;
        out = replaceNumberFormat(out, "$Number", number);
        out = replaceNumberFormat(out, "$Time", time);
        out = out.replace("$RepresentationID$", d.id == null ? "" : d.id);
        out = out.replace("$Bandwidth$", String.valueOf(d.bandwidth));
        return out;
    }

    private static String replaceNumberFormat(String input, String token, long value) {
        String simple = token + "$";
        if (input.contains(simple)) input = input.replace(simple, String.valueOf(value));
        int from = 0;
        while (true) {
            int a = input.indexOf(token + "%", from);
            if (a < 0) break;
            int b = input.indexOf("$", a + token.length() + 1);
            if (b < 0) break;
            String fmt = input.substring(a + token.length() + 1, b);
            String replacement;
            try { replacement = String.format(Locale.US, "%" + fmt, value); }
            catch (Exception e) { replacement = String.valueOf(value); }
            input = input.substring(0, a) + replacement + input.substring(b + 1);
            from = a + replacement.length();
        }
        return input;
    }

    private static void remuxTsToMp4(File ts, File mp4) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        MediaMuxer muxer = null;
        try {
            extractor.setDataSource(ts.getAbsolutePath());
            int trackCount = extractor.getTrackCount();
            if (trackCount <= 0) throw new IllegalStateException("No media tracks");
            muxer = new MediaMuxer(mp4.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            Map<Integer,Integer> map = new HashMap<>();
            for (int i = 0; i < trackCount; i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime == null || !(mime.startsWith("video/") || mime.startsWith("audio/"))) continue;
                map.put(i, muxer.addTrack(format));
            }
            if (map.isEmpty()) throw new IllegalStateException("Unsupported TS codecs");
            muxer.start();
            ByteBuffer buffer = ByteBuffer.allocate(2 * 1024 * 1024);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            for (Map.Entry<Integer,Integer> e : map.entrySet()) {
                int src = e.getKey(); int dst = e.getValue();
                extractor.selectTrack(src);
                extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
                while (true) {
                    int sampleTrack = extractor.getSampleTrackIndex();
                    if (sampleTrack < 0) break;
                    if (sampleTrack != src) { extractor.advance(); continue; }
                    buffer.clear();
                    int size = extractor.readSampleData(buffer, 0);
                    if (size < 0) break;
                    info.offset = 0; info.size = size; info.presentationTimeUs = extractor.getSampleTime();
                    info.flags = extractor.getSampleFlags();
                    muxer.writeSampleData(dst, buffer, info);
                    extractor.advance();
                }
                extractor.unselectTrack(src);
            }
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
            if (muxer != null) {
                try { muxer.stop(); } catch (Exception ignored) {}
                try { muxer.release(); } catch (Exception ignored) {}
            }
        }
    }

    private static void appendFile(File f, OutputStream out) throws Exception {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
            byte[] b = new byte[64 * 1024]; int n;
            while ((n = in.read(b)) >= 0) out.write(b, 0, n);
        }
    }

    private static void copyFile(File from, File to) throws Exception {
        try (InputStream in = new BufferedInputStream(new FileInputStream(from)); OutputStream out = new BufferedOutputStream(new FileOutputStream(to, false))) {
            byte[] b = new byte[64 * 1024]; int n; while ((n = in.read(b)) >= 0) out.write(b, 0, n);
        }
    }

    private static File siblingWithExtension(File original, String ext) {
        String n = original.getName();
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        return new File(original.getParentFile(), n + ext);
    }

    private static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) { File[] children = f.listFiles(); if (children != null) for (File c : children) deleteRecursively(c); }
        f.delete();
    }

    private static String resolve(String base, String relative) throws Exception {
        if (relative == null || relative.isEmpty()) return base;
        URI b = new URI(base);
        return b.resolve(relative).toString();
    }

    private static String attrString(String line, String name) {
        String needle = name + "=";
        int p = line.indexOf(needle);
        if (p < 0) return null;
        int start = p + needle.length();
        if (start >= line.length()) return null;
        if (line.charAt(start) == '"') {
            int end = line.indexOf('"', start + 1);
            return end > start ? line.substring(start + 1, end) : null;
        }
        int comma = line.indexOf(',', start);
        return (comma < 0 ? line.substring(start) : line.substring(start, comma)).trim();
    }

    private static long attrLong(String line, String name, long fallback) {
        try { String s = attrString(line, name); return s == null ? fallback : Long.parseLong(s); } catch (Exception e) { return fallback; }
    }

    private static String firstChildText(Element parent, String tag) {
        Element e = firstChildElement(parent, tag);
        return e == null ? null : e.getTextContent().trim();
    }

    private static Element firstChildElement(Element parent, String tag) {
        NodeList children = parent.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node n = children.item(i);
            if (n instanceof Element && tag.equals(((Element)n).getTagName())) return (Element)n;
        }
        return null;
    }

    private static long parseLong(String s, long fallback) {
        try { return s == null || s.isEmpty() ? fallback : Long.parseLong(s); } catch (Exception e) { return fallback; }
    }

    private static double parseDurationSeconds(String s) {
        try { return s == null || s.isEmpty() ? 0d : Duration.parse(s).toMillis() / 1000d; } catch (Exception e) { return 0d; }
    }

    private static void ensureNotPaused(Control c) throws PauseException {
        if (c != null && c.isPaused()) throw new PauseException();
        if (Thread.currentThread().isInterrupted()) throw new PauseException();
    }

    static final class PauseException extends Exception {}
    private static final class HlsPlan { final List<String> segments = new ArrayList<>(); String initUrl; boolean fragmentedMp4; }
    private static final class DashRepresentation {
        String id, mime, directUrl, initializationUrl; long bandwidth; boolean protectedContent;
        final List<String> segmentUrls = new ArrayList<>();
    }
}
