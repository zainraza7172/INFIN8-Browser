package com.infin8.browser;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.security.NetworkSecurityPolicy;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Non-sensitive browser security and diagnostics center.
 * Never exposes WireGuard keys, cookies, passwords, browsing history or private URLs.
 */
public final class SecurityCenterActivity extends Activity {
    private static final String PREFS = "infin8_browser_data";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 36, 0xFFEAF2FF, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xFF0D1826, 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tcp.setMargins(dp(14), 0, 0, 0);
        titleCol.setLayoutParams(tcp);
        titleCol.addView(text("Security Center", 27, Color.WHITE, Typeface.BOLD));
        titleCol.addView(text("Phase 4C • hardening & diagnostics", 12, 0xFF7F91AA, Typeface.NORMAL));
        header.addView(titleCol);
        root.addView(header);

        TextView banner = text(coreStatusText(), 15, Color.WHITE, Typeface.BOLD);
        banner.setPadding(dp(16), dp(14), dp(16), dp(14));
        banner.setBackground(round(0xFF0E2236, 18, ThemePalette.accent(this), 1));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.setMargins(0, dp(18), 0, dp(12));
        root.addView(banner, blp);

        section(root, "WEBVIEW HARDENING");
        root.addView(statusRow("Cleartext HTTP", cleartextBlocked() ? "BLOCKED" : "ALLOWED",
                cleartextBlocked(), "Android network policy is checked at runtime."));
        root.addView(statusRow("Mixed content", "BLOCKED", true,
                "HTTPS pages cannot load insecure HTTP subresources."));
        root.addView(statusRow("Local file/content access", "BLOCKED", true,
                "INFIN8 home is served through WebViewAssetLoader instead of file:// access."));
        root.addView(statusRow("Invalid SSL certificates", "FAIL CLOSED", true,
                "Certificate errors are cancelled; INFIN8 does not proceed through them."));
        root.addView(statusRow("Safe Browsing", safeBrowsingSupported() ? "ENABLED" : "OS LIMITED",
                safeBrowsingSupported(), safeBrowsingSupported()
                        ? "Android WebView Safe Browsing is requested for normal and Incognito WebViews."
                        : "This Android version does not expose the modern WebView Safe Browsing API."));
        root.addView(statusRow("WebRTC / geolocation", "SHIELDED", true,
                "WebRTC local-address exposure is restricted and WebView geolocation prompts are denied."));

        section(root, "PRIVACY & PROCESS");
        root.addView(statusRow("Incognito process", Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? "ISOLATED PROFILE" : "SEPARATE PROCESS",
                true, Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                        ? "Separate process plus a dedicated WebView data-directory suffix."
                        : "Separate process; dedicated data-directory suffix requires Android 9+."));
        root.addView(statusRow("External app hand-off", prefs.getBoolean(SettingsActivity.KEY_ASK_EXTERNAL_APPS, true) ? "ASK FIRST" : "DIRECT",
                prefs.getBoolean(SettingsActivity.KEY_ASK_EXTERNAL_APPS, true),
                "When enabled, websites must get your confirmation before opening supported external apps."));
        root.addView(statusRow("WireGuard profile", SecureConfigStore.hasConfig(this) ? "IMPORTED" : "NOT IMPORTED",
                true, SecureConfigStore.hasConfig(this)
                        ? "Stored with Android Keystore encryption; the private key is not included in diagnostics."
                        : "No WireGuard profile is currently stored on this device."));
        root.addView(statusRow("USA connection mode", ConnectionSettings.modeLabel(this).toUpperCase(java.util.Locale.US),
                true, ConnectionSettings.isProxyMode(this)
                        ? (ConnectionSettings.hasProxy(this) ? "Global proxy is configured; browsing still requires a verified US proxy exit." : "Proxy mode is selected but no proxy is configured.")
                        : "Embedded app-scoped WireGuard mode is selected."));

        section(root, "RUNTIME");
        root.addView(infoRow("App version", appVersion()));
        root.addView(infoRow("Android", Build.VERSION.RELEASE + " • API " + Build.VERSION.SDK_INT));
        root.addView(infoRow("WebView provider", webViewProvider()));
        root.addView(infoRow("Background browsing", prefs.getBoolean(SettingsActivity.KEY_KEEP_BROWSER_ACTIVE, true) ? "Enabled" : "Disabled"));
        root.addView(infoRow("Smart memory saver", prefs.getBoolean(SettingsActivity.KEY_SMART_MEMORY_SAVER, true) ? "Enabled" : "Disabled"));
        root.addView(infoRow("Camera permission", permissionState(Manifest.permission.CAMERA)));
        root.addView(infoRow("Microphone permission", permissionState(Manifest.permission.RECORD_AUDIO)));

        section(root, "DIAGNOSTICS");
        TextView note = text("The report below never includes browsing history, open URLs, cookies, passwords, Incognito data, IP addresses, or WireGuard private keys.",
                12, 0xFF8190A5, Typeface.NORMAL);
        note.setPadding(dp(4), 0, dp(4), dp(10));
        root.addView(note);
        TextView copy = text("Copy non-sensitive diagnostic report", 15, Color.WHITE, Typeface.BOLD);
        copy.setGravity(Gravity.CENTER);
        copy.setBackground(round(ThemePalette.accentStrong(this), 18, ThemePalette.accent(this), 1));
        copy.setOnClickListener(v -> copyDiagnostics());
        root.addView(copy, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        return scroll;
    }

    private String coreStatusText() {
        if (cleartextBlocked()) return "Core WebView hardening is active";
        return "Security attention needed: cleartext traffic is permitted";
    }

    private boolean cleartextBlocked() {
        try {
            return !NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted();
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean safeBrowsingSupported() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
    }

    private String appVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? info.getLongVersionCode() : info.versionCode;
            return info.versionName + " (" + code + ")";
        } catch (Exception ignored) {
            return "Unknown";
        }
    }

    private String webViewProvider() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return "Provider details unavailable on this Android version";
        try {
            PackageInfo info = WebView.getCurrentWebViewPackage();
            if (info == null) return "Unavailable";
            return info.packageName + " • " + info.versionName;
        } catch (Exception ignored) {
            return "Unavailable";
        }
    }

    private String permissionState(String permission) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return "Granted by install model";
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED ? "Granted" : "Not granted";
    }

    private void copyDiagnostics() {
        String report = "INFIN8 Browser Security Diagnostics\n"
                + "App: " + appVersion() + "\n"
                + "Android: " + Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT + "\n"
                + "WebView: " + webViewProvider() + "\n"
                + "Cleartext HTTP: " + (cleartextBlocked() ? "blocked" : "permitted") + "\n"
                + "Mixed content: blocked\n"
                + "Local file/content access: blocked\n"
                + "SSL errors: fail closed\n"
                + "Safe Browsing API: " + (safeBrowsingSupported() ? "enabled/requested" : "not available") + "\n"
                + "Incognito: separate process" + (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? " + isolated WebView suffix" : "") + "\n"
                + "External app confirmation: " + (prefs.getBoolean(SettingsActivity.KEY_ASK_EXTERNAL_APPS, true) ? "on" : "off") + "\n"
                + "WireGuard config present: " + (SecureConfigStore.hasConfig(this) ? "yes" : "no") + "\n"
                + "USA connection mode: " + ConnectionSettings.modeLabel(this) + "\n"
                + "Proxy configured: " + (ConnectionSettings.hasProxy(this) ? "yes" : "no") + "\n"
                + "Background browsing: " + (prefs.getBoolean(SettingsActivity.KEY_KEEP_BROWSER_ACTIVE, true) ? "on" : "off") + "\n"
                + "Smart memory saver: " + (prefs.getBoolean(SettingsActivity.KEY_SMART_MEMORY_SAVER, true) ? "on" : "off") + "\n";
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("INFIN8 diagnostics", report));
        Toast.makeText(this, "Diagnostic report copied", Toast.LENGTH_SHORT).show();
    }

    private View statusRow(String title, String value, boolean good, String summary) {
        LinearLayout card = cardBase();
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 15, 0xFFF2F6FC, Typeface.BOLD);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = text(value, 12, good ? ThemePalette.accent(this) : 0xFFFFA35C, Typeface.BOLD);
        top.addView(t);
        top.addView(v);
        card.addView(top);
        TextView s = text(summary, 12, 0xFF8190A5, Typeface.NORMAL);
        s.setPadding(0, dp(6), 0, 0);
        card.addView(s);
        return card;
    }

    private View infoRow(String title, String value) {
        LinearLayout card = cardBase();
        TextView t = text(title, 13, 0xFF8EA0B8, Typeface.BOLD);
        TextView v = text(value, 14, 0xFFEAF2FF, Typeface.NORMAL);
        v.setPadding(0, dp(5), 0, 0);
        card.addView(t);
        card.addView(v);
        return card;
    }

    private LinearLayout cardBase() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(13), dp(15), dp(13));
        card.setBackground(round(ThemePalette.surface(this), 17, 0xFF1B2A3E, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        card.setLayoutParams(lp);
        return card;
    }

    private void section(LinearLayout root, String title) {
        TextView t = text(title, 11, ThemePalette.accent(this), Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(22), 0, dp(9));
        root.addView(t, lp);
    }

    private TextView text(String value, float size, int color, int style) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(Typeface.SANS_SERIF, style));
        return v;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
