# Changelog

## 0.5.0
- Replaced the crowded toolbar with logo + address/search bar + overflow menu.
- Added explicit × close control to every tab.
- Fixed Android back navigation to use WebView history before leaving the browser.
- Added Android 13+ OnBackInvoked handling.
- Removed USA MODE badge and enlarged INFIN8 Browser branding.
- Removed all built-in Speed Dial shortcuts; Speed Dial is custom-only.
- Removed the homepage USA Security Gate card while retaining the underlying security gate.

## 0.4.0
- Added horizontal Vivaldi-style tab strip.
- Added one-tap new tab button and long-press tab close.
- Rebuilt the new-tab page into a polished Speed Dial dashboard.
- Added locally persistent custom shortcuts with add/edit/delete controls.
- Added new-tab Google/address search.
- Preserved v0.3 USA verification gate and WireGuard fail-closed behavior.


## v0.3.0 — Automatic USA Security Gate
- Added automatic VPN exit-country verification after WireGuard connects.
- Uses multiple public IP geolocation checks with a tie-breaker to handle stale databases.
- Internet remains blocked until the exit is verified as United States.
- Added a WebView process-level fail-closed proxy gate while unverified/disconnected.
- Re-verifies the exit periodically and when returning to the app after the verification becomes stale.
- USA status button now distinguishes connected/unverified from USA-verified.
- VPN configuration continues to be encrypted locally with Android Keystore.

## v0.2.0
- Embedded WireGuard tunnel support.
- Import Proton WireGuard .conf profiles securely.
- App-only VPN routing for INFIN8 Browser.
- Browser navigation blocked while WireGuard is disconnected.


## v0.6
- Removed left toolbar logo for a cleaner top bar
- Replaced the right toolbar menu icon with the INFIN8 mascot logo
- Refined homepage wordmark styling for a more unique brand font feel


## v0.7
- Lowered the top toolbar slightly for better spacing
- Reduced the top-right logo/menu button size
- Added the mascot logo beside the homepage INFIN8 Browser wordmark
- Set the mascot logo as the Android app icon


## v0.8
- Restyled the top toolbar to a darker Vivaldi-inspired look
- Added a search glyph inside the rounded address field
- Updated the homepage brand line from INFIN8 Browser to INFIN8 LIMITED


## v0.9
- Made the top toolbar smaller and slightly lower from the top edge
- Reduced the top-right mascot logo button size
- Reduced the homepage logo/brand sizing slightly
- Added a Vivaldi-inspired dark bottom navigation bar with tabs, back, search, forward, and tab count controls


## v1.0
- New premium dark INFIN8 home UI inspired by the supplied reference
- Removed all filler categories/cards: Explore, Video, Shopping, Games, News, Images, Weather, AI Search, Discover, etc.
- Kept only custom shortcuts added by the user
- Home hides the browser toolbar for a clean app-like experience
- Bottom navigation simplified to Home, Tabs, Search, Menu
- Real web pages still show the compact address bar
- USA WireGuard gate, tab system and back-history behavior preserved


## v1.1
- Replaced the plain Android Tabs alert with a custom premium dark tabs panel
- Added logo thumbnails, active-tab highlighting, close buttons and styled New Tab action
- Replaced the plain PopupMenu with a custom dark floating menu matching the INFIN8 UI
- Improved bottom navigation typography, spacing, active color and dark border treatment


## v1.2
- Added persistent bookmarks with add/remove support
- Added persistent browsing history with individual delete and clear history
- Added per-tab Desktop Site / Mobile Site toggle
- Added premium dark Bookmarks and History dialogs matching the INFIN8 UI
- Kept homepage uncluttered; new features live in the Menu

## v1.5.1
- Fixed WireGuard reconnecting when INFIN8 Browser is merely minimized or sent to background
- Removed the 20-second secondary-backend VPN polling loop from the foreground keep-alive service
- MainActivity remains the single connect/disconnect authority during normal app use
- Sticky service performs at most one conservative restore attempt only after Android recreates the service following process loss
- Manual Disconnect remains authoritative and stops the foreground keeper without issuing a duplicate tunnel DOWN command

## v1.5
- Welcome splash is now shown only once per fresh app install
- Strengthened tab persistence with synchronous preference writes plus an internal backup file
- Added foreground WireGuard keep-alive service so an explicitly connected tunnel can remain active after the browser task closes, until manual disconnect
- Replaced font-dependent bottom navigation glyphs with vector Home, Tabs, Search and Menu icons
- Added native INFIN8 download manager: HTTP range segmentation, dynamic 1/4/8/16/32 parts, pause/resume, retry recovery, two-download queue, speed limiter and automatic file categories
- Added Downloads screen and browser download interception without Android DownloadManager, keeping traffic inside the INFIN8 package/VPN route
- Added page-file grabber for direct downloadable links and lightweight media URL detection
- Added built-in basic ad/tracker blocker toggle
- Added shared-link interception (Android Share -> INFIN8 Browser)
- HLS/M3U8 and MP-DASH manifests are detected but DRM-protected streams are not bypassed or downloaded

## v1.6 — Phase 2A: Download Manager Pro
- Premium Downloads Pro center with live transfer speed and ETA.
- Manual speed limit entry plus quick presets.
- Global Wi-Fi-only mode; queued downloads wait and resume when Wi-Fi returns.
- Rename files before download.
- Select Auto / 1 / 4 / 8 / 16 / 32 range parts per download.
- Optional category folder selection with automatic fallback categories.
- Improved foreground notification with active count / progress.
- Open and Share completed downloads through FileProvider content URIs.
- Delete individual files, clear completed downloads, retry all failed downloads.
- Active / Completed / Failed filters.
- Page Grabber now lets the user select which discovered direct files to queue.
- Keeps the v1.5.1 WireGuard minimize/reconnect hotfix unchanged.

Not yet in v1.6 Phase 2A: public HLS/DASH segment download/merge, torrent/magnet engine, scheduled downloads, antivirus integration. DRM bypass is intentionally not implemented.
