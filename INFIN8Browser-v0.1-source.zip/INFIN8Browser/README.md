# INFIN8 Browser — Android v0.1

A first working MVP for the personal browser project: a Vivaldi-style direction with a dedicated **USA Mode** network layer.

## What works in v0.1

- Chromium-based Android WebView browsing engine
- Address/search bar
- Back / forward / reload / home
- Multiple tabs
- Speed Dial home page for Instagram, TikTok, YouTube and YouTube Studio
- File upload picker (important for creator workflows)
- Android DownloadManager integration
- Persistent cookies/session support
- USA Mode settings
- AndroidX WebKit `ProxyController` routing hook
- HTTP / HTTPS / SOCKS proxy URL support as allowed by AndroidX WebKit
- No deliberate direct fallback rule while USA Mode is enabled
- Geolocation denied by default
- WebRTC JavaScript API shield when Document Start Script is supported
- Mixed HTTP content blocked

## Important network limitation in v0.1

`ProxyController` controls **WebView-initiated network requests**. It is not a full Android VPN/TUN implementation. The project therefore does **not** claim a complete network kill switch for every possible native/network path.

For Phase 2, the correct stronger architecture is:

```
INFIN8 Browser
      |
      +-- UI / Tabs / Chromium WebView
      |
      +-- Android VPNService / TUN
               |
               +-- encrypted tunnel
                       |
                       +-- private US VPS
                              |
                              +-- dedicated static US IPv4
```

That layer can force browser traffic through the US gateway more comprehensively and prevent fallback outside the tunnel.

## USA gateway needed

To get a real stable US public IP you still need a network endpoint physically hosted/routed in the United States, for example:

1. A private US VPS with a static IPv4 and a proxy/tunnel service; or
2. A trusted dedicated static US proxy.

For this v0.1, an IP-allowlisted/private endpoint without browser-visible username/password auth is the simplest test configuration.

### Proxy formats

Examples only:

```
http://HOST:PORT
https://HOST:PORT
socks://HOST:1080
```

Do **not** use random free proxies for social accounts.

## Build requirements

- Android Studio compatible with Android Gradle Plugin 9.4.0
- JDK 17+
- Android SDK 37
- Gradle 9.6.0

The project uses `androidx.webkit:webkit:1.17.1`.

## Open in Android Studio

1. Open the `INFIN8Browser` folder.
2. Allow Gradle sync.
3. Install SDK 37 if Android Studio asks.
4. Run on a physical Android device or emulator.
5. Tap the `🇺🇸` button.
6. Enter your private US proxy endpoint and enable USA Mode.
7. Long-press `🇺🇸` to open the IP check page.

## Phase 2 roadmap

- Android `VPNService` / TUN tunnel
- Private WireGuard-compatible US gateway
- Stronger kill switch
- DNS through tunnel
- IPv6 policy
- Connection health check before any page load
- Bookmarks + history database
- Tab groups / tab stacks
- Desktop mode per tab
- Ad/tracker blocker
- Custom Speed Dial editor
- Dark theme
- Site permissions dashboard
- Password/autofill strategy
- Vivaldi-like bottom/desktop tab UI

## Product rule

The browser should provide a **stable US-oriented browsing/network environment**, not pretend that an IP address guarantees US recommendations or platform reach.
