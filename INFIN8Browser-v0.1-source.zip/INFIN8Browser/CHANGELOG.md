# Changelog

## 0.1.0
- Initial Android browser MVP
- Multi-tab browser shell
- Speed Dial creator home
- USA Mode proxy integration
- Geolocation blocking
- WebRTC JS shield
- Upload and download support
