package com.infin8.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String HOME_URL = "file:///android_asset/start.html";
    private static final int FILE_CHOOSER_REQUEST = 501;

    private final List<BrowserTab> tabs = new ArrayList<>();
    private int currentTab = -1;

    private FrameLayout webContainer;
    private EditText addressBar;
    private Button backButton;
    private Button forwardButton;
    private Button tabsButton;
    private Button usaButton;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Locale.setDefault(Locale.US);
        setContentView(buildUi());

        ProxyManager.apply(
                this,
                getMainExecutor(),
                () -> {
                    updateUsaButton();
                    createTab(HOME_URL, true);
                },
                () -> {
                    updateUsaButton();
                    createTab(HOME_URL, true);
                    if (ProxyManager.isEnabled(this)) {
                        toast("USA Mode could not be applied on this WebView build.");
                    }
                }
        );

        Intent incoming = getIntent();
        if (incoming != null && Intent.ACTION_VIEW.equals(incoming.getAction()) && incoming.getData() != null) {
            // Load after the first WebView exists.
            webContainer.postDelayed(() -> navigate(incoming.getData().toString()), 350);
        }
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF8F9FB);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        nav.setPadding(dp(6), dp(6), dp(6), dp(4));

        backButton = smallButton("‹");
        forwardButton = smallButton("›");
        Button homeButton = smallButton("⌂");
        Button reloadButton = smallButton("↻");
        tabsButton = smallButton("1");
        usaButton = smallButton("🇺🇸");

        addressBar = new EditText(this);
        addressBar.setSingleLine(true);
        addressBar.setHint("Search or enter address");
        addressBar.setTextSize(15);
        addressBar.setPadding(dp(12), 0, dp(12), 0);
        addressBar.setBackgroundColor(0xFFFFFFFF);
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setLayoutParams(new LinearLayout.LayoutParams(0, dp(44), 1f));

        nav.addView(backButton);
        nav.addView(forwardButton);
        nav.addView(homeButton);
        nav.addView(addressBar);
        nav.addView(reloadButton);
        nav.addView(tabsButton);
        nav.addView(usaButton);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        webContainer = new FrameLayout(this);
        webContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        root.addView(nav);
        root.addView(progressBar);
        root.addView(webContainer);

        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate(addressBar.getText().toString());
                return true;
            }
            return false;
        });

        backButton.setOnClickListener(v -> {
            WebView w = currentWebView();
            if (w != null && w.canGoBack()) w.goBack();
        });
        forwardButton.setOnClickListener(v -> {
            WebView w = currentWebView();
            if (w != null && w.canGoForward()) w.goForward();
        });
        homeButton.setOnClickListener(v -> navigate(HOME_URL));
        reloadButton.setOnClickListener(v -> {
            WebView w = currentWebView();
            if (w != null) w.reload();
        });
        tabsButton.setOnClickListener(v -> showTabsDialog());
        usaButton.setOnClickListener(v -> showUsaModeDialog());
        usaButton.setOnLongClickListener(v -> {
            openIpCheck();
            return true;
        });

        updateUsaButton();
        return root;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(7), 0, dp(7), 0);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        return b;
    }

    private void createTab(String initialUrl, boolean switchToIt) {
        WebView webView = new WebView(this);
        configureWebView(webView);
        BrowserTab tab = new BrowserTab(webView, "New Tab", initialUrl);
        tabs.add(tab);
        if (switchToIt) switchToTab(tabs.size() - 1);
        webView.loadUrl(initialUrl);
        updateTabCount();
    }

    private void configureWebView(WebView webView) {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        installWebRtcShield(webView);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                if (!HOME_URL.equals(url)) addressBar.setText(url);
                updateNavState();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                BrowserTab tab = tabFor(view);
                if (tab != null) {
                    tab.url = url;
                    tab.title = view.getTitle() == null || view.getTitle().trim().isEmpty() ? url : view.getTitle();
                }
                if (view == currentWebView()) {
                    addressBar.setText(HOME_URL.equals(url) ? "" : url);
                }
                updateNavState();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return super.shouldInterceptRequest(view, request);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                BrowserTab tab = tabFor(view);
                if (tab != null && title != null) tab.title = title;
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                // Location is denied by default to avoid accidental physical-location disclosure.
                callback.invoke(origin, false, false);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallbackIn, FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePathCallbackIn;
                Intent intent = fileChooserParams.createIntent();
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    toast("No file picker available.");
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.addRequestHeader("User-Agent", userAgent);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) request.addRequestHeader("Cookie", cookies);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setAllowedOverMetered(true);
                request.setAllowedOverRoaming(false);
                String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType);
                String filename = "INFIN8_" + System.currentTimeMillis() + (ext == null ? "" : "." + ext);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                dm.enqueue(request);
                toast("Download started");
            } catch (Exception e) {
                toast("Download could not start");
            }
        });
    }

    private void installWebRtcShield(WebView webView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        String script = "(() => { try {" +
                "Object.defineProperty(window,'RTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'webkitRTCPeerConnection',{value:undefined,configurable:false});" +
                "Object.defineProperty(window,'mozRTCPeerConnection',{value:undefined,configurable:false});" +
                "} catch(e) {} })();";
        try {
            WebViewCompat.addDocumentStartJavaScript(webView, script, Collections.singleton("*"));
        } catch (Exception ignored) {}
    }

    private void navigate(String input) {
        WebView webView = currentWebView();
        if (webView == null) return;
        String text = input == null ? "" : input.trim();
        if (text.isEmpty()) return;

        String url;
        if (HOME_URL.equals(text) || text.startsWith("http://") || text.startsWith("https://") || text.startsWith("file://")) {
            url = text;
        } else if (text.matches("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}([/:?#].*)?$")) {
            url = "https://" + text;
        } else {
            url = "https://www.google.com/search?q=" + urlEncode(text);
        }
        webView.loadUrl(url);
    }

    private void switchToTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        webContainer.removeAllViews();
        currentTab = index;
        WebView webView = tabs.get(index).webView;
        ViewGroup parent = (ViewGroup) webView.getParent();
        if (parent != null) parent.removeView(webView);
        webContainer.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        String url = webView.getUrl();
        addressBar.setText(url == null || HOME_URL.equals(url) ? "" : url);
        updateNavState();
        updateTabCount();
    }

    private void closeTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        BrowserTab tab = tabs.remove(index);
        if (tab.webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
        }
        tab.webView.stopLoading();
        tab.webView.destroy();

        if (tabs.isEmpty()) {
            currentTab = -1;
            createTab(HOME_URL, true);
            return;
        }
        int next = Math.min(index, tabs.size() - 1);
        switchToTab(next);
    }

    private void showTabsDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(10), dp(8), dp(10), dp(8));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Tabs")
                .setView(layout)
                .setPositiveButton("+ New tab", null)
                .setNegativeButton("Close", null)
                .create();

        for (int i = 0; i < tabs.size(); i++) {
            int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            Button open = new Button(this);
            open.setAllCaps(false);
            open.setText(shortTitle(tabs.get(i).title));
            open.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            open.setLayoutParams(new LinearLayout.LayoutParams(0, dp(52), 1));
            open.setOnClickListener(v -> {
                switchToTab(index);
                dialog.dismiss();
            });

            Button close = smallButton("×");
            close.setOnClickListener(v -> {
                dialog.dismiss();
                closeTab(index);
            });

            row.addView(open);
            row.addView(close);
            layout.addView(row);
        }

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            createTab(HOME_URL, true);
            dialog.dismiss();
        }));
        dialog.show();
    }

    private void showUsaModeDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22), dp(8), dp(22), 0);

        CheckBox enabled = new CheckBox(this);
        enabled.setText("Enable USA Mode");
        enabled.setChecked(ProxyManager.isEnabled(this));

        TextView description = new TextView(this);
        description.setText("Enter your private/static US proxy endpoint. Example: socks://HOST:1080 or http://HOST:PORT. v0.1 is designed for a trusted private endpoint; do not use unknown free proxies.");
        description.setTextSize(13);
        description.setPadding(0, dp(6), 0, dp(8));

        EditText proxy = new EditText(this);
        proxy.setSingleLine(true);
        proxy.setHint("socks://us-gateway.example.com:1080");
        proxy.setText(ProxyManager.getProxyUrl(this));

        TextView note = new TextView(this);
        note.setText("Long-press the 🇺🇸 button to open an IP-check page. WebRTC and geolocation are blocked in this MVP. A full VPNService/TUN kill-switch layer is planned for Phase 2.");
        note.setTextSize(12);
        note.setPadding(0, dp(10), 0, 0);

        layout.addView(enabled);
        layout.addView(description);
        layout.addView(proxy);
        layout.addView(note);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("🇺🇸 USA Mode")
                .setView(layout)
                .setPositiveButton("Apply", null)
                .setNeutralButton("IP check", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String proxyUrl = proxy.getText().toString().trim();
                if (enabled.isChecked() && proxyUrl.isEmpty()) {
                    proxy.setError("Proxy endpoint required");
                    return;
                }
                ProxyManager.save(this, enabled.isChecked(), proxyUrl);
                ProxyManager.apply(
                        this,
                        getMainExecutor(),
                        () -> {
                            updateUsaButton();
                            toast(enabled.isChecked() ? "USA Mode applied" : "USA Mode disabled");
                            WebView w = currentWebView();
                            if (w != null) w.reload();
                            dialog.dismiss();
                        },
                        () -> toast("Proxy override is not supported on this WebView version.")
                );
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                dialog.dismiss();
                openIpCheck();
            });
        });
        dialog.show();
    }

    private void openIpCheck() {
        navigate("https://ipinfo.io/");
    }

    private void updateUsaButton() {
        if (usaButton == null) return;
        boolean active = ProxyManager.isEnabled(this) && !ProxyManager.getProxyUrl(this).trim().isEmpty() && ProxyManager.isSupported();
        usaButton.setText(active ? "🇺🇸●" : "🇺🇸");
        usaButton.setContentDescription(active ? "USA Mode enabled" : "USA Mode disabled");
    }

    private void updateNavState() {
        WebView w = currentWebView();
        if (w == null) return;
        backButton.setEnabled(w.canGoBack());
        forwardButton.setEnabled(w.canGoForward());
    }

    private void updateTabCount() {
        if (tabsButton != null) tabsButton.setText(String.valueOf(Math.max(1, tabs.size())));
    }

    private BrowserTab tabFor(WebView webView) {
        for (BrowserTab tab : tabs) if (tab.webView == webView) return tab;
        return null;
    }

    private WebView currentWebView() {
        if (currentTab < 0 || currentTab >= tabs.size()) return null;
        return tabs.get(currentTab).webView;
    }

    private String shortTitle(String title) {
        if (title == null || title.trim().isEmpty()) return "New Tab";
        return title.length() > 36 ? title.substring(0, 36) + "…" : title;
    }

    private String urlEncode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception ignored) {
            return value.replace(" ", "+");
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                result = new Uri[count];
                for (int i = 0; i < count; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        filePathCallback.onReceiveValue(result);
        filePathCallback = null;
    }

    @Override
    public void onBackPressed() {
        WebView w = currentWebView();
        if (w != null && w.canGoBack()) {
            w.goBack();
        } else if (tabs.size() > 1) {
            closeTab(currentTab);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        for (BrowserTab tab : tabs) {
            if (tab.webView.getParent() instanceof ViewGroup) {
                ((ViewGroup) tab.webView.getParent()).removeView(tab.webView);
            }
            tab.webView.destroy();
        }
        tabs.clear();
        super.onDestroy();
    }

    private static final class BrowserTab {
        final WebView webView;
        String title;
        String url;

        BrowserTab(WebView webView, String title, String url) {
            this.webView = webView;
            this.title = title;
            this.url = url;
        }
    }
}
