package com.infin8.browser;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

import java.util.concurrent.Executor;

public final class ProxyManager {
    private static final String PREFS = "infin8_network";
    private static final String KEY_ENABLED = "usa_mode_enabled";
    private static final String KEY_PROXY = "proxy_url";

    private ProxyManager() {}

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static String getProxyUrl(Context context) {
        return prefs(context).getString(KEY_PROXY, "");
    }

    public static void save(Context context, boolean enabled, String proxyUrl) {
        prefs(context).edit()
                .putBoolean(KEY_ENABLED, enabled)
                .putString(KEY_PROXY, proxyUrl == null ? "" : proxyUrl.trim())
                .apply();
    }

    public static boolean isSupported() {
        return WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE);
    }

    public static void apply(Context context, Executor executor, Runnable onApplied, Runnable onUnsupported) {
        if (!isSupported()) {
            if (onUnsupported != null) onUnsupported.run();
            return;
        }

        boolean enabled = isEnabled(context);
        String proxyUrl = getProxyUrl(context).trim();
        ProxyController controller = ProxyController.getInstance();

        if (!enabled) {
            controller.clearProxyOverride(executor, onApplied == null ? () -> {} : onApplied);
            return;
        }

        if (proxyUrl.isEmpty()) {
            if (onUnsupported != null) onUnsupported.run();
            return;
        }

        // Deliberately NO addDirect() fallback. If the proxy cannot be reached,
        // WebView requests fail instead of intentionally falling back to a direct rule.
        ProxyConfig config = new ProxyConfig.Builder()
                .addProxyRule(proxyUrl)
                .build();
        controller.setProxyOverride(config, executor, onApplied == null ? () -> {} : onApplied);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
