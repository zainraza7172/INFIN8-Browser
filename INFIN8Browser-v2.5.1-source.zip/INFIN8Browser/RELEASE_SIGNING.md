# INFIN8 Browser Production Signing

Phase 4D keeps the production keystore completely outside the repository and source ZIP.

## GitHub Actions secrets

Add these four repository secrets before making a public production release:

- `INFIN8_RELEASE_KEYSTORE_BASE64` — base64 of the `.jks` / `.keystore` file
- `INFIN8_RELEASE_KEYSTORE_PASSWORD`
- `INFIN8_RELEASE_KEY_ALIAS`
- `INFIN8_RELEASE_KEY_PASSWORD`

The workflow writes the decoded keystore only into the temporary GitHub runner directory. It is never uploaded as an artifact.

If those secrets are missing, the workflow still builds the normal debug APK for testing and produces unsigned release APK/AAB files. It does **not** silently sign production artifacts with the debug key.

## Create a production key locally

Example with the JDK `keytool` command:

```bash
keytool -genkeypair -v \
  -keystore infin8-release.jks \
  -alias infin8 \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000
```

Keep the keystore and passwords backed up securely. Losing the production signing key can prevent future updates from being accepted by already-installed copies distributed outside Play App Signing.

## Base64 for GitHub secret

Linux/macOS:

```bash
base64 -w 0 infin8-release.jks
```

If your `base64` does not support `-w`, use:

```bash
base64 infin8-release.jks | tr -d '\n'
```

Do not commit the key, base64 text, or passwords to GitHub.
