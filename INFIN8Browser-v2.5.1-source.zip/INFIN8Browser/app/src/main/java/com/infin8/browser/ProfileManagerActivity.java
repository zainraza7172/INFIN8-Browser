package com.infin8.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewFeature;

import java.util.List;

public class ProfileManagerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        rebuild();
    }

    private void rebuild() { setContentView(buildUi()); }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(36));
        scroll.addView(root);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 36, Color.WHITE, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xFF0D1826, 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(14), 0, 0, 0);
        titleCol.addView(text("Browser Profiles", 27, Color.WHITE, Typeface.BOLD));
        titleCol.addView(text("Separate accounts, storage and profile settings", 12, 0xFF8394AA, Typeface.NORMAL));
        head.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(head);

        TextView support = text(BrowserProfiles.multiProfileSupported()
                ? "✓ Isolated WebView profiles supported on this device"
                : "⚠ This WebView does not support isolated multi-profile browsing", 12,
                BrowserProfiles.multiProfileSupported() ? 0xFF70D59B : 0xFFFFB86B, Typeface.BOLD);
        support.setPadding(dp(12), dp(15), dp(12), dp(12));
        root.addView(support);

        Button create = button("＋ Create profile");
        create.setOnClickListener(v -> showCreateDialog());
        create.setEnabled(BrowserProfiles.multiProfileSupported());
        root.addView(create, lpMatch(dp(52), 0, dp(10)));

        String activeId = BrowserProfiles.activeId(this);
        List<BrowserProfiles.ProfileData> profiles = BrowserProfiles.all(this);
        for (BrowserProfiles.ProfileData p : profiles) root.addView(profileCard(p, p.id.equals(activeId)));

        TextView note = text("Profiles use Android WebView's official multi-profile API, so cookies, WebStorage, service workers and profile cache are isolated. INFIN8 also keeps its own history, bookmarks and tab session separately per profile. Proxy settings apply to the currently active profile only and must pass the existing USA fail-closed check.", 12, 0xFF7789A1, Typeface.NORMAL);
        note.setPadding(dp(4), dp(18), dp(4), 0);
        root.addView(note);
        return scroll;
    }

    private View profileCard(BrowserProfiles.ProfileData p, boolean active) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(14), dp(15), dp(14));
        card.setBackground(round(active ? 0xFF10233B : 0xFF0B1624, 20, active ? ThemePalette.accent(this) : 0xFF1B314D, 1));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(clp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(p.name + (active ? "  • ACTIVE" : ""), 17, Color.WHITE, Typeface.BOLD);
        top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView id = text(p.isDefault() ? "DEFAULT" : "PROFILE", 10, active ? ThemePalette.accent(this) : 0xFF6F829A, Typeface.BOLD);
        top.addView(id);
        card.addView(top);

        TextView summary = text(BrowserProfiles.profileSummary(p), 12, 0xFF8A9AB0, Typeface.NORMAL);
        summary.setPadding(0, dp(6), 0, dp(10));
        card.addView(summary);
        TextView connection = text(p.hasProxy() ? "Connection: " + p.proxyUrl : "Connection: INFIN8 WireGuard / USA gate", 11, p.hasProxy() ? 0xFF74B9FF : 0xFF7B8DA5, Typeface.NORMAL);
        card.addView(connection);

        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(12), 0, 0);
        Button open = smallButton(active ? "Open" : "Switch");
        Button edit = smallButton("Edit");
        Button copy = smallButton("Clone");
        actions.addView(open, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(44), 1f); ap.setMargins(dp(7),0,0,0);
        actions.addView(edit, ap);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(44), 1f); cp.setMargins(dp(7),0,0,0);
        actions.addView(copy, cp);
        card.addView(actions);

        open.setOnClickListener(v -> switchProfile(p.id));
        edit.setOnClickListener(v -> showEditDialog(p));
        copy.setOnClickListener(v -> cloneProfile(p));

        if (!p.isDefault()) {
            TextView delete = text("Delete profile", 12, 0xFFFF7A86, Typeface.BOLD);
            delete.setGravity(Gravity.CENTER);
            delete.setPadding(0, dp(12), 0, dp(2));
            delete.setOnClickListener(v -> confirmDelete(p));
            card.addView(delete);
        }
        return card;
    }

    private void showCreateDialog() {
        EditText e = input("Profile name", "Work");
        new AlertDialog.Builder(this).setTitle("Create isolated profile").setView(e)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Create", (d,w) -> {
                    try {
                        BrowserProfiles.ProfileData p = BrowserProfiles.create(this, e.getText().toString());
                        showEditDialog(p);
                    } catch (Exception ex) { toast(ex.getMessage()); }
                }).show();
    }

    private void cloneProfile(BrowserProfiles.ProfileData p) {
        try {
            BrowserProfiles.duplicateSettings(this, p.id, p.name + " Copy");
            toast("Profile settings cloned; account cookies were not copied");
            rebuild();
        } catch (Exception e) { toast(e.getMessage()); }
    }

    private void showEditDialog(BrowserProfiles.ProfileData p) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(8), dp(18), dp(8));
        scroll.addView(form);

        EditText name = input("Name", p.name); form.addView(label("Profile name")); form.addView(name);
        Spinner ua = spinner(new String[]{"Android / system", "Desktop", "Custom user agent"}, uaIndex(p.uaMode)); form.addView(label("Browser identification")); form.addView(ua);
        EditText customUa = input("Custom user agent", p.customUa); form.addView(customUa);
        Spinner language = spinner(new String[]{"en-US","en-GB","es-ES","de-DE","fr-FR","ur-PK"}, indexOf(new String[]{"en-US","en-GB","es-ES","de-DE","fr-FR","ur-PK"}, p.language)); form.addView(label("Language")); form.addView(language);
        Spinner timezone = spinner(new String[]{"system","America/New_York","America/Chicago","America/Denver","America/Los_Angeles","Europe/London","Asia/Karachi"}, indexOf(new String[]{"system","America/New_York","America/Chicago","America/Denver","America/Los_Angeles","Europe/London","Asia/Karachi"}, p.timezone)); form.addView(label("Time zone preference")); form.addView(timezone);
        Spinner region = spinner(new String[]{"US","GB","CA","AU","DE","FR","PK"}, indexOf(new String[]{"US","GB","CA","AU","DE","FR","PK"}, p.region)); form.addView(label("Regional setting")); form.addView(region);
        EditText proxy = input("http://host:port or socks://host:port", p.proxyUrl); form.addView(label("Profile proxy (optional)")); form.addView(proxy);
        TextView proxyNote = text("HTTP, HTTPS and SOCKS are accepted. Credentials inside the URL are rejected so proxy passwords are not stored as plaintext. A configured proxy must verify as a US exit before browsing is unlocked.", 11, 0xFF7789A1, Typeface.NORMAL); proxyNote.setPadding(0,dp(6),0,0); form.addView(proxyNote);

        new AlertDialog.Builder(this).setTitle("Edit " + p.name).setView(scroll)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d,w) -> {
                    p.name = name.getText().toString();
                    p.uaMode = ua.getSelectedItemPosition()==1 ? "desktop" : ua.getSelectedItemPosition()==2 ? "custom" : "android";
                    p.customUa = customUa.getText().toString().trim();
                    p.language = String.valueOf(language.getSelectedItem());
                    p.timezone = String.valueOf(timezone.getSelectedItem());
                    p.region = String.valueOf(region.getSelectedItem());
                    String rawProxy = proxy.getText().toString().trim();
                    String normalized = BrowserProfiles.normalizeProxy(rawProxy);
                    if (!rawProxy.isEmpty() && normalized.isEmpty()) {
                        toast("Proxy rejected. Use HTTP/HTTPS/SOCKS host:port without embedded credentials.");
                        return;
                    }
                    p.proxyUrl = normalized;
                    BrowserProfiles.upsert(this, p);
                    toast("Profile saved — tap Open/Switch to apply browser identity or proxy changes");
                    rebuild();
                }).show();
    }

    private void switchProfile(String id) {
        BrowserProfiles.setActive(this, id);
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("switch_profile", id);
        i.putExtra("force_profile_reload", true);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
        finish();
    }

    private void confirmDelete(BrowserProfiles.ProfileData p) {
        new AlertDialog.Builder(this).setTitle("Delete " + p.name + "?")
                .setMessage("Its isolated WebView data, INFIN8 history, bookmarks and tabs will be removed. This cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d,w) -> {
                    try {
                        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                            boolean deleted = true;
                            try {
                                ProfileStore store = ProfileStore.getInstance();
                                if (store.getAllProfileNames().contains(p.webViewProfileName())) deleted = store.deleteProfile(p.webViewProfileName());
                            } catch (Exception ignored) { deleted = false; }
                            if (!deleted) { toast("Profile data is still in use. Switch away/close it and try again."); return; }
                        }
                        getSharedPreferences(BrowserProfiles.PREFS, MODE_PRIVATE).edit()
                                .remove("history_json__profile__" + p.id)
                                .remove("bookmarks_json__profile__" + p.id)
                                .remove("tab_session_json__profile__" + p.id)
                                .remove("current_tab_index__profile__" + p.id)
                                .apply();
                        BrowserProfiles.deleteMetadata(this, p.id);
                        try { deleteFile("tab_session_" + p.id + ".json"); } catch (Exception ignored) {}
                        toast("Profile deleted");
                        rebuild();
                    } catch (Exception e) { toast("Could not delete profile data yet. Close its tabs and try again."); }
                }).show();
    }

    private int uaIndex(String m) { return "desktop".equals(m) ? 1 : "custom".equals(m) ? 2 : 0; }
    private int indexOf(String[] a, String v) { for(int i=0;i<a.length;i++) if(a[i].equals(v)) return i; return 0; }
    private Spinner spinner(String[] values, int selected) { Spinner s=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values); s.setAdapter(a); s.setSelection(Math.max(0, Math.min(selected, values.length-1))); return s; }
    private EditText input(String hint, String value) { EditText e=new EditText(this); e.setHint(hint); e.setText(value==null?"":value); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF66788F); e.setSingleLine(true); e.setPadding(dp(12),dp(8),dp(12),dp(8)); return e; }
    private TextView label(String s) { TextView t=text(s,12,0xFF9EB0C8,Typeface.BOLD); t.setPadding(0,dp(12),0,dp(3)); return t; }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(round(ThemePalette.accentStrong(this),18,ThemePalette.accent(this),1)); return b; }
    private Button smallButton(String s) { Button b=button(s); b.setTextSize(12); return b; }
    private LinearLayout.LayoutParams lpMatch(int h,int top,int bottom){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,h);lp.setMargins(0,top,0,bottom);return lp;}
    private TextView text(String s,float sp,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setTypeface(Typeface.create(Typeface.SANS_SERIF,style));return t;}
    private GradientDrawable round(int color,int radius,int strokeColor,int strokeWidth){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));if(strokeWidth>0)g.setStroke(dp(strokeWidth),strokeColor);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private void toast(String s){Toast.makeText(this,s==null?"Done":s,Toast.LENGTH_SHORT).show();}
}
