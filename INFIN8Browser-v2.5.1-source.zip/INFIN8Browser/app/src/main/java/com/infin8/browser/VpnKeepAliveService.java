package com.infin8.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import com.wireguard.android.backend.Tunnel;

/**
 * Foreground lifetime keeper for the user-enabled WireGuard tunnel.
 *
 * Important: while MainActivity is alive this service does NOT poll or re-issue
 * setState(UP). Repeated state polling from a second GoBackend instance caused
 * false DOWN events on some devices when the browser was merely minimized,
 * which made the VPN reconnect unnecessarily.
 *
 * Normal lifetime:
 * - MainActivity owns connect/disconnect.
 * - This foreground service only keeps the process/tunnel lifetime stable.
 * - If Android kills and later recreates this sticky service, we perform one
 *   conservative restore check and reconnect only if the tunnel is genuinely DOWN.
 */
public final class VpnKeepAliveService extends Service implements WireGuardManager.Listener {
    public static final String ACTION_START = "com.infin8.browser.vpn.START";
    public static final String ACTION_STOP = "com.infin8.browser.vpn.STOP";

    private static final String CHANNEL_ID = "infin8_vpn";
    private static final int NOTIFICATION_ID = 8008;
    private static final String PREFS = "infin8_browser_data";
    private static final String KEEP_KEY = "keep_vpn_connected";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WireGuardManager restoreWireGuard;
    private boolean stopping;
    private boolean restoreAttempted;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopping = true;
            handler.removeCallbacksAndMessages(null);
            // MainActivity is the single authority that actually calls disconnect().
            // Avoid a second backend issuing DOWN at the same time.
            shutdownRestoreManager();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!shouldKeepConnected()) {
            stopSelfSafely();
            return START_NOT_STICKY;
        }

        stopping = false;
        startForeground(NOTIFICATION_ID,
                notification("USA network active", "WireGuard stays connected until you disconnect it"));

        // ACTION_START comes from the browser while its own WireGuardManager is active.
        // Do NOT refresh/reconnect here. That duplicate polling was the minimize bug.
        if (ACTION_START.equals(action)) {
            return START_STICKY;
        }

        // A null intent means Android recreated this START_STICKY service after process loss.
        // In that exceptional case, perform one restore check only.
        if (intent == null && !restoreAttempted) {
            restoreAttempted = true;
            handler.postDelayed(this::restoreAfterProcessRecreation, 1200L);
        }
        return START_STICKY;
    }

    private boolean shouldKeepConnected() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEEP_KEY, false);
    }

    private void restoreAfterProcessRecreation() {
        if (stopping || !shouldKeepConnected()) return;
        if (restoreWireGuard != null) return;

        restoreWireGuard = new WireGuardManager(getApplicationContext(), this);
        if (!restoreWireGuard.hasConfig()) {
            stopSelfSafely();
            return;
        }

        updateNotification("Checking USA network…", "Restoring previous WireGuard state");
        restoreWireGuard.refreshState();
    }

    @Override
    public void onStateChanged(Tunnel.State state) {
        if (stopping || !shouldKeepConnected()) return;

        if (state == Tunnel.State.UP) {
            updateNotification("USA network connected", "INFIN8 WireGuard is active");
            // No health-loop. Leave the already-UP tunnel alone.
            return;
        }

        // This callback is used only during sticky-service restoration after process loss.
        // Reconnect once, never in a repeating loop.
        if (restoreWireGuard != null) {
            if (VpnService.prepare(this) != null) {
                updateNotification("VPN permission needed", "Open INFIN8 Browser to reconnect");
                shutdownRestoreManager();
                return;
            }
            updateNotification("Restoring USA network…", "Reconnecting WireGuard after Android restart");
            WireGuardManager manager = restoreWireGuard;
            restoreWireGuard = null; // prevents a DOWN callback from scheduling another retry loop
            manager.connect();
            // Allow its queued connect operation to finish before shutting its executor down.
            handler.postDelayed(manager::shutdown, 2500L);
        }
    }

    @Override
    public void onError(String message, Throwable error) {
        if (stopping || !shouldKeepConnected()) return;
        updateNotification("USA network needs attention",
                message == null ? "Open INFIN8 Browser to reconnect" : message);
        shutdownRestoreManager();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Intentionally do nothing. Minimizing/swiping away the browser must not trigger
        // a state refresh or reconnect. The foreground service simply remains alive.
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        shutdownRestoreManager();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void shutdownRestoreManager() {
        if (restoreWireGuard != null) {
            try { restoreWireGuard.shutdown(); } catch (Exception ignored) {}
            restoreWireGuard = null;
        }
    }

    private void stopSelfSafely() {
        stopping = true;
        handler.removeCallbacksAndMessages(null);
        shutdownRestoreManager();
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "INFIN8 USA Network",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the user-enabled WireGuard tunnel connected");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    private Notification notification(String title, String text) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(
                this, 11, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(com.infin8.browser.R.drawable.ic_vpn_small)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateNotification(String title, String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, notification(title, text));
    }
}
