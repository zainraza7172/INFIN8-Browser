package com.infin8.browser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Lightweight persistent counters for resources blocked by INFIN8's built-in host blocker. */
public final class PrivacyStats {
    private static final String PREFS = "infin8_privacy_stats";
    private static final String KEY_TOTAL = "blocked_total";
    private static final String KEY_TODAY = "blocked_today";
    private static final String KEY_DAY = "blocked_day";
    private static final String KEY_HOSTS = "blocked_hosts_json";
    private static final Object LOCK = new Object();

    private static long pendingTotal;
    private static long pendingToday;
    private static long lastFlushAt;
    private static final Map<String, Long> pendingHosts = new HashMap<>();

    private PrivacyStats() {}

    public static void recordBlocked(Context context, String host) {
        if (context == null) return;
        String cleanHost = host == null ? "unknown" : host.trim().toLowerCase(Locale.US);
        if (cleanHost.isEmpty()) cleanHost = "unknown";
        synchronized (LOCK) {
            pendingTotal++;
            pendingToday++;
            pendingHosts.put(cleanHost, pendingHosts.getOrDefault(cleanHost, 0L) + 1L);
            long now = System.currentTimeMillis();
            if (pendingTotal >= 20L || now - lastFlushAt >= 2000L) {
                flushLocked(context.getApplicationContext());
            }
        }
    }

    public static Snapshot snapshot(Context context) {
        if (context == null) return new Snapshot(0, 0, todayKey(), Collections.emptyList());
        synchronized (LOCK) {
            flushLocked(context.getApplicationContext());
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String today = todayKey();
            String storedDay = p.getString(KEY_DAY, today);
            long todayCount = today.equals(storedDay) ? p.getLong(KEY_TODAY, 0L) : 0L;
            long total = p.getLong(KEY_TOTAL, 0L);
            List<HostCount> hosts = parseHosts(p.getString(KEY_HOSTS, "{}"));
            return new Snapshot(total, todayCount, today, hosts);
        }
    }

    public static void clear(Context context) {
        if (context == null) return;
        synchronized (LOCK) {
            pendingTotal = 0L;
            pendingToday = 0L;
            pendingHosts.clear();
            lastFlushAt = System.currentTimeMillis();
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
        }
    }

    private static void flushLocked(Context context) {
        if (pendingTotal == 0L && pendingToday == 0L && pendingHosts.isEmpty()) return;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = todayKey();
        String storedDay = p.getString(KEY_DAY, today);
        long baseToday = today.equals(storedDay) ? p.getLong(KEY_TODAY, 0L) : 0L;
        long total = p.getLong(KEY_TOTAL, 0L) + pendingTotal;
        long todayCount = baseToday + pendingToday;

        JSONObject hosts = new JSONObject();
        try {
            hosts = new JSONObject(p.getString(KEY_HOSTS, "{}"));
            for (Map.Entry<String, Long> e : pendingHosts.entrySet()) {
                hosts.put(e.getKey(), hosts.optLong(e.getKey(), 0L) + e.getValue());
            }
            // Cap persisted host keys to the top 40 so stats cannot grow without bound.
            List<HostCount> sorted = parseHosts(hosts.toString());
            JSONObject capped = new JSONObject();
            int max = Math.min(40, sorted.size());
            for (int i = 0; i < max; i++) capped.put(sorted.get(i).host, sorted.get(i).count);
            hosts = capped;
        } catch (Exception ignored) {}

        p.edit()
                .putLong(KEY_TOTAL, total)
                .putLong(KEY_TODAY, todayCount)
                .putString(KEY_DAY, today)
                .putString(KEY_HOSTS, hosts.toString())
                .apply();

        pendingTotal = 0L;
        pendingToday = 0L;
        pendingHosts.clear();
        lastFlushAt = System.currentTimeMillis();
    }

    private static List<HostCount> parseHosts(String raw) {
        List<HostCount> out = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(raw == null ? "{}" : raw);
            java.util.Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String host = keys.next();
                out.add(new HostCount(host, obj.optLong(host, 0L)));
            }
        } catch (Exception ignored) {}
        out.sort((a, b) -> Long.compare(b.count, a.count));
        return out;
    }

    private static String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    public static final class Snapshot {
        public final long totalBlocked;
        public final long todayBlocked;
        public final String day;
        public final List<HostCount> topHosts;
        Snapshot(long totalBlocked, long todayBlocked, String day, List<HostCount> topHosts) {
            this.totalBlocked = totalBlocked;
            this.todayBlocked = todayBlocked;
            this.day = day;
            this.topHosts = topHosts;
        }
    }

    public static final class HostCount {
        public final String host;
        public final long count;
        HostCount(String host, long count) { this.host = host; this.count = count; }
    }
}
