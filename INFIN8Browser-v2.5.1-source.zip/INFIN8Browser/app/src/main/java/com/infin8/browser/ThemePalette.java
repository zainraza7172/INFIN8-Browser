package com.infin8.browser;

import android.content.Context;
import android.content.SharedPreferences;

final class ThemePalette {
    static final String PREFS = "infin8_browser_data";
    static final String KEY_THEME_MODE = "theme_mode";
    static final String KEY_ACCENT = "accent_color";
    static final String KEY_INCOGNITO_SECURE = "incognito_secure_screen";

    private ThemePalette() {}

    static int background(Context context) {
        return isAmoled(context) ? 0xFF000000 : 0xFF05080D;
    }

    static int surface(Context context) {
        return isAmoled(context) ? 0xFF07090D : 0xFF0B0F16;
    }

    static int panel(Context context) {
        return isAmoled(context) ? 0xFF070B11 : 0xFF08111D;
    }

    static int accent(Context context) {
        String value = prefs(context).getString(KEY_ACCENT, "blue");
        if ("purple".equals(value)) return 0xFF8B7CFF;
        if ("green".equals(value)) return 0xFF35C98B;
        if ("orange".equals(value)) return 0xFFFF9B55;
        if ("cyan".equals(value)) return 0xFF45C7FF;
        return 0xFF58A6FF;
    }

    static int accentStrong(Context context) {
        String value = prefs(context).getString(KEY_ACCENT, "blue");
        if ("purple".equals(value)) return 0xFF6D5FEF;
        if ("green".equals(value)) return 0xFF149E67;
        if ("orange".equals(value)) return 0xFFDF7331;
        if ("cyan".equals(value)) return 0xFF1599D4;
        return 0xFF0967E8;
    }

    static boolean isAmoled(Context context) {
        return "amoled".equals(prefs(context).getString(KEY_THEME_MODE, "dark"));
    }

    static String themeName(Context context) {
        return isAmoled(context) ? "AMOLED Black" : "Dark";
    }

    static String accentName(Context context) {
        String value = prefs(context).getString(KEY_ACCENT, "blue");
        if ("purple".equals(value)) return "Purple";
        if ("green".equals(value)) return "Green";
        if ("orange".equals(value)) return "Orange";
        if ("cyan".equals(value)) return "Cyan";
        return "Blue";
    }

    static String signature(Context context) {
        SharedPreferences p = prefs(context);
        return p.getString(KEY_THEME_MODE, "dark") + ":" + p.getString(KEY_ACCENT, "blue");
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
