package com.infin8.browser;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fast, fail-closed USA exit verifier.
 *
 * Cloudflare's edge geolocation is checked first because it is normally the fastest
 * and tends to reflect the actual network exit more quickly than stale third-party
 * IP databases. If Cloudflare cannot give a US answer, independent fallbacks are
 * consulted before browsing is rejected.
 */
final class UsaNetworkVerifier {
    interface Callback {
        void onResult(Result result);
    }

    static final class Result {
        final boolean verifiedUsa;
        final String ip;
        final String location;
        final int usVotes;
        final int nonUsVotes;
        final int successfulChecks;
        final String detail;

        Result(boolean verifiedUsa, String ip, String location, int usVotes, int nonUsVotes,
               int successfulChecks, String detail) {
            this.verifiedUsa = verifiedUsa;
            this.ip = ip == null ? "" : ip;
            this.location = location == null ? "" : location;
            this.usVotes = usVotes;
            this.nonUsVotes = nonUsVotes;
            this.successfulChecks = successfulChecks;
            this.detail = detail == null ? "" : detail;
        }
    }

    private static final int CONNECT_TIMEOUT_MS = 4500;
    private static final int READ_TIMEOUT_MS = 4500;
    private static final String USER_AGENT = "INFIN8-Browser/1.2.1 USA-Exit-Check";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    void verify(Callback callback) {
        executor.execute(() -> callback.onResult(runChecks()));
    }

    /** Synchronous variant for background services that must fail closed before network transfer. */
    Result verifyBlocking() {
        return runChecks();
    }

    void shutdown() {
        executor.shutdownNow();
    }

    private Result runChecks() {
        List<Check> checks = new ArrayList<>();

        // 1) Fast primary check. A US result from Cloudflare is enough to open the gate.
        try {
            Check cloudflare = checkCloudflare();
            checks.add(cloudflare);
            if ("US".equalsIgnoreCase(cloudflare.countryCode)) {
                return new Result(
                        true,
                        cloudflare.ip,
                        cloudflare.location.isEmpty() ? "United States" : cloudflare.location,
                        1,
                        0,
                        1,
                        "US exit confirmed by Cloudflare network location"
                );
            }
        } catch (Exception ignored) {}

        // 2) Independent fallbacks. Some geolocation databases may be stale,
        // so a majority among reachable fallback services is accepted.
        addSafely(checks, 0);
        addSafely(checks, 1);
        addSafely(checks, 2);

        int usVotes = 0;
        int nonUsVotes = 0;
        String ip = "";
        String location = "";

        for (Check check : checks) {
            if (check == null || check.countryCode.isEmpty()) continue;
            if ("US".equalsIgnoreCase(check.countryCode)) usVotes++;
            else nonUsVotes++;
            if (ip.isEmpty() && !check.ip.isEmpty()) ip = check.ip;
            if (location.isEmpty() && !check.location.isEmpty()) location = check.location;
        }

        int successful = usVotes + nonUsVotes;
        boolean verified = usVotes >= 2 || (successful == 1 && usVotes == 1);

        String detail;
        if (verified) {
            detail = "US exit confirmed by " + usVotes + " of " + successful + " available checks";
        } else if (successful == 0) {
            detail = "USA verification services are temporarily unreachable";
        } else if (usVotes > 0) {
            detail = "IP databases disagree about this exit; browsing remains blocked";
        } else {
            detail = "Exit country is not verified as United States";
        }

        return new Result(verified, ip, location, usVotes, nonUsVotes, successful, detail);
    }

    private void addSafely(List<Check> checks, int provider) {
        try {
            Check check;
            if (provider == 0) check = checkIpInfo();
            else if (provider == 1) check = checkCountryIs();
            else check = checkIpWhoIs();
            if (check != null) checks.add(check);
        } catch (Exception ignored) {}
    }

    private Check checkCloudflare() throws Exception {
        String body = get("https://www.cloudflare.com/cdn-cgi/trace");
        String ip = "";
        String country = "";
        for (String line : body.split("\\n")) {
            int equals = line.indexOf('=');
            if (equals <= 0) continue;
            String key = line.substring(0, equals).trim();
            String value = line.substring(equals + 1).trim();
            if ("ip".equals(key)) ip = value;
            if ("loc".equals(key)) country = value.toUpperCase(Locale.US);
        }
        return new Check(country, ip, "US".equals(country) ? "United States" : country);
    }

    private Check checkIpInfo() throws Exception {
        JSONObject json = new JSONObject(get("https://ipinfo.io/json"));
        String country = json.optString("country", "").toUpperCase(Locale.US);
        String ip = json.optString("ip", "");
        String city = json.optString("city", "");
        String region = json.optString("region", "");
        return new Check(country, ip, joinLocation(city, region, "US".equals(country) ? "United States" : country));
    }

    private Check checkCountryIs() throws Exception {
        JSONObject json = new JSONObject(get("https://api.country.is/"));
        String country = json.optString("country", "").toUpperCase(Locale.US);
        String ip = json.optString("ip", "");
        return new Check(country, ip, "US".equals(country) ? "United States" : country);
    }

    private Check checkIpWhoIs() throws Exception {
        JSONObject json = new JSONObject(get("https://ipwho.is/"));
        if (!json.optBoolean("success", true)) {
            throw new IllegalStateException("IP geolocation service returned an error");
        }
        String country = json.optString("country_code", "").toUpperCase(Locale.US);
        String ip = json.optString("ip", "");
        String city = json.optString("city", "");
        String region = json.optString("region", "");
        String location = joinLocation(city, region, json.optString("country", ""));
        return new Check(country, ip, location);
    }

    private static String joinLocation(String... parts) {
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part == null || part.trim().isEmpty()) continue;
            if (out.length() > 0) out.append(", ");
            out.append(part.trim());
        }
        return out.toString();
    }

    private static String get(String urlString) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/json,text/plain,*/*");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setUseCaches(false);

        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300
                ? connection.getInputStream()
                : connection.getErrorStream();
        if (stream == null) throw new IllegalStateException("HTTP " + code);

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line).append('\n');
                if (body.length() > 128 * 1024) break;
            }
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
            return body.toString();
        } finally {
            connection.disconnect();
        }
    }

    private static final class Check {
        final String countryCode;
        final String ip;
        final String location;

        Check(String countryCode, String ip, String location) {
            this.countryCode = countryCode == null ? "" : countryCode;
            this.ip = ip == null ? "" : ip;
            this.location = location == null ? "" : location;
        }
    }
}
