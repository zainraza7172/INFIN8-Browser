package com.infin8.browser;

import android.content.Context;
import android.content.Intent;
import android.net.VpnService;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Embedded WireGuard controller for INFIN8 Browser.
 *
 * The imported profile is intentionally limited to this browser package by injecting
 * IncludedApplications into the [Interface] section before handing the configuration to
 * WireGuard's official Android tunnel backend.
 */
final class WireGuardManager {
    interface Listener {
        void onStateChanged(Tunnel.State state);
        void onError(String message, Throwable error);
    }

    private static final String TUNNEL_NAME = "infin8_us";
    private static final Pattern SERVER_COMMENT = Pattern.compile("(?m)^\\s*#\\s*([^\\r\\n]*US[^\\r\\n]*)$");
    private static final Pattern ENDPOINT = Pattern.compile("(?mi)^\\s*Endpoint\\s*=\\s*([^\\r\\n]+)$");

    private final Context context;
    private final Listener listener;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final GoBackend backend;
    private volatile Tunnel.State state = Tunnel.State.DOWN;

    private final Tunnel tunnel = new Tunnel() {
        @Override
        public String getName() {
            return TUNNEL_NAME;
        }

        @Override
        public void onStateChange(State newState) {
            state = newState;
            dispatchState(newState);
        }
    };

    WireGuardManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.backend = new GoBackend(this.context);
    }

    Intent getVpnPermissionIntent() {
        return VpnService.prepare(context);
    }

    boolean hasConfig() {
        return SecureConfigStore.hasConfig(context);
    }

    Tunnel.State getState() {
        return state;
    }

    boolean isConnected() {
        return state == Tunnel.State.UP;
    }

    void importConfig(String rawConfig) throws Exception {
        validateConfig(rawConfig);
        // Parse once now so malformed profiles fail before being stored.
        parseBrowserOnlyConfig(rawConfig);
        SecureConfigStore.save(context, rawConfig.trim() + "\n");
    }

    void clearConfig() {
        disconnect();
        SecureConfigStore.clear(context);
    }

    String getServerLabel() {
        try {
            String raw = SecureConfigStore.load(context);
            Matcher comment = SERVER_COMMENT.matcher(raw);
            if (comment.find()) return comment.group(1).trim();
            Matcher endpoint = ENDPOINT.matcher(raw);
            if (endpoint.find()) return endpoint.group(1).trim();
        } catch (Exception ignored) {}
        return hasConfig() ? "Imported WireGuard profile" : "No profile imported";
    }

    void refreshState() {
        executor.execute(() -> {
            try {
                Tunnel.State current = backend.getState(tunnel);
                state = current;
                dispatchState(current);
            } catch (Throwable error) {
                // A fresh backend can report DOWN if no tunnel currently exists; do not treat that as fatal.
                state = Tunnel.State.DOWN;
                dispatchState(Tunnel.State.DOWN);
            }
        });
    }

    void connect() {
        executor.execute(() -> {
            try {
                String raw = SecureConfigStore.load(context);
                if (raw.isEmpty()) throw new IllegalStateException("No WireGuard profile imported");
                Config config = parseBrowserOnlyConfig(raw);
                Tunnel.State newState = backend.setState(tunnel, Tunnel.State.UP, config);
                state = newState;
            } catch (Throwable error) {
                state = Tunnel.State.DOWN;
                dispatchState(Tunnel.State.DOWN);
                dispatchError("WireGuard connection failed", error);
            }
        });
    }

    void disconnect() {
        executor.execute(() -> {
            try {
                Tunnel.State newState = backend.setState(tunnel, Tunnel.State.DOWN, null);
                state = newState;
            } catch (Throwable error) {
                dispatchError("Could not disconnect WireGuard", error);
            }
        });
    }

    void shutdown() {
        executor.shutdown();
    }

    private Config parseBrowserOnlyConfig(String rawConfig) throws Exception {
        String normalized = rawConfig.replace("\r\n", "\n").replace('\r', '\n');
        // Never trust app-routing directives from an imported file. Force this tunnel to INFIN8 only.
        normalized = normalized.replaceAll("(?mi)^\\s*(IncludedApplications|ExcludedApplications)\\s*=.*(?:\\n|$)", "");
        String lower = normalized.toLowerCase(Locale.ENGLISH);
        int interfacePos = lower.indexOf("[interface]");
        if (interfacePos < 0) throw new IllegalArgumentException("Missing [Interface] section");
        int insertAt = normalized.indexOf('\n', interfacePos);
        if (insertAt < 0) throw new IllegalArgumentException("Invalid [Interface] section");
        normalized = normalized.substring(0, insertAt + 1)
                + "IncludedApplications = " + context.getPackageName() + "\n"
                + normalized.substring(insertAt + 1);
        try (ByteArrayInputStream input = new ByteArrayInputStream(normalized.getBytes(StandardCharsets.UTF_8))) {
            return Config.parse(input);
        }
    }

    private static void validateConfig(String rawConfig) {
        if (rawConfig == null || rawConfig.trim().isEmpty()) {
            throw new IllegalArgumentException("The selected file is empty");
        }
        String lower = rawConfig.toLowerCase(Locale.ENGLISH);
        if (!lower.contains("[interface]") || !lower.contains("[peer]")) {
            throw new IllegalArgumentException("Not a WireGuard .conf file");
        }
        if (!lower.contains("privatekey") || !lower.contains("endpoint") || !lower.contains("allowedips")) {
            throw new IllegalArgumentException("WireGuard profile is missing required fields");
        }
    }

    private void dispatchState(Tunnel.State newState) {
        if (listener != null) listener.onStateChanged(newState);
    }

    private void dispatchError(String message, Throwable error) {
        if (listener != null) listener.onError(message, error);
    }
}
