package com.infin8.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.Locale;

public final class PrivacyDashboardActivity extends Activity {
    private SharedPreferences browserPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        browserPrefs = getSharedPreferences("infin8_browser_data", MODE_PRIVATE);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        rebuild();
    }

    @Override
    protected void onResume() {
        super.onResume();
        rebuild();
    }

    private void rebuild() {
        PrivacyStats.Snapshot stats = PrivacyStats.snapshot(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(38));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 36, Color.WHITE, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xFF0D1826, 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(dp(14), 0, 0, 0);
        header.addView(titles, tp);
        titles.addView(text("Privacy Dashboard", 27, Color.WHITE, Typeface.BOLD));
        titles.addView(text("Protection activity inside INFIN8", 12, 0xFF7F91AA, Typeface.NORMAL));
        root.addView(header);

        section(root, "BLOCKING STATS");
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.addView(statCard("Today", format(stats.todayBlocked), "blocked requests"), new LinearLayout.LayoutParams(0, dp(120), 1f));
        LinearLayout.LayoutParams second = new LinearLayout.LayoutParams(0, dp(120), 1f);
        second.setMargins(dp(10), 0, 0, 0);
        statsRow.addView(statCard("All time", format(stats.totalBlocked), "blocked requests"), second);
        root.addView(statsRow);

        section(root, "ACTIVE PROTECTIONS");
        boolean adblock = browserPrefs.getBoolean("adblock_enabled", true);
        boolean thirdParty = browserPrefs.getBoolean("third_party_cookies", true);
        root.addView(infoCard("Ad & tracker protection", adblock ? "ON" : "OFF", adblock ? "Known ad/tracker hosts are blocked before their resources load." : "Global host blocking is currently disabled."));
        root.addView(infoCard("Third-party cookies", thirdParty ? "ALLOWED" : "BLOCKED", thirdParty ? "Global default allows third-party cookies; site overrides may differ." : "Global default blocks third-party cookies; site overrides may differ."));
        root.addView(infoCard("Network privacy", "ACTIVE", "WebRTC shield, geolocation blocking, mixed-content blocking and the USA fail-closed gate remain active in normal browsing."));
        root.addView(infoCard("Site overrides", String.valueOf(siteOverrideCount()), "Websites with custom ad-block or third-party-cookie rules."));

        section(root, "TOP BLOCKED DOMAINS");
        if (stats.topHosts.isEmpty()) {
            root.addView(infoCard("No tracker activity yet", "—", "Browse with Ad & Tracker Protection enabled and blocked requests will appear here."));
        } else {
            int max = Math.min(10, stats.topHosts.size());
            for (int i = 0; i < max; i++) {
                PrivacyStats.HostCount h = stats.topHosts.get(i);
                root.addView(infoCard(h.host, format(h.count), "blocked resource requests"));
            }
        }

        section(root, "DATA");
        TextView clear = actionCard("Reset privacy statistics", "Clears counters only. Your privacy settings stay unchanged.");
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Reset privacy statistics?")
                .setMessage("Blocked-request counters and top-domain statistics will be cleared.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> {
                    PrivacyStats.clear(this);
                    Toast.makeText(this, "Privacy statistics reset", Toast.LENGTH_SHORT).show();
                    rebuild();
                }).show());
        root.addView(clear);

        TextView note = text("Counters track resources blocked by INFIN8's built-in host blocker. They do not claim to count every tracker on the internet, and WebView does not expose a reliable per-cookie blocked-event counter.", 11, 0xFF718198, Typeface.NORMAL);
        note.setPadding(dp(4), dp(14), dp(4), 0);
        root.addView(note);

        setContentView(scroll);
    }

    private int siteOverrideCount() {
        try { return new JSONObject(browserPrefs.getString("site_privacy_json", "{}")).length(); }
        catch (Exception ignored) { return 0; }
    }

    private LinearLayout statCard(String label, String value, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(ThemePalette.surface(this), 20, ThemePalette.accent(this), 1));
        card.addView(text(label, 12, 0xFF8EA0B8, Typeface.BOLD));
        card.addView(text(value, 27, Color.WHITE, Typeface.BOLD));
        card.addView(text(detail, 11, ThemePalette.accent(this), Typeface.NORMAL));
        return card;
    }

    private LinearLayout infoCard(String title, String value, String summary) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        card.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMargins(0, 0, 0, dp(8));
        card.setLayoutParams(cp);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(title, 15, 0xFFF2F6FC, Typeface.BOLD);
        t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(t);
        top.addView(text(value, 13, ThemePalette.accent(this), Typeface.BOLD));
        card.addView(top);
        TextView s = text(summary, 12, 0xFF8190A5, Typeface.NORMAL);
        s.setPadding(0, dp(5), 0, 0);
        card.addView(s);
        return card;
    }

    private TextView actionCard(String title, String summary) {
        TextView v = text(title + "\n" + summary, 15, 0xFFF2F6FC, Typeface.BOLD);
        v.setLineSpacing(0f, 1.12f);
        v.setPadding(dp(16), dp(14), dp(16), dp(14));
        v.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
        return v;
    }

    private void section(LinearLayout root, String title) {
        TextView t = text(title, 11, ThemePalette.accent(this), Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(24), 0, dp(9));
        root.addView(t, lp);
    }

    private String format(long v) { return NumberFormat.getIntegerInstance(Locale.US).format(v); }
    private TextView text(String s, int size, int color, int style) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT, style); return t; }
    private GradientDrawable round(int color, int radius, int strokeColor, int stroke) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if (stroke > 0) g.setStroke(dp(stroke), strokeColor); return g; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
