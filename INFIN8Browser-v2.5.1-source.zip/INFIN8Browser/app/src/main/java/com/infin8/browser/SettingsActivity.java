package com.infin8.browser;

import android.app.Activity;
import android.app.Dialog;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

public class SettingsActivity extends Activity {
    public static final String PREFS = "infin8_browser_data";
    public static final String KEY_SEARCH_ENGINE = "search_engine";
    public static final String KEY_ADBLOCK_ENABLED = "adblock_enabled";
    public static final String KEY_THIRD_PARTY_COOKIES = "third_party_cookies";
    public static final String KEY_ALLOW_POPUPS = "allow_popups";
    public static final String KEY_DEFAULT_DESKTOP = "default_desktop_mode";
    public static final String KEY_HISTORY = "history_json";
    public static final String KEY_SITE_PERMISSION_MODE = "site_permission_mode";
    public static final String KEY_SITE_PRIVACY = "site_privacy_json";
    public static final String KEY_SYSTEM_AUTOFILL = "system_autofill";
    public static final String KEY_KEEP_BROWSER_ACTIVE = "keep_browser_active_background";
    public static final String KEY_SMART_MEMORY_SAVER = "smart_memory_saver";
    public static final String KEY_ASK_EXTERNAL_APPS = "ask_before_external_apps";

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(0);
        }
        rebuild();
    }

    private void rebuild() {
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 36, 0xFFEAF2FF, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xFF0D1826, 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tcp.setMargins(dp(14), 0, 0, 0);
        titleCol.setLayoutParams(tcp);
        TextView title = text("Settings", 28, Color.WHITE, Typeface.BOLD);
        TextView sub = text("INFIN8 Browser • Multi-Profile Edition", 12, 0xFF7F91AA, Typeface.NORMAL);
        titleCol.addView(title);
        titleCol.addView(sub);
        header.addView(titleCol);
        root.addView(header);

        section(root, "SEARCH");
        root.addView(row("Search engine", engineName(getSearchEngine()), "Choose the engine used by the address bar and homepage.", v -> showSearchEnginePicker()));

        section(root, "PRIVACY & SECURITY");
        root.addView(toggleRow(
                "Ad & tracker protection",
                prefs.getBoolean(KEY_ADBLOCK_ENABLED, true),
                "Blocks a built-in list of common advertising and tracking hosts.",
                KEY_ADBLOCK_ENABLED));
        root.addView(toggleRow(
                "Third-party cookies",
                prefs.getBoolean(KEY_THIRD_PARTY_COOKIES, true),
                "Turn off for stronger cross-site privacy. Some sign-ins or embedded services may need it.",
                KEY_THIRD_PARTY_COOKIES));
        root.addView(row("Camera & microphone", permissionModeName(), "Ask per site or block all capture requests. Saved site choices can be reviewed separately.", v -> showPermissionModePicker()));
        root.addView(actionRow("Site permissions", "Review or reset saved camera/microphone decisions by website.", v -> startActivity(new Intent(this, SitePermissionsActivity.class))));
        root.addView(actionRow("Site privacy overrides", sitePrivacySummary(), v -> confirmClearSitePrivacy()));
        root.addView(actionRow("Privacy dashboard", "See blocked-request totals, top blocked domains and active protection status.", v -> startActivity(new Intent(this, PrivacyDashboardActivity.class))));
        root.addView(actionRow("Security Center", "Review WebView hardening, Safe Browsing support, WebView provider, WireGuard config status and copy a non-sensitive diagnostic report.", v -> startActivity(new Intent(this, SecurityCenterActivity.class))));
        root.addView(toggleRow(
                "Ask before opening external apps",
                prefs.getBoolean(KEY_ASK_EXTERNAL_APPS, true),
                "Shows a confirmation before websites can hand links to phone, messaging, maps, market or other external apps.",
                KEY_ASK_EXTERNAL_APPS));
        root.addView(actionRow("New incognito window", "Opens an isolated private WebView profile in a separate process. History, cookies and storage are cleared between sessions.", v -> openIncognito()));
        root.addView(toggleRow(
                "Block screenshots in Incognito",
                prefs.getBoolean(ThemePalette.KEY_INCOGNITO_SECURE, true),
                "Uses Android secure-window protection for private windows.",
                ThemePalette.KEY_INCOGNITO_SECURE));
        root.addView(actionRow("Clear cookies & site data", "Signs you out of websites and clears WebView storage.", v -> confirmClearSiteData()));
        root.addView(actionRow("Clear browsing history", "Bookmarks are kept.", v -> confirmClearHistory()));
        root.addView(actionRow("Clear cache", "Removes cached webpage files without deleting bookmarks.", v -> clearCache()));

        section(root, "APPEARANCE");
        root.addView(row("Theme", ThemePalette.themeName(this), "Choose standard dark or pure-black AMOLED mode.", v -> showThemePicker()));
        root.addView(row("Accent color", ThemePalette.accentName(this), "Changes the primary INFIN8 highlight color.", v -> showAccentPicker()));

        section(root, "PERFORMANCE & BACKGROUND");
        root.addView(toggleRow(
                "Keep browser active in background",
                prefs.getBoolean(KEY_KEEP_BROWSER_ACTIVE, true),
                "Keeps the current tab and INFIN8 process at foreground-service priority when you minimize with Home/Recents. Force-stop or severe Android memory pressure can still stop it.",
                KEY_KEEP_BROWSER_ACTIVE));
        root.addView(toggleRow(
                "Smart memory saver",
                prefs.getBoolean(KEY_SMART_MEMORY_SAVER, true),
                "Keeps the current tab high priority while letting inactive tab renderers become reclaimable under memory pressure.",
                KEY_SMART_MEMORY_SAVER));
        root.addView(actionRow(
                "Android battery settings",
                "For maximum background reliability, you can set INFIN8 battery usage to Unrestricted on supported phones.",
                v -> openBatterySettings()));

        section(root, "BROWSING");
        root.addView(actionRow("Browser profiles", "Create isolated account profiles with separate cookies, storage, history, tabs, browser identity, locale/time-zone preferences and an optional active-profile proxy.", v -> startActivity(new Intent(this, ProfileManagerActivity.class))));
        root.addView(toggleRow(
                "Android Autofill & passwords",
                prefs.getBoolean(KEY_SYSTEM_AUTOFILL, true),
                "Lets your Android Autofill provider fill and save sign-ins inside WebView. INFIN8 does not keep a separate plaintext password database.",
                KEY_SYSTEM_AUTOFILL));
        root.addView(toggleRow(
                "Allow pop-ups & new windows",
                prefs.getBoolean(KEY_ALLOW_POPUPS, false),
                "When enabled, target=_blank and JavaScript windows can open as a new INFIN8 tab.",
                KEY_ALLOW_POPUPS));
        root.addView(toggleRow(
                "Desktop mode for new tabs",
                prefs.getBoolean(KEY_DEFAULT_DESKTOP, false),
                "New tabs use the desktop browser user-agent by default.",
                KEY_DEFAULT_DESKTOP));
        root.addView(actionRow("Set INFIN8 as default browser", defaultBrowserSummary(), v -> requestDefaultBrowser()));
        root.addView(actionRow("USA Network / VPN", "Open WireGuard profile and USA verification controls.", v -> openVpnSettings()));
        root.addView(actionRow("Downloads", "Open Download Manager Pro.", v -> startActivity(new Intent(this, DownloadsActivity.class))));

        section(root, "BACKUP & RECOVERY");
        root.addView(actionRow("Backup & Restore", "Export or restore bookmarks, history, tabs, tab groups, site rules and browser settings. WireGuard secrets are excluded.", v -> startActivity(new Intent(this, BackupRestoreActivity.class))));

        section(root, "ABOUT");
        root.addView(actionRow("Release Center", "View installed build/signing details, run a fail-closed manual update check, and copy a non-sensitive release report.", v -> startActivity(new Intent(this, ReleaseCenterActivity.class))));
        root.addView(infoRow("INFIN8 Browser", "v2.5 • Isolated multi-profile browsing\nProvided by Jin Baba"));
        root.addView(infoRow("Security model", "WebRTC shielding, geolocation blocked, USA verification gate, mixed-content blocking, Safe Browsing where supported, fail-closed SSL handling, hardened local-home loading and user-controlled WireGuard remain enabled."));

        return scroll;
    }

    private String sitePrivacySummary() {
        try {
            JSONObject root = new JSONObject(prefs.getString(KEY_SITE_PRIVACY, "{}"));
            int count = root.length();
            return count == 0 ? "No custom website privacy rules." : count + (count == 1 ? " website has" : " websites have") + " custom ad/cookie rules. Tap to reset all.";
        } catch (Exception ignored) {
            return "No custom website privacy rules.";
        }
    }

    private void confirmClearSitePrivacy() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Reset site privacy overrides?")
                .setMessage("Per-site ad blocker and third-party cookie choices will return to global defaults.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset", (d, w) -> {
                    prefs.edit().remove(KEY_SITE_PRIVACY).apply();
                    toast("Site privacy overrides cleared");
                    rebuild();
                }).show();
    }

    private View toggleRow(String title, boolean enabled, String summary, String key) {
        String value = enabled ? "ON" : "OFF";
        LinearLayout row = row(title, value, summary, v -> {
            boolean next = !prefs.getBoolean(key, enabled);
            prefs.edit().putBoolean(key, next).apply();
            if (KEY_KEEP_BROWSER_ACTIVE.equals(key)) setBackgroundBrowserMode(next);
            rebuild();
        });
        return row;
    }

    private View actionRow(String title, String summary, View.OnClickListener click) {
        return row(title, "›", summary, click);
    }

    private View infoRow(String title, String summary) {
        return row(title, "", summary, null);
    }

    private LinearLayout row(String titleText, String valueText, String summaryText, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(9));
        card.setLayoutParams(lp);
        if (click != null) card.setOnClickListener(click);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text(titleText, 16, 0xFFF2F6FC, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView value = text(valueText, 13, ThemePalette.accent(this), Typeface.BOLD);
        value.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        top.addView(title);
        top.addView(value, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(top);

        if (summaryText != null && !summaryText.trim().isEmpty()) {
            TextView summary = text(summaryText, 12, 0xFF8190A5, Typeface.NORMAL);
            summary.setPadding(0, dp(6), 0, 0);
            card.addView(summary);
        }
        return card;
    }

    private void section(LinearLayout root, String title) {
        TextView t = text(title, 11, ThemePalette.accent(this), Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(24), 0, dp(9));
        t.setLayoutParams(lp);
        root.addView(t);
    }

    private void showSearchEnginePicker() {
        final String[] ids = {"google", "startpage", "duckduckgo", "bing", "brave"};
        final String[] names = {"Google", "Startpage", "DuckDuckGo", "Bing", "Brave Search"};
        String current = getSearchEngine();

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));
        card.addView(text("Search engine", 23, Color.WHITE, Typeface.BOLD));
        TextView note = text("Used for typed searches on the homepage and address bar.", 12, 0xFF8190A5, Typeface.NORMAL);
        note.setPadding(0, dp(5), 0, dp(12));
        card.addView(note);

        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            TextView item = text((ids[i].equals(current) ? "✓  " : "     ") + names[i], 16,
                    ids[i].equals(current) ? 0xFF67B1FF : 0xFFEAF2FF,
                    ids[i].equals(current) ? Typeface.BOLD : Typeface.NORMAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(14), 0, dp(14), 0);
            item.setBackground(round(0xFF0D1A2A, 16, 0xFF1A3555, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            lp.setMargins(0, i == 0 ? 0 : dp(7), 0, 0);
            item.setLayoutParams(lp);
            item.setOnClickListener(v -> {
                prefs.edit().putString(KEY_SEARCH_ENGINE, ids[index]).apply();
                dialog.dismiss();
                rebuild();
            });
            card.addView(item);
        }

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private String getSearchEngine() {
        String id = prefs.getString(KEY_SEARCH_ENGINE, "google");
        if (id == null) return "google";
        switch (id) {
            case "startpage":
            case "duckduckgo":
            case "bing":
            case "brave":
            case "google":
                return id;
            default:
                return "google";
        }
    }

    private String engineName(String id) {
        switch (id) {
            case "startpage": return "Startpage";
            case "duckduckgo": return "DuckDuckGo";
            case "bing": return "Bing";
            case "brave": return "Brave Search";
            default: return "Google";
        }
    }

    private String permissionModeName() {
        return "block".equals(prefs.getString(KEY_SITE_PERMISSION_MODE, "ask")) ? "Block all" : "Ask";
    }

    private void showPermissionModePicker() {
        showSimplePicker(
                "Camera & microphone",
                new String[]{"ask", "block"},
                new String[]{"Ask per site", "Block all"},
                prefs.getString(KEY_SITE_PERMISSION_MODE, "ask"),
                value -> prefs.edit().putString(KEY_SITE_PERMISSION_MODE, value).apply());
    }

    private void showThemePicker() {
        showSimplePicker(
                "Theme",
                new String[]{"dark", "amoled"},
                new String[]{"Dark", "AMOLED Black"},
                prefs.getString(ThemePalette.KEY_THEME_MODE, "dark"),
                value -> {
                    prefs.edit().putString(ThemePalette.KEY_THEME_MODE, value).apply();
                    getWindow().setStatusBarColor(ThemePalette.background(this));
                    getWindow().setNavigationBarColor(ThemePalette.background(this));
                });
    }

    private void showAccentPicker() {
        showSimplePicker(
                "Accent color",
                new String[]{"blue", "cyan", "purple", "green", "orange"},
                new String[]{"Blue", "Cyan", "Purple", "Green", "Orange"},
                prefs.getString(ThemePalette.KEY_ACCENT, "blue"),
                value -> prefs.edit().putString(ThemePalette.KEY_ACCENT, value).apply());
    }

    private interface PickerSaver { void save(String value); }

    private void showSimplePicker(String titleText, String[] ids, String[] labels, String current, PickerSaver saver) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));
        card.addView(text(titleText, 22, Color.WHITE, Typeface.BOLD));
        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            boolean selected = ids[i].equals(current);
            TextView item = text((selected ? "✓  " : "     ") + labels[i], 16,
                    selected ? ThemePalette.accent(this) : 0xFFEAF2FF,
                    selected ? Typeface.BOLD : Typeface.NORMAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(14), 0, dp(14), 0);
            item.setBackground(round(0xFF0D1A2A, 16, 0xFF1A3555, 1));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            lp.setMargins(0, dp(7), 0, 0);
            item.setLayoutParams(lp);
            item.setOnClickListener(v -> {
                saver.save(ids[index]);
                dialog.dismiss();
                rebuild();
            });
            card.addView(item);
        }
        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void openIncognito() {
        try {
            Intent intent = new Intent(this, IncognitoActivity.class);
            intent.putExtra("search_engine", getSearchEngine());
            intent.putExtra("theme_mode", prefs.getString(ThemePalette.KEY_THEME_MODE, "dark"));
            intent.putExtra("accent_color", prefs.getString(ThemePalette.KEY_ACCENT, "blue"));
            intent.putExtra("secure_screen", prefs.getBoolean(ThemePalette.KEY_INCOGNITO_SECURE, true));
            intent.putExtra("ask_external_apps", prefs.getBoolean(KEY_ASK_EXTERNAL_APPS, true));
            startActivity(intent);
        } catch (Exception e) {
            toast("Could not open Incognito");
        }
    }

    private void confirmClearHistory() {
        showConfirm(
                "Clear browsing history?",
                "Visited-page history will be deleted. Bookmarks and tabs stay intact.",
                () -> {
                    prefs.edit().putString(BrowserProfiles.scopedKey(this, KEY_HISTORY), "[]").apply();
                    toast("Browsing history cleared");
                });
    }

    private void confirmClearSiteData() {
        showConfirm(
                "Clear cookies & site data?",
                "You will be signed out of websites. Homepage shortcuts stored as site data may also be removed.",
                () -> {
                    try {
                        BrowserProfiles.ProfileData profile = BrowserProfiles.active(this);
                        if (!profile.isDefault() && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                            Profile p = ProfileStore.getInstance().getProfile(profile.webViewProfileName());
                            if (p != null) {
                                p.getCookieManager().removeAllCookies(null);
                                p.getCookieManager().flush();
                                p.getWebStorage().deleteAllData();
                            }
                        } else {
                            CookieManager.getInstance().removeAllCookies(null);
                            CookieManager.getInstance().flush();
                            WebStorage.getInstance().deleteAllData();
                        }
                    } catch (Exception ignored) {}
                    toast("Active profile cookies and site data cleared");
                });
    }

    private void clearCache() {
        try {
            WebView temp = new WebView(this);
            BrowserProfiles.ProfileData profile = BrowserProfiles.active(this);
            if (!profile.isDefault() && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                WebViewCompat.setProfile(temp, profile.webViewProfileName());
            }
            temp.clearCache(true);
            temp.destroy();
            toast("Active profile cache cleared");
        } catch (Exception e) {
            toast("Could not clear cache");
        }
    }

    private void showConfirm(String title, String message, Runnable action) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(18));
        card.setBackground(round(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));
        card.addView(text(title, 21, Color.WHITE, Typeface.BOLD));
        TextView msg = text(message, 13, 0xFF92A1B6, Typeface.NORMAL);
        msg.setPadding(0, dp(8), 0, dp(18));
        card.addView(msg);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setGravity(Gravity.END);
        TextView cancel = text("Cancel", 14, 0xFFDCE7F6, Typeface.BOLD);
        cancel.setGravity(Gravity.CENTER);
        cancel.setBackground(round(0xFF102033, 18, 0xFF1C3857, 1));
        TextView clear = text("Clear", 14, 0xFFFFB0B0, Typeface.BOLD);
        clear.setGravity(Gravity.CENTER);
        clear.setBackground(round(0xFF35151C, 18, 0xFF6E2934, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());
        clear.setOnClickListener(v -> {
            dialog.dismiss();
            action.run();
        });
        buttons.addView(cancel, new LinearLayout.LayoutParams(dp(96), dp(44)));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(96), dp(44));
        clp.setMargins(dp(8), 0, 0, 0);
        buttons.addView(clear, clp);
        card.addView(buttons);
        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private void setBackgroundBrowserMode(boolean enabled) {
        Intent intent = new Intent(this, BrowserKeepAliveService.class)
                .setAction(enabled ? BrowserKeepAliveService.ACTION_START : BrowserKeepAliveService.ACTION_STOP);
        try {
            if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
            else startService(intent);
        } catch (Exception e) {
            if (!enabled) {
                try { stopService(new Intent(this, BrowserKeepAliveService.class)); } catch (Exception ignored) {}
            }
        }
    }

    private void openBatterySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            toast("Open Battery and choose Unrestricted if your phone offers it");
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                toast("Battery settings are unavailable on this device");
            }
        }
    }

    private void openVpnSettings() {
        try {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("open_usa_settings", true);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Exception e) {
            toast("Could not open USA Network settings");
        }
    }

    private String defaultBrowserSummary() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                RoleManager roleManager = getSystemService(RoleManager.class);
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_BROWSER)
                        && roleManager.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                    return "Currently the default browser.";
                }
            } catch (Exception ignored) {}
        }
        return "Choose INFIN8 for web links from other apps.";
    }

    private void requestDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                RoleManager roleManager = getSystemService(RoleManager.class);
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_BROWSER)) {
                    if (roleManager.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                        toast("INFIN8 is already your default browser");
                    } else {
                        startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_BROWSER), 2001);
                    }
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        } catch (Exception e) {
            try {
                Intent app = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()));
                startActivity(app);
            } catch (Exception ignored) {
                toast("Default app settings are unavailable on this device");
            }
        }
    }

    private TextView text(String value, int size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}
