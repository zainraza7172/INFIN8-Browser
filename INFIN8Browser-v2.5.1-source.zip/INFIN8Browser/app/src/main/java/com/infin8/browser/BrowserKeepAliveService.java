package com.infin8.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;

/**
 * User-controlled foreground lifetime service for active background browsing.
 *
 * This service deliberately does not poll WebView, VPN or network state. Its job is only
 * to keep the INFIN8 process at foreground-service priority while the user has explicitly
 * enabled "Keep browser active in background". MainActivity keeps its current WebView alive
 * when the app is minimized with Home/Recents, and Android remains free to reclaim the app
 * under critical resource pressure or after force-stop.
 */
public final class BrowserKeepAliveService extends Service {
    public static final String ACTION_START = "com.infin8.browser.background.START";
    public static final String ACTION_STOP = "com.infin8.browser.background.STOP";
    public static final String PREFS = "infin8_browser_data";
    public static final String KEY_KEEP_BROWSER_ACTIVE = "keep_browser_active_background";

    private static final String CHANNEL_ID = "infin8_background_browser";
    private static final int NOTIFICATION_ID = 8020;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_KEEP_BROWSER_ACTIVE, false).apply();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!isEnabled()) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, notification());
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Do not terminate background mode just because the task card disappeared.
        // Android may still reclaim the process later; force-stop always wins.
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private boolean isEnabled() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEY_KEEP_BROWSER_ACTIVE, true);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "INFIN8 Background Browser",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the current INFIN8 tab active while the browser is minimized");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(channel);
        }
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(
                this, 21, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, BrowserKeepAliveService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 22, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.ic_home)
                .setContentTitle("INFIN8 Browser active")
                .setContentText("Current tab stays active while INFIN8 is minimized")
                .setContentIntent(content)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_media_pause,
                        "Stop background mode",
                        stopPending).build())
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }
}
