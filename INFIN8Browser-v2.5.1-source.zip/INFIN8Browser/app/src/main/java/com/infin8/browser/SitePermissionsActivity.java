package com.infin8.browser;

import android.app.Activity;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SitePermissionsActivity extends Activity {
    static final String PREFS = "infin8_browser_data";
    static final String KEY_SITE_PERMISSIONS = "site_permissions_json";

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        applySystemTheme();
        rebuild();
    }

    private void applySystemTheme() {
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
    }

    private void rebuild() {
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 36, 0xFFEAF2FF, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(ThemePalette.surface(this), 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(dp(14), 0, 0, 0);
        titles.setLayoutParams(titleLp);
        titles.addView(text("Site permissions", 27, Color.WHITE, Typeface.BOLD));
        titles.addView(text("Camera & microphone decisions", 12, 0xFF7F91AA, Typeface.NORMAL));
        header.addView(titles);
        root.addView(header);

        TextView note = text("INFIN8 only stores camera/microphone choices for sites you explicitly approve or block. Geolocation stays blocked.", 12, 0xFF91A1B7, Typeface.NORMAL);
        note.setPadding(dp(4), dp(18), dp(4), dp(18));
        root.addView(note);

        List<String> origins = loadOrigins();
        if (origins.isEmpty()) {
            TextView empty = text("No saved site permissions yet.", 15, 0xFF8190A5, Typeface.NORMAL);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(42), 0, dp(42));
            root.addView(empty);
        } else {
            for (String origin : origins) {
                String decision = getDecision(origin);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(16), dp(14), dp(16), dp(14));
                card.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
                LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cardLp.setMargins(0, 0, 0, dp(9));
                card.setLayoutParams(cardLp);

                LinearLayout top = new LinearLayout(this);
                top.setGravity(Gravity.CENTER_VERTICAL);
                TextView host = text(origin, 14, 0xFFF2F6FC, Typeface.BOLD);
                host.setSingleLine(true);
                host.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                TextView state = text("allow".equals(decision) ? "ALLOW" : "BLOCK", 12,
                        "allow".equals(decision) ? 0xFF64D89B : 0xFFFF8E9C, Typeface.BOLD);
                top.addView(host);
                top.addView(state);
                card.addView(top);

                TextView action = text("Tap to change or reset", 12, 0xFF7F91AA, Typeface.NORMAL);
                action.setPadding(0, dp(5), 0, 0);
                card.addView(action);
                card.setOnClickListener(v -> showDecisionDialog(origin));
                root.addView(card);
            }

            TextView reset = text("Reset all site permissions", 14, 0xFFFFA2AD, Typeface.BOLD);
            reset.setGravity(Gravity.CENTER);
            reset.setBackground(round(0xFF30151B, 18, 0xFF6E2934, 1));
            reset.setOnClickListener(v -> {
                prefs.edit().putString(KEY_SITE_PERMISSIONS, "{}").apply();
                toast("Site permissions reset");
                rebuild();
            });
            root.addView(reset, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
        }
        return scroll;
    }

    private void showDecisionDialog(String origin) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(ThemePalette.panel(this), 24, ThemePalette.accent(this), 1));
        card.addView(text(origin, 18, Color.WHITE, Typeface.BOLD));
        TextView note = text("Choose the saved camera/microphone behavior for this site.", 12, 0xFF8798AF, Typeface.NORMAL);
        note.setPadding(0, dp(6), 0, dp(12));
        card.addView(note);

        TextView allow = choice("Always allow", 0xFF64D89B);
        TextView block = choice("Always block", 0xFFFF8E9C);
        TextView ask = choice("Reset to ask every time", 0xFFEAF2FF);
        allow.setOnClickListener(v -> { setDecision(origin, "allow"); dialog.dismiss(); rebuild(); });
        block.setOnClickListener(v -> { setDecision(origin, "block"); dialog.dismiss(); rebuild(); });
        ask.setOnClickListener(v -> { setDecision(origin, ""); dialog.dismiss(); rebuild(); });
        card.addView(allow);
        card.addView(block);
        card.addView(ask);

        dialog.setContentView(card);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(28), dp(470));
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    private TextView choice(String label, int color) {
        TextView item = text(label, 15, color, Typeface.BOLD);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(14), 0, dp(14), 0);
        item.setBackground(round(0xFF0D1A2A, 16, 0xFF1A3555, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.setMargins(0, dp(7), 0, 0);
        item.setLayoutParams(lp);
        return item;
    }

    private List<String> loadOrigins() {
        List<String> out = new ArrayList<>();
        try {
            JSONObject json = new JSONObject(prefs.getString(KEY_SITE_PERMISSIONS, "{}"));
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) out.add(keys.next());
        } catch (Exception ignored) {}
        Collections.sort(out);
        return out;
    }

    private String getDecision(String origin) {
        try {
            JSONObject json = new JSONObject(prefs.getString(KEY_SITE_PERMISSIONS, "{}"));
            return json.optString(origin, "");
        } catch (Exception ignored) {
            return "";
        }
    }

    private void setDecision(String origin, String decision) {
        try {
            JSONObject json = new JSONObject(prefs.getString(KEY_SITE_PERMISSIONS, "{}"));
            if (decision == null || decision.isEmpty()) json.remove(origin);
            else json.put(origin, decision);
            prefs.edit().putString(KEY_SITE_PERMISSIONS, json.toString()).apply();
        } catch (Exception ignored) {}
    }

    private TextView text(String value, int size, int color, int style) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, style);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }
}
