package com.infin8.browser;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Browser profile metadata for INFIN8 multi-account workspaces.
 * Web data isolation itself is provided by AndroidX WebKit MULTI_PROFILE.
 */
public final class BrowserProfiles {
    public static final String PREFS = "infin8_browser_data";
    public static final String KEY_PROFILES = "browser_profiles_v25";
    public static final String KEY_ACTIVE = "active_browser_profile_v25";
    public static final String DEFAULT_ID = "default";

    private BrowserProfiles() {}

    public interface ProxyCheckCallback {
        void onResult(boolean usa, String detail, String ip);
    }

    public static final class ProfileData {
        public String id = DEFAULT_ID;
        public String name = "Personal";
        public String uaMode = "android"; // android | desktop | custom
        public String customUa = "";
        public String language = "en-US";
        public String timezone = "system";
        public String region = "US";
        public String proxyUrl = "";
        public long createdAt = System.currentTimeMillis();
        public long lastUsedAt = System.currentTimeMillis();

        public JSONObject toJson() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id);
                o.put("name", name);
                o.put("uaMode", uaMode);
                o.put("customUa", customUa);
                o.put("language", language);
                o.put("timezone", timezone);
                o.put("region", region);
                o.put("proxyUrl", proxyUrl);
                o.put("createdAt", createdAt);
                o.put("lastUsedAt", lastUsedAt);
            } catch (Exception ignored) {}
            return o;
        }

        static ProfileData fromJson(JSONObject o) {
            ProfileData p = new ProfileData();
            if (o == null) return p;
            p.id = cleanId(o.optString("id", DEFAULT_ID));
            p.name = cleanName(o.optString("name", "Profile"));
            p.uaMode = normalizeUaMode(o.optString("uaMode", "android"));
            p.customUa = o.optString("customUa", "");
            p.language = normalizeLanguage(o.optString("language", "en-US"));
            p.timezone = normalizeTimezone(o.optString("timezone", "system"));
            p.region = normalizeRegion(o.optString("region", "US"));
            p.proxyUrl = normalizeProxy(o.optString("proxyUrl", ""));
            p.createdAt = o.optLong("createdAt", System.currentTimeMillis());
            p.lastUsedAt = o.optLong("lastUsedAt", p.createdAt);
            return p;
        }

        public String webViewProfileName() {
            return "infin8_" + cleanId(id);
        }

        public boolean isDefault() { return DEFAULT_ID.equals(id); }
        public boolean hasProxy() { return proxyUrl != null && !proxyUrl.trim().isEmpty(); }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean multiProfileSupported() {
        return WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
    }

    public static synchronized List<ProfileData> all(Context c) {
        List<ProfileData> out = new ArrayList<>();
        try {
            String raw = prefs(c).getString(KEY_PROFILES, "[]");
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) out.add(ProfileData.fromJson(o));
            }
        } catch (Exception ignored) {}
        boolean hasDefault = false;
        for (ProfileData p : out) if (DEFAULT_ID.equals(p.id)) { hasDefault = true; break; }
        if (!hasDefault) {
            ProfileData d = new ProfileData();
            d.id = DEFAULT_ID;
            d.name = "Personal";
            out.add(0, d);
            saveAll(c, out);
        }
        return out;
    }

    private static synchronized void saveAll(Context c, List<ProfileData> list) {
        JSONArray a = new JSONArray();
        for (ProfileData p : list) a.put(p.toJson());
        prefs(c).edit().putString(KEY_PROFILES, a.toString()).apply();
    }

    public static ProfileData active(Context c) {
        return get(c, activeId(c));
    }

    public static String activeId(Context c) {
        String id = cleanId(prefs(c).getString(KEY_ACTIVE, DEFAULT_ID));
        return get(c, id).id;
    }

    public static void setActive(Context c, String id) {
        ProfileData p = get(c, id);
        p.lastUsedAt = System.currentTimeMillis();
        upsert(c, p);
        prefs(c).edit().putString(KEY_ACTIVE, p.id).apply();
    }

    public static ProfileData get(Context c, String id) {
        String target = cleanId(id);
        for (ProfileData p : all(c)) if (p.id.equals(target)) return p;
        for (ProfileData p : all(c)) if (p.id.equals(DEFAULT_ID)) return p;
        ProfileData d = new ProfileData();
        upsert(c, d);
        return d;
    }

    public static ProfileData create(Context c, String name) {
        if (!multiProfileSupported()) throw new IllegalStateException("This Android WebView does not support isolated multi-profile browsing.");
        ProfileData p = new ProfileData();
        p.id = "p_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        p.name = cleanName(name);
        p.createdAt = System.currentTimeMillis();
        p.lastUsedAt = p.createdAt;
        upsert(c, p);
        return p;
    }

    public static ProfileData duplicateSettings(Context c, String sourceId, String newName) {
        if (!multiProfileSupported()) throw new IllegalStateException("This Android WebView does not support isolated multi-profile browsing.");
        ProfileData s = get(c, sourceId);
        ProfileData p = new ProfileData();
        p.id = "p_" + UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        p.name = cleanName(newName);
        p.uaMode = s.uaMode;
        p.customUa = s.customUa;
        p.language = s.language;
        p.timezone = s.timezone;
        p.region = s.region;
        p.proxyUrl = s.proxyUrl;
        p.createdAt = System.currentTimeMillis();
        p.lastUsedAt = p.createdAt;
        upsert(c, p);
        return p;
    }

    public static synchronized void upsert(Context c, ProfileData value) {
        value.id = cleanId(value.id);
        value.name = cleanName(value.name);
        value.uaMode = normalizeUaMode(value.uaMode);
        value.language = normalizeLanguage(value.language);
        value.timezone = normalizeTimezone(value.timezone);
        value.region = normalizeRegion(value.region);
        value.proxyUrl = normalizeProxy(value.proxyUrl);
        List<ProfileData> list = all(c);
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(value.id)) { list.set(i, value); found = true; break; }
        }
        if (!found) list.add(value);
        saveAll(c, list);
    }

    public static synchronized boolean deleteMetadata(Context c, String id) {
        String target = cleanId(id);
        if (DEFAULT_ID.equals(target)) return false;
        List<ProfileData> list = all(c);
        boolean removed = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).id.equals(target)) { list.remove(i); removed = true; }
        }
        if (removed) {
            String rawActive = prefs(c).getString(KEY_ACTIVE, DEFAULT_ID);
            saveAll(c, list);
            if (target.equals(rawActive)) prefs(c).edit().putString(KEY_ACTIVE, DEFAULT_ID).apply();
        }
        return removed;
    }

    public static String scopedKey(Context c, String baseKey) {
        String id = activeId(c);
        return DEFAULT_ID.equals(id) ? baseKey : baseKey + "__profile__" + id;
    }

    public static String profileSummary(ProfileData p) {
        String proxy = p.hasProxy() ? "Proxy" : "VPN";
        return p.language + " • " + ("system".equals(p.timezone) ? "System time zone" : p.timezone) + " • " + p.region + " • " + proxy;
    }

    public static String normalizeProxy(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.isEmpty()) return "";
        if (!s.contains("://")) s = "http://" + s;
        try {
            URI u = URI.create(s);
            String scheme = u.getScheme() == null ? "http" : u.getScheme().toLowerCase(Locale.ENGLISH);
            if ("socks5".equals(scheme)) scheme = "socks";
            if (!("http".equals(scheme) || "https".equals(scheme) || "socks".equals(scheme))) return "";
            if (u.getUserInfo() != null && !u.getUserInfo().isEmpty()) return ""; // credentials intentionally not stored in plaintext
            String host = u.getHost();
            if (host == null || host.trim().isEmpty()) return "";
            int port = u.getPort();
            if (port < 0) port = "https".equals(scheme) ? 443 : "socks".equals(scheme) ? 1080 : 80;
            return scheme + "://" + host + ":" + port;
        } catch (Exception e) {
            return "";
        }
    }

    public static String environmentScript(ProfileData p) {
        String lang = js(p.language);
        String region = js(p.region);
        String tz = js(p.timezone);
        StringBuilder s = new StringBuilder();
        s.append("(()=>{try{");
        s.append("const L='").append(lang).append("';const R='").append(region).append("';");
        s.append("try{Object.defineProperty(Navigator.prototype,'language',{get:()=>L,configurable:true});Object.defineProperty(Navigator.prototype,'languages',{get:()=>[L,L.split('-')[0]],configurable:true});}catch(e){}");
        s.append("try{Object.defineProperty(Navigator.prototype,'userLanguage',{get:()=>L,configurable:true});}catch(e){}");
        s.append("try{Object.defineProperty(Navigator.prototype,'country',{get:()=>R,configurable:true});}catch(e){}");
        if (!"system".equals(p.timezone)) {
            s.append("const TZ='").append(tz).append("';const RO=Intl.DateTimeFormat.prototype.resolvedOptions;Intl.DateTimeFormat.prototype.resolvedOptions=function(){const o=RO.call(this);try{Object.defineProperty(o,'timeZone',{value:TZ,configurable:true});}catch(e){}return o;};");
        }
        s.append("}catch(e){}})();");
        return s.toString();
    }

    private static String js(String s) {
        return (s == null ? "" : s).replace("\\", "\\\\").replace("'", "\\'").replace("\n", "");
    }

    public static void verifyProxyUs(ProfileData p, ProxyCheckCallback callback) {
        if (p == null || !p.hasProxy()) {
            callback.onResult(true, "No profile proxy", "");
            return;
        }
        new Thread(() -> {
            String ip = "";
            try {
                URI u = URI.create(p.proxyUrl);
                String scheme = u.getScheme() == null ? "http" : u.getScheme().toLowerCase(Locale.ENGLISH);
                Proxy.Type type = "socks".equals(scheme) ? Proxy.Type.SOCKS : Proxy.Type.HTTP;
                Proxy proxy = new Proxy(type, new InetSocketAddress(u.getHost(), u.getPort()));
                URLConnection conn = new URL("https://www.cloudflare.com/cdn-cgi/trace").openConnection(proxy);
                conn.setConnectTimeout(4500);
                conn.setReadTimeout(4500);
                conn.setRequestProperty("User-Agent", "INFIN8-Browser/2.5");
                String loc = "";
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if (line.startsWith("loc=")) loc = line.substring(4).trim();
                        else if (line.startsWith("ip=")) ip = line.substring(3).trim();
                    }
                }
                boolean usa = "US".equalsIgnoreCase(loc);
                callback.onResult(usa, usa ? "Profile proxy verified in USA" : "Profile proxy is not a USA exit", ip);
            } catch (Exception e) {
                callback.onResult(false, "Could not verify profile proxy through USA gate", ip);
            }
        }, "INFIN8-Proxy-US-Check").start();
    }

    private static String cleanId(String s) {
        if (s == null || s.trim().isEmpty()) return DEFAULT_ID;
        String v = s.trim().replaceAll("[^A-Za-z0-9_-]", "_");
        return v.isEmpty() ? DEFAULT_ID : v;
    }

    private static String cleanName(String s) {
        String v = s == null ? "Profile" : s.trim();
        if (v.isEmpty()) v = "Profile";
        return v.length() > 40 ? v.substring(0, 40) : v;
    }

    private static String normalizeUaMode(String s) {
        if ("desktop".equalsIgnoreCase(s)) return "desktop";
        if ("custom".equalsIgnoreCase(s)) return "custom";
        return "android";
    }

    private static String normalizeLanguage(String s) {
        if (s == null || s.trim().isEmpty()) return "en-US";
        return s.trim().replace('_', '-');
    }

    private static String normalizeTimezone(String s) {
        if (s == null || s.trim().isEmpty()) return "system";
        return s.trim();
    }

    private static String normalizeRegion(String s) {
        if (s == null || s.trim().isEmpty()) return "US";
        String r = s.trim().toUpperCase(Locale.ENGLISH);
        return r.length() > 3 ? r.substring(0, 3) : r;
    }
}
