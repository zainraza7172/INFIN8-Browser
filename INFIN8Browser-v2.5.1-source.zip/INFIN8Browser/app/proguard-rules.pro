# INFIN8 Browser v2.4
# Release shrinking is intentionally disabled for the Phase 4D release-candidate pass.
# Keep this file ready for future R8 rules once signed-device regression testing is complete.
