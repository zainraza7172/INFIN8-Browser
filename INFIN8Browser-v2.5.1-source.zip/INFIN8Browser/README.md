# INFIN8 Browser v2.3

Android browser prototype with embedded WireGuard USA routing and a fail-closed verification gate.

## v0.5 UI cleanup
- Minimal top toolbar: INFIN8 logo, search/address bar, overflow menu only
- Overflow menu contains Back, Forward, Reload, Home, New Tab, Tabs, USA network and IP check
- Each top tab has a visible × close button
- Android system Back now prioritizes WebView history; if no history exists on a website it returns to the INFIN8 home page instead of immediately exiting
- Android 13+ modern back callback registered for gesture/back-button reliability
- Removed the USA MODE badge from the new-tab page
- Increased INFIN8 Browser branding size
- Speed Dial is now 100% user-custom; no preloaded social shortcuts
- Removed the USA Security Gate promotional card from the homepage

## Network security retained
- Embedded WireGuard tunnel backend
- Imported .conf encrypted locally with Android Keystore
- Tunnel scoped to the INFIN8 app package
- Automatic US-exit verification with independent checks
- Fail-closed WebView proxy gate when USA exit is not verified
- WebRTC shield and geolocation disabled

The Proton WireGuard private key is intentionally NOT bundled in source. Import the profile on-device.


### Downloads Pro (v1.7)
INFIN8 includes an in-app HTTP/HTTPS download engine with resumable range downloads, Auto/1/4/8/16/32 parts, speed limits, Wi-Fi-only waiting, retry recovery, categories, live speed/ETA, notifications, page link grabbing, and safe Open/Share/Delete actions. Phase 2B adds public clear HLS/M3U8 and static DASH handling, user scheduling, queue reordering, and a 1–3 parallel-job control. HLS MPEG-TS is remuxed to MP4 when Android supports the codecs; unsupported streams fall back to TS. Encrypted HLS and DASH manifests that declare content protection are refused. Live/dynamic DASH, torrent/magnet support, and DRM bypass are intentionally not implemented.


### Browser Pro (v1.8 / Phase 3A)
INFIN8 now includes a native dark Settings center with selectable Google, Startpage, DuckDuckGo, Bing or Brave Search; third-party-cookie control; stronger built-in ad/tracker host blocking; optional pop-ups/new-window tabs; default Desktop Mode for new tabs; Find in Page; Copy/Share page tools; Android default-browser role support; clear-history/cookie/site-data/cache controls; and quick access to USA Network/VPN and Downloads Pro. The existing fail-closed USA verification gate, WebRTC shield, geolocation blocking, WireGuard behavior and Phase 2 downloader remain intact.

Phase 3B added isolated Incognito browsing and richer site permissions in a separate WebView profile/process.


## v1.9.0 — Phase 3B
INFIN8 Browser now includes an isolated Incognito process/profile, camera & microphone site-permission management, AMOLED/accent customization, recently closed tab recovery, and tab duplication. Private windows do not write the normal browser history/session and clear their private WebView data between sessions.


## v2.0.0 — Phase 3C
INFIN8 Browser adds a grouped tab switcher with persistent tab groups, per-site privacy overrides for ad blocking and third-party cookies, Android Autofill integration for normal WebView tabs, searchable Downloads Pro history/queue, and a live local device clock/date under INFIN8 LIMITED on the home screen. Incognito keeps Autofill disabled and remains isolated.


### Phase 4A — Background & Stability
INFIN8 v2.1 adds an opt-in/opt-out foreground background-browsing lifetime service (enabled by default), selected-tab renderer priority, Smart Memory Saver for inactive tabs, lazy restored-tab loading, periodic session checkpoints, and WebView renderer crash recovery. Background continuity is best-effort within Android rules: Home/Recents minimization is supported, while force-stop and critical OS memory reclamation cannot be bypassed.


### Phase 4B / v2.2
INFIN8 now includes a Privacy Dashboard, local JSON browser-state backup/restore, actionable download notifications, and a foreground-notification reliability fix. Backups do not contain cookies, passwords, Incognito data, or WireGuard secrets.


### Phase 4C / v2.3 — Security Hardening & UI Finish
INFIN8 v2.3 moves the local new-tab page away from `file://` and serves it through AndroidX WebViewAssetLoader on the trusted `appassets.androidplatform.net` origin, then disables normal WebView file/content access. Existing homepage shortcuts are migrated once from the legacy local-file origin when possible. Normal and Incognito WebViews keep mixed-content blocking, explicitly cancel SSL certificate errors, and request Android WebView Safe Browsing on supported Android versions. External-app hand-offs are restricted to supported schemes and can require user confirmation before leaving the browser.

A new Security Center shows non-sensitive runtime hardening status, app/WebView versions, background-mode state, Android camera/microphone permission state, and whether a WireGuard profile is present. Its copyable diagnostics deliberately exclude browsing history, open URLs, cookies, passwords, IP addresses, Incognito data, and WireGuard private keys.

Tab UI finishing adds long-press actions from the tab strip and grouped tab switcher: duplicate, move to group, copy link, close other tabs, or close the selected tab. Phase 4A background browsing, Smart Memory Saver, crash recovery, Phase 4B privacy/backup features, the USA fail-closed gate, and WireGuard behavior remain preserved.

Production signing/AAB optimization is intentionally left for the next release phase rather than being mixed into the security hardening update.

## Phase 4D — Production release & update readiness (v2.4)

Phase 4D adds a Release Center so installed builds can expose their version code/name, debug-vs-release state, installer source and signing-certificate SHA-256 fingerprint without exposing private browser data. A manual update checker can query the official GitHub Releases feed, but it first requires the same USA fail-closed network verification used elsewhere in INFIN8 and never runs as a periodic background poller.

The GitHub Actions workflow now produces the normal installable debug APK for testing plus a release APK, release AAB and SHA-256 checksums. Production signing is optional and secret-driven: `INFIN8_RELEASE_KEYSTORE_BASE64`, `INFIN8_RELEASE_KEYSTORE_PASSWORD`, `INFIN8_RELEASE_KEY_ALIAS` and `INFIN8_RELEASE_KEY_PASSWORD`. When those secrets are not configured, release outputs remain unsigned rather than using the debug key. The production keystore/private key must never be committed to GitHub or added to the source ZIP.

Background browsing remains enabled by the existing user preference and foreground-service architecture. Phase 4D does not add polling that would wake the browser just to check for updates. Android Force Stop still terminates the app/services by platform design.


## v2.5 Multi-Profile Workspace
INFIN8 can create isolated WebView profiles on devices whose Android System WebView supports `WebViewFeature.MULTI_PROFILE`. The default Personal profile preserves existing browser data; additional profiles keep WebView session data separate and have their own INFIN8 history/bookmarks/tabs. Profile proxy routing is process-wide by Android WebView design, so INFIN8 allows only one active browser profile at a time and re-verifies a configured profile proxy through the USA fail-closed gate before opening internet browsing.
