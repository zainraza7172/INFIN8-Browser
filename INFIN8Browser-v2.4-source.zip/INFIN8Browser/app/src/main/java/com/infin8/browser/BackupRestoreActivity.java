package com.infin8.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public final class BackupRestoreActivity extends Activity {
    private static final int REQ_EXPORT = 4201;
    private static final int REQ_IMPORT = 4202;
    private static final String BROWSER_PREFS = "infin8_browser_data";
    private static final String DOWNLOAD_PREFS = "infin8_downloads";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 36, Color.WHITE, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xFF0D1826, 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(dp(14), 0, 0, 0);
        header.addView(titles, tp);
        titles.addView(text("Backup & Restore", 27, Color.WHITE, Typeface.BOLD));
        titles.addView(text("Portable INFIN8 browser state", 12, 0xFF7F91AA, Typeface.NORMAL));
        root.addView(header);

        section(root, "BACKUP");
        TextView export = action("Export backup", "Creates a JSON backup containing bookmarks, history, tabs/tab groups, site rules and browser settings.");
        export.setOnClickListener(v -> exportBackup());
        root.addView(export);

        TextView restore = action("Restore backup", "Choose an INFIN8 JSON backup. Matching browser state/settings are restored and the browser restarts.");
        restore.setOnClickListener(v -> chooseBackup());
        root.addView(restore);

        section(root, "INCLUDED");
        root.addView(info("Browser state", "Bookmarks, browsing history, open tabs, tab groups, recently closed tabs, appearance, search engine, site permissions/privacy rules and performance preferences."));
        root.addView(info("Download preferences", "Speed limit, Wi-Fi-only preference and maximum concurrent-download setting. Downloaded files and active queue items are not copied."));

        section(root, "NOT INCLUDED");
        root.addView(info("Sensitive credentials", "Cookies, website passwords/autofill vault data and Incognito data are not exported."));
        root.addView(info("WireGuard secrets", "Your imported WireGuard profile/private key is deliberately excluded from browser backups."));
        root.addView(info("Backup privacy", "The JSON file is not encrypted. It can contain browsing history and tab URLs, so keep it somewhere you trust."));

        return scroll;
    }

    private void exportBackup() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        i.putExtra(Intent.EXTRA_TITLE, "INFIN8_Backup_" + stamp + ".json");
        try { startActivityForResult(i, REQ_EXPORT); }
        catch (Exception e) { toast("File picker unavailable"); }
    }

    private void chooseBackup() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        try { startActivityForResult(i, REQ_IMPORT); }
        catch (Exception e) { toast("File picker unavailable"); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) writeBackup(uri);
        else if (requestCode == REQ_IMPORT) previewRestore(uri);
    }

    private void writeBackup(Uri uri) {
        try {
            JSONObject root = new JSONObject();
            root.put("format", "INFIN8_BROWSER_BACKUP");
            root.put("schema", 1);
            root.put("version", "2.3.0");
            root.put("createdAt", System.currentTimeMillis());
            root.put("browserPreferences", prefsToJson(getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).getAll()));

            SharedPreferences dl = getSharedPreferences(DOWNLOAD_PREFS, MODE_PRIVATE);
            JSONObject download = new JSONObject();
            download.put("speed_limit_kbps", dl.getLong("speed_limit_kbps", 0L));
            download.put("wifi_only", dl.getBoolean("wifi_only", false));
            download.put("max_concurrent", dl.getInt("max_concurrent", 2));
            root.put("downloadPreferences", download);

            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new IllegalStateException("Could not open file");
                out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
            toast("INFIN8 backup exported");
        } catch (Exception e) {
            toast("Backup failed: " + safeMessage(e));
        }
    }

    private void previewRestore(Uri uri) {
        try {
            String raw = readAll(uri);
            JSONObject backup = new JSONObject(raw);
            if (!"INFIN8_BROWSER_BACKUP".equals(backup.optString("format")) || backup.optInt("schema", 0) != 1) {
                toast("This is not a supported INFIN8 backup");
                return;
            }
            JSONObject browser = backup.optJSONObject("browserPreferences");
            if (browser == null) {
                toast("Backup is missing browser data");
                return;
            }
            long created = backup.optLong("createdAt", 0L);
            String when = created > 0L ? new SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.US).format(new Date(created)) : "Unknown date";
            new AlertDialog.Builder(this)
                    .setTitle("Restore INFIN8 backup?")
                    .setMessage("Backup: " + when + "\n\nThis replaces browser preferences/state contained in the backup. WireGuard keys, cookies and passwords are untouched.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Restore", (d, w) -> restoreBackup(backup))
                    .show();
        } catch (Exception e) {
            toast("Could not read backup: " + safeMessage(e));
        }
    }

    private void restoreBackup(JSONObject backup) {
        try {
            JSONObject browser = backup.getJSONObject("browserPreferences");
            SharedPreferences.Editor editor = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).edit().clear();
            java.util.Iterator<String> keys = browser.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject entry = browser.optJSONObject(key);
                if (entry != null) putTypedValue(editor, key, entry);
            }
            if (!editor.commit()) throw new IllegalStateException("Browser preferences were not saved");

            JSONObject download = backup.optJSONObject("downloadPreferences");
            if (download != null) {
                getSharedPreferences(DOWNLOAD_PREFS, MODE_PRIVATE).edit()
                        .putLong("speed_limit_kbps", download.optLong("speed_limit_kbps", 0L))
                        .putBoolean("wifi_only", download.optBoolean("wifi_only", false))
                        .putInt("max_concurrent", Math.max(1, Math.min(3, download.optInt("max_concurrent", 2))))
                        .apply();
            }
            syncBackgroundService();
            toast("Backup restored — restarting INFIN8");
            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(launch);
            }
            finishAffinity();
        } catch (Exception e) {
            toast("Restore failed: " + safeMessage(e));
        }
    }

    private JSONObject prefsToJson(Map<String, ?> all) throws Exception {
        JSONObject out = new JSONObject();
        for (Map.Entry<String, ?> e : all.entrySet()) {
            Object v = e.getValue();
            JSONObject item = new JSONObject();
            if (v instanceof String) { item.put("type", "string"); item.put("value", v); }
            else if (v instanceof Boolean) { item.put("type", "boolean"); item.put("value", v); }
            else if (v instanceof Integer) { item.put("type", "int"); item.put("value", v); }
            else if (v instanceof Long) { item.put("type", "long"); item.put("value", v); }
            else if (v instanceof Float) { item.put("type", "float"); item.put("value", ((Float) v).doubleValue()); }
            else continue;
            out.put(e.getKey(), item);
        }
        return out;
    }

    private void putTypedValue(SharedPreferences.Editor editor, String key, JSONObject entry) {
        String type = entry.optString("type", "string");
        switch (type) {
            case "boolean": editor.putBoolean(key, entry.optBoolean("value", false)); break;
            case "int": editor.putInt(key, entry.optInt("value", 0)); break;
            case "long": editor.putLong(key, entry.optLong("value", 0L)); break;
            case "float": editor.putFloat(key, (float) entry.optDouble("value", 0d)); break;
            default: editor.putString(key, entry.optString("value", "")); break;
        }
    }

    private String readAll(Uri uri) throws Exception {
        StringBuilder b = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (b.length() > 4_000_000) throw new IllegalArgumentException("Backup is too large");
                b.append(line).append('\n');
            }
        }
        return b.toString();
    }

    private void syncBackgroundService() {
        boolean enabled = getSharedPreferences(BROWSER_PREFS, MODE_PRIVATE).getBoolean("keep_browser_active_background", true);
        Intent service = new Intent(this, BrowserKeepAliveService.class)
                .setAction(enabled ? BrowserKeepAliveService.ACTION_START : BrowserKeepAliveService.ACTION_STOP);
        try {
            if (enabled && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
        } catch (Exception ignored) {}
    }

    private TextView action(String title, String summary) {
        TextView v = text(title + "\n" + summary, 15, 0xFFF2F6FC, Typeface.BOLD);
        v.setLineSpacing(0f, 1.13f);
        v.setPadding(dp(16), dp(15), dp(16), dp(15));
        v.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(9));
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout info(String title, String summary) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        card.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        card.setLayoutParams(lp);
        card.addView(text(title, 15, Color.WHITE, Typeface.BOLD));
        TextView s = text(summary, 12, 0xFF8190A5, Typeface.NORMAL);
        s.setPadding(0, dp(5), 0, 0);
        card.addView(s);
        return card;
    }

    private void section(LinearLayout root, String title) {
        TextView t = text(title, 11, ThemePalette.accent(this), Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(24), 0, dp(9));
        root.addView(t, lp);
    }

    private String safeMessage(Exception e) { String m = e.getMessage(); return m == null || m.trim().isEmpty() ? "unknown error" : m; }
    private TextView text(String s, int size, int color, int style) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT, style); return t; }
    private GradientDrawable round(int color, int radius, int strokeColor, int stroke) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if (stroke > 0) g.setStroke(dp(stroke), strokeColor); return g; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
