package com.infin8.browser;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

public class ReleaseCenterActivity extends Activity {
    private static final String RELEASES_URL = "https://github.com/zainraza7172/INFIN8-Browser/releases";
    private static final String LATEST_API = "https://api.github.com/repos/zainraza7172/INFIN8-Browser/releases/latest";

    private TextView updateStatus;
    private String latestReleaseUrl = RELEASES_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(ThemePalette.background(this));
        getWindow().setNavigationBarColor(ThemePalette.background(this));
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(ThemePalette.background(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(40));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹", 36, 0xFFEAF2FF, Typeface.NORMAL);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xFF0D1826, 22, 0xFF1D3654, 1));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tcp.setMargins(dp(14), 0, 0, 0);
        titleCol.setLayoutParams(tcp);
        titleCol.addView(text("Release Center", 28, Color.WHITE, Typeface.BOLD));
        titleCol.addView(text("Phase 4D • production readiness", 12, 0xFF7F91AA, Typeface.NORMAL));
        header.addView(titleCol);
        root.addView(header);

        section(root, "INSTALLED BUILD");
        root.addView(infoRow("Version", versionLabel()));
        root.addView(infoRow("Build mode", isDebuggable() ? "Debug / testing build" : "Release build"));
        root.addView(infoRow("Install source", installerSource()));
        root.addView(infoRow("Signing certificate SHA-256", signingCertificateSha256()));

        section(root, "UPDATE CHANNEL");
        updateStatus = infoRow("Update status", "Not checked yet. Update checks are manual and first require the same USA fail-closed verification used by the browser.");
        root.addView(updateStatus);
        root.addView(actionRow("Check for update", "Checks the latest published GitHub Release after USA exit verification. No automatic background update traffic is used.", v -> checkForUpdate()));
        root.addView(actionRow("Open release page", "Open the official INFIN8 Browser releases page inside INFIN8.", v -> openReleasePage()));

        section(root, "PRODUCTION SAFETY");
        root.addView(infoRow("Release signing", "Production signing is supported by the GitHub workflow through encrypted repository secrets. The keystore/private key is never stored in the source ZIP."));
        root.addView(infoRow("Release outputs", "The workflow builds a test APK plus release APK/AAB outputs. If production signing secrets are absent, release outputs remain unsigned instead of silently using the debug key."));
        root.addView(infoRow("Browser protections", "Cleartext traffic remains blocked, Android backup remains disabled, SSL errors fail closed, Safe Browsing is requested where supported, and WireGuard secrets stay outside source control."));

        section(root, "TOOLS");
        root.addView(actionRow("Copy release report", "Copies non-sensitive version/build/signing metadata. It excludes URLs, history, cookies, passwords, IP addresses and WireGuard secrets.", v -> copyReport()));
        root.addView(actionRow("Android app details", "Open system app-info settings for INFIN8 Browser.", v -> openAppDetails()));

        return scroll;
    }

    private void checkForUpdate() {
        setUpdateStatus("Checking USA exit before contacting the update server…");
        new Thread(() -> {
            UsaNetworkVerifier verifier = new UsaNetworkVerifier();
            try {
                UsaNetworkVerifier.Result usa = verifier.verifyBlocking();
                if (!usa.verifiedUsa) {
                    runOnUiThread(() -> setUpdateStatus("Update check blocked: USA exit is not verified. " + usa.detail));
                    return;
                }

                HttpURLConnection connection = (HttpURLConnection) new URL(LATEST_API).openConnection();
                connection.setConnectTimeout(6000);
                connection.setReadTimeout(6000);
                connection.setUseCaches(false);
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Accept", "application/vnd.github+json");
                connection.setRequestProperty("User-Agent", "INFIN8-Browser-Release-Center/2.4");

                int code = connection.getResponseCode();
                if (code == 404) {
                    connection.disconnect();
                    runOnUiThread(() -> setUpdateStatus("No published GitHub Release exists yet. Your installed build remains unchanged."));
                    return;
                }

                InputStream stream = code >= 200 && code < 300
                        ? connection.getInputStream()
                        : connection.getErrorStream();
                String body = readBody(stream);
                connection.disconnect();

                if (code < 200 || code >= 300) {
                    runOnUiThread(() -> setUpdateStatus("Update server returned HTTP " + code + ". Try again later."));
                    return;
                }

                JSONObject json = new JSONObject(body);
                String tag = json.optString("tag_name", "").trim();
                String page = json.optString("html_url", RELEASES_URL).trim();
                if (!page.isEmpty()) latestReleaseUrl = page;
                if (tag.isEmpty()) {
                    runOnUiThread(() -> setUpdateStatus("Latest release metadata did not contain a version tag."));
                    return;
                }

                String current = versionName();
                int compare = compareVersions(tag, current);
                if (compare > 0) {
                    runOnUiThread(() -> setUpdateStatus("Update available: " + tag + " • installed " + current));
                } else if (compare == 0) {
                    runOnUiThread(() -> setUpdateStatus("You are up to date: " + current));
                } else {
                    runOnUiThread(() -> setUpdateStatus("Installed build " + current + " is newer than published " + tag + "."));
                }
            } catch (Exception e) {
                runOnUiThread(() -> setUpdateStatus("Update check failed safely: " + safeMessage(e)));
            } finally {
                verifier.shutdown();
            }
        }, "INFIN8-UpdateCheck").start();
    }

    private static String readBody(InputStream stream) throws Exception {
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line).append('\n');
                if (out.length() > 256 * 1024) break;
            }
            return out.toString();
        }
    }

    private void openReleasePage() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(latestReleaseUrl), this, MainActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            toast("Could not open release page");
        }
    }

    private void openAppDetails() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            toast("Could not open app details");
        }
    }

    private void copyReport() {
        String report = "INFIN8 Browser Release Report\n"
                + "Version: " + versionLabel() + "\n"
                + "Build mode: " + (isDebuggable() ? "Debug" : "Release") + "\n"
                + "Install source: " + installerSource() + "\n"
                + "Signing SHA-256: " + signingCertificateSha256() + "\n"
                + "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n"
                + "Package: " + getPackageName() + "\n"
                + "Background browsing preference: "
                + (getSharedPreferences(SettingsActivity.PREFS, MODE_PRIVATE)
                .getBoolean(SettingsActivity.KEY_KEEP_BROWSER_ACTIVE, true) ? "ON" : "OFF") + "\n"
                + "WireGuard profile present: " + (SecureConfigStore.hasConfig(this) ? "YES" : "NO") + "\n";
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("INFIN8 release report", report));
            toast("Release report copied");
        }
    }

    private String versionLabel() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? pi.getLongVersionCode() : pi.versionCode;
            return pi.versionName + " (" + code + ")";
        } catch (Exception e) {
            return "Unknown";
        }
    }

    private String versionName() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pi.versionName == null ? "0" : pi.versionName;
        } catch (Exception e) {
            return "0";
        }
    }

    private boolean isDebuggable() {
        return (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

    private String installerSource() {
        try {
            String installer;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                installer = getPackageManager().getInstallSourceInfo(getPackageName()).getInstallingPackageName();
            } else {
                installer = getPackageManager().getInstallerPackageName(getPackageName());
            }
            return installer == null || installer.trim().isEmpty() ? "Sideload / local install" : installer;
        } catch (Exception e) {
            return "Unknown";
        }
    }

    private String signingCertificateSha256() {
        try {
            PackageInfo pi;
            Signature signature;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                if (pi.signingInfo == null) return "Unavailable";
                Signature[] signatures = pi.signingInfo.hasMultipleSigners()
                        ? pi.signingInfo.getApkContentsSigners()
                        : pi.signingInfo.getSigningCertificateHistory();
                if (signatures == null || signatures.length == 0) return "Unavailable";
                signature = signatures[0];
            } else {
                pi = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
                if (pi.signatures == null || pi.signatures.length == 0) return "Unavailable";
                signature = pi.signatures[0];
            }
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(signature.toByteArray());
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                if (i > 0) out.append(':');
                out.append(String.format("%02X", digest[i]));
            }
            return out.toString();
        } catch (Exception e) {
            return "Unavailable";
        }
    }

    private static int compareVersions(String a, String b) {
        List<Integer> left = versionNumbers(a);
        List<Integer> right = versionNumbers(b);
        int count = Math.max(left.size(), right.size());
        for (int i = 0; i < count; i++) {
            int l = i < left.size() ? left.get(i) : 0;
            int r = i < right.size() ? right.get(i) : 0;
            if (l != r) return Integer.compare(l, r);
        }
        return 0;
    }

    private static List<Integer> versionNumbers(String value) {
        List<Integer> out = new ArrayList<>();
        if (value == null) return out;
        String[] parts = value.replaceFirst("^[vV]", "").split("[^0-9]+");
        for (String part : parts) {
            if (part == null || part.isEmpty()) continue;
            try {
                out.add(Integer.parseInt(part));
            } catch (Exception ignored) {}
        }
        return out;
    }

    private void setUpdateStatus(String message) {
        if (updateStatus == null) return;
        updateStatus.setText(message);
    }

    private static String safeMessage(Exception e) {
        String message = e.getMessage();
        if (message == null || message.trim().isEmpty()) return e.getClass().getSimpleName();
        if (message.length() > 140) message = message.substring(0, 140);
        return message.replace('\n', ' ').replace('\r', ' ');
    }

    private TextView infoRow(String title, String summary) {
        TextView card = text(title + "\n" + summary, 14, 0xFFEAF2FF, Typeface.NORMAL);
        card.setLineSpacing(dp(2), 1f);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(ThemePalette.surface(this), 18, 0xFF1B2A3E, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(9));
        card.setLayoutParams(lp);
        return card;
    }

    private TextView actionRow(String title, String summary, View.OnClickListener click) {
        TextView card = infoRow(title + "  ›", summary);
        card.setOnClickListener(click);
        return card;
    }

    private void section(LinearLayout root, String title) {
        TextView t = text(title, 11, ThemePalette.accent(this), Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), dp(24), 0, dp(9));
        t.setLayoutParams(lp);
        root.addView(t);
    }

    private TextView text(String value, int sp, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setTypeface(Typeface.create("sans", style));
        return view;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
