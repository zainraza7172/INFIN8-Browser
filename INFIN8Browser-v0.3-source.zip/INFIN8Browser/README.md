# INFIN8 Browser v0.3

Android browser prototype with an embedded WireGuard USA mode and an automatic fail-closed USA verification gate.

## Security flow
1. Import a WireGuard `.conf` inside the app.
2. The profile is encrypted locally using Android Keystore.
3. WireGuard is scoped to the INFIN8 Browser package.
4. After connection, the app checks the current public exit country.
5. WebView internet traffic remains blocked until the exit is verified as `US`.
6. The app periodically re-verifies the exit. If verification fails, browsing is blocked and open internet tabs are returned home.

## Fail-closed layers
- App navigation checks require WireGuard + USA verification.
- While blocked, AndroidX WebKit `ProxyController` points WebView at a non-listening local proxy with no direct fallback rule.
- Geolocation is disabled and WebRTC is shielded in WebView.

## Important
Public IP geolocation databases can disagree. The verifier uses multiple independent checks and a tie-breaker when needed. This is a browser security/consistency control, not a guarantee about how any social platform classifies an account or audience.
