# Changelog

## v0.3.0 — Automatic USA Security Gate
- Added automatic VPN exit-country verification after WireGuard connects.
- Uses multiple public IP geolocation checks with a tie-breaker to handle stale databases.
- Internet remains blocked until the exit is verified as United States.
- Added a WebView process-level fail-closed proxy gate while unverified/disconnected.
- Re-verifies the exit periodically and when returning to the app after the verification becomes stale.
- USA status button now distinguishes connected/unverified from USA-verified.
- VPN configuration continues to be encrypted locally with Android Keystore.

## v0.2.0
- Embedded WireGuard tunnel support.
- Import Proton WireGuard .conf profiles securely.
- App-only VPN routing for INFIN8 Browser.
- Browser navigation blocked while WireGuard is disconnected.
