# INFIN8 Browser v2.0

Android browser prototype with embedded WireGuard USA routing and a fail-closed verification gate.

## v0.5 UI cleanup
- Minimal top toolbar: INFIN8 logo, search/address bar, overflow menu only
- Overflow menu contains Back, Forward, Reload, Home, New Tab, Tabs, USA network and IP check
- Each top tab has a visible × close button
- Android system Back now prioritizes WebView history; if no history exists on a website it returns to the INFIN8 home page instead of immediately exiting
- Android 13+ modern back callback registered for gesture/back-button reliability
- Removed the USA MODE badge from the new-tab page
- Increased INFIN8 Browser branding size
- Speed Dial is now 100% user-custom; no preloaded social shortcuts
- Removed the USA Security Gate promotional card from the homepage

## Network security retained
- Embedded WireGuard tunnel backend
- Imported .conf encrypted locally with Android Keystore
- Tunnel scoped to the INFIN8 app package
- Automatic US-exit verification with independent checks
- Fail-closed WebView proxy gate when USA exit is not verified
- WebRTC shield and geolocation disabled

The Proton WireGuard private key is intentionally NOT bundled in source. Import the profile on-device.


### Downloads Pro (v1.7)
INFIN8 includes an in-app HTTP/HTTPS download engine with resumable range downloads, Auto/1/4/8/16/32 parts, speed limits, Wi-Fi-only waiting, retry recovery, categories, live speed/ETA, notifications, page link grabbing, and safe Open/Share/Delete actions. Phase 2B adds public clear HLS/M3U8 and static DASH handling, user scheduling, queue reordering, and a 1–3 parallel-job control. HLS MPEG-TS is remuxed to MP4 when Android supports the codecs; unsupported streams fall back to TS. Encrypted HLS and DASH manifests that declare content protection are refused. Live/dynamic DASH, torrent/magnet support, and DRM bypass are intentionally not implemented.


### Browser Pro (v1.8 / Phase 3A)
INFIN8 now includes a native dark Settings center with selectable Google, Startpage, DuckDuckGo, Bing or Brave Search; third-party-cookie control; stronger built-in ad/tracker host blocking; optional pop-ups/new-window tabs; default Desktop Mode for new tabs; Find in Page; Copy/Share page tools; Android default-browser role support; clear-history/cookie/site-data/cache controls; and quick access to USA Network/VPN and Downloads Pro. The existing fail-closed USA verification gate, WebRTC shield, geolocation blocking, WireGuard behavior and Phase 2 downloader remain intact.

Phase 3B added isolated Incognito browsing and richer site permissions in a separate WebView profile/process.


## v1.9.0 — Phase 3B
INFIN8 Browser now includes an isolated Incognito process/profile, camera & microphone site-permission management, AMOLED/accent customization, recently closed tab recovery, and tab duplication. Private windows do not write the normal browser history/session and clear their private WebView data between sessions.


## v2.0.0 — Phase 3C
INFIN8 Browser adds a grouped tab switcher with persistent tab groups, per-site privacy overrides for ad blocking and third-party cookies, Android Autofill integration for normal WebView tabs, searchable Downloads Pro history/queue, and a live local device clock/date under INFIN8 LIMITED on the home screen. Incognito keeps Autofill disabled and remains isolated.
