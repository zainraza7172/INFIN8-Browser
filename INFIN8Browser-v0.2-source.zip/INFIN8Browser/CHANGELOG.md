# Changelog

## 0.2.0
- Added embedded WireGuard tunnel backend.
- Added secure on-device `.conf` import using Android Keystore encryption.
- Added browser-only VPN routing via WireGuard IncludedApplications.
- Blocked direct web navigation when the tunnel is down.
- Added automatic reconnect attempt on browser startup after a profile has been imported.
- Added USA connection status to the toolbar.
- Disabled Android DownloadManager in USA Mode to avoid bypassing the browser-only VPN.
- Removed the old WebView proxy configuration UI.

## 0.1.0
- Initial Android browser MVP.
