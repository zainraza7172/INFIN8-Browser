# INFIN8 Browser v0.2

Android browser MVP with a built-in WireGuard tunnel designed for a consistent US browsing environment.

## v0.2 network model

- Official WireGuard Android tunnel library (`com.wireguard.android:tunnel:1.0.20260102`)
- Runtime import of a standard Proton/WireGuard `.conf` file
- Imported configuration encrypted locally with Android Keystore (AES-GCM)
- No VPN private key stored in source code or GitHub
- `IncludedApplications = com.infin8.browser` is injected at runtime so the tunnel is limited to INFIN8 Browser
- Direct HTTP/HTTPS navigation is blocked while WireGuard is disconnected
- Geolocation denied by default
- WebRTC API shielded in WebView
- IP check: long-press the 🇺🇸 button after connecting

## Why the Proton config is not embedded

A WireGuard config contains a private key. Putting that key in a public GitHub repository or baking it permanently into a distributable APK would expose it. v0.2 therefore imports the config on the device after installation and encrypts it at rest.

## Current limitations

- This is still a WebView MVP, not a full Chromium fork.
- Android DownloadManager is disabled in USA Mode because it runs outside the browser package and could bypass an app-only VPN route.
- Proton Free does not promise the same exit IP forever even when the same config/server is reused.
- A true permanent fixed US IP still requires a static US gateway/dedicated IP.

## Build

Requires JDK 17, Android SDK 36 and Gradle/AGP compatible with the project.

```bash
gradle assembleDebug
```

Debug APK output:

`app/build/outputs/apk/debug/app-debug.apk`
